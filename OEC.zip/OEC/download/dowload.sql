

-- --------------------------------------------------------
-- Database: `user_system`
-- --------------------------------------------------------

CREATE DATABASE IF NOT EXISTS `user_system`;
USE `user_system`;

-- --------------------------------------------------------
-- Table structure for table `notifications`
-- --------------------------------------------------------



CREATE TABLE IF NOT EXISTS downloads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    file_name VARCHAR(255),
    file_path VARCHAR(255),
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);