<?php
include '../db.php';

if (!empty($_GET['id'])) {
    $id = intval($_GET['id']);

    // Get file path
    $stmt = $conn->prepare("SELECT file_path FROM downloads WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($file_path);
    if ($stmt->fetch()) {
        $stmt->close();

        // Delete file from folder
        if (file_exists($file_path)) {
            unlink($file_path);
        }

        // Delete from database
        $del = $conn->prepare("DELETE FROM downloads WHERE id = ?");
        $del->bind_param("i", $id);
        $del->execute();
        $del->close();
    }
}

header("Location: admin_upload.php");
exit;
?>
