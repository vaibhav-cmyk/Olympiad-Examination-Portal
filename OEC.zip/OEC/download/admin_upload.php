<?php include '../db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Upload | OEC</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<style>
body {
  background-color: #f8f9fa;
  font-family: 'Inter', sans-serif;
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}
.navbar {
  background-color: #004080;
}
.navbar-brand {
  color: white !important;
  font-weight: 600;
  font-size: 1.5rem;
}
.card {
  border-radius: 1rem;
  box-shadow: 0 0.125rem 0.25rem rgba(0,0,0,.075);
}
footer {
  background-color: #004080;
  color: white;
  text-align: center;
  padding: 1rem 0;
  margin-top: auto;
  font-size: 0.95rem;
}
</style>
</head>

<body>

<nav class="navbar navbar-dark">
  <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
    <div>
      <a class="navbar-brand fw-bold" href="#">OEC - Admin Panel</a>
    </div>
    <a href="../master_dash/masterdashboard.php" class="btn btn-light btn-sm">
      <i class="bi bi-arrow-left-circle me-1"></i> Back to Dashboard
    </a>
  </div>
</nav>

<main class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-10">
      <div class="card p-4 mb-4">
        <h3 class="mb-4 text-center" style="color: #004080;">
          <i class="bi bi-upload me-2"></i> Upload File
        </h3>

        <?php if (!empty($_GET['success'])): ?>
        <div id="success-alert" class="alert alert-success alert-dismissible fade show" role="alert">
          <i class="bi bi-check-circle-fill me-2"></i> File uploaded successfully!
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <form action="handle_upload.php" method="post" enctype="multipart/form-data">
          <div class="mb-3">
            <label for="file" class="form-label fw-semibold">Choose File (PDF/DOCX, max 2MB)</label>
            <input type="file" name="file" id="file" class="form-control" required>
          </div>
          <div class="d-grid">
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-cloud-arrow-up me-1"></i> Upload
            </button>
          </div>
        </form>
      </div>

      <!-- Existing Files Table -->
      <div class="card p-4">
        <h4 class="mb-3" style="color: #004080;">
          <i class="bi bi-folder2-open me-2"></i> Uploaded Files
        </h4>

        <!-- Search -->
        <div class="mb-3">
          <div class="input-group">
            <input type="text" id="searchInput" class="form-control" placeholder="Search by file name...">
            <button class="btn btn-primary" type="button" onclick="filterTable()">
              <i class="bi bi-search"></i> Search
            </button>
          </div>
        </div>

        <div class="table-responsive">
          <table class="table table-bordered align-middle" id="fileTable">
            <thead class="table-light">
              <tr>
                <th>File Name</th>
                <th>Uploaded At</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $result = $conn->query("SELECT * FROM downloads ORDER BY uploaded_at DESC");
              if ($result->num_rows > 0):
                  while ($row = $result->fetch_assoc()): ?>
                    <tr>
                      <td><?= htmlspecialchars($row['file_name']) ?></td>
                      <td><?= htmlspecialchars($row['uploaded_at']) ?></td>
                      <td>
                        <a href="delete_upload.php?id=<?= $row['id'] ?>" 
                           onclick="return confirm('Are you sure you want to delete this file?');" 
                           class="btn btn-sm btn-danger">
                          <i class="bi bi-trash"></i> Delete
                        </a>
                      </td>
                    </tr>
                  <?php endwhile;
              else: ?>
                <tr><td colspan="3" class="text-center">No files found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</main>

<footer>
  &copy; <?= date("Y") ?> Olympiad Examination Council. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Auto-hide success alert after 3s
setTimeout(() => {
  const alert = document.getElementById('success-alert');
  if (alert) {
    alert.classList.remove('show');
    alert.classList.add('fade');
  }
}, 3000);

// Dynamic table filter
function filterTable() {
  const input = document.getElementById("searchInput").value.toLowerCase();
  const rows = document.querySelectorAll("#fileTable tbody tr");
  rows.forEach(row => {
    const fileName = row.cells[0].textContent.toLowerCase();
    if (fileName.includes(input)) {
      row.style.display = "";
    } else {
      row.style.display = "none";
    }
  });
}

// Also filter as you type
document.getElementById("searchInput").addEventListener("input", filterTable);
</script>

</body>
</html>
