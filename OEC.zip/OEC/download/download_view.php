<?php include '../db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Download Files | OEC</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Bootstrap 5 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<style>
body {
  background-color: #f8f9fa;
  font-family: 'Inter', sans-serif;
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.navbar {
  background-color: #004080;
}

.navbar-brand {
  color: white !important;
  font-weight: 600;
  font-size: 1.5rem;
}

.card {
  border-radius: 1rem;
  box-shadow: 0 0.125rem 0.25rem rgba(0,0,0,.075);
}

footer {
  background-color: #004080;
  color: white;
  text-align: center;
  padding: 1rem 0;
  margin-top: auto;
  font-size: 0.95rem;
}
</style>
</head>

<body>

<!-- Navbar -->
<nav class="navbar navbar-dark">
  <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
    <div>
      <a class="navbar-brand fw-bold" href="#">OEC Portal</a>
    </div>
    <a href="../master_dash/masterdashboard.php" class="btn btn-light btn-sm">
      <i class="bi bi-arrow-left-circle me-1"></i> Back to Dashboard
    </a>
  </div>
</nav>

<!-- Main Content -->
<main class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-10">
      <div class="card p-4">
        <h3 class="mb-4 text-center" style="color: #004080;">
          <i class="bi bi-folder2-open me-2"></i> Available Downloads
        </h3>

        <div class="table-responsive">
          <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
              <tr class="text-center">
                <th>File Name</th>
                <th>View</th>
                <th>Download</th>
              </tr>
            </thead>
            <tbody>
            <?php
            $result = $conn->query("SELECT * FROM downloads ORDER BY uploaded_at DESC");
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $filePath = htmlspecialchars($row['file_path']);
                    echo "<tr>
                            <td>" . htmlspecialchars($row['file_name']) . "</td>
                            <td class='text-center'>
                              <a href='" . $filePath . "' target='_blank' class='btn btn-info btn-sm'>
                                <i class='bi bi-eye me-1'></i> View
                              </a>
                            </td>
                            <td class='text-center'>
                              <a href='" . $filePath . "' download class='btn btn-success btn-sm'>
                                <i class='bi bi-download me-1'></i> Download
                              </a>
                            </td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='3' class='text-center text-muted'>No files found.</td></tr>";
            }
            ?>
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>
</main>

<footer>
  &copy; <?= date("Y") ?> Olympiad Examination Council. All rights reserved.
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
