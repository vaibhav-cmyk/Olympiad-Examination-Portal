<?php
include '../db.php';

if (!is_dir('uploads')) {
    mkdir('uploads', 0777, true);
}

if (isset($_FILES['file'])) {
    $fileName = basename($_FILES['file']['name']);
    $targetPath = "uploads/" . $fileName;

    if (move_uploaded_file($_FILES['file']['tmp_name'], $targetPath)) {
        $stmt = $conn->prepare("INSERT INTO downloads (file_name, file_path) VALUES (?, ?)");
        $stmt->bind_param("ss", $fileName, $targetPath);
        $stmt->execute();
        $stmt->close();
        header("Location: admin_upload.php?success=1");
        exit;
    } else {
        echo "Error uploading file.";
    }
} else {
    echo "No file selected.";
}
?>
