<?php
// Start session if needed
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get values passed from student_dash.php
$regno   = $_GET['regno'] ?? '';
$student = $_GET['name'] ?? '';
$exam    = $_GET['next'] ?? '';
$grade   = $_GET['grade'] ?? '';
$Exam_Lg = $_GET['Exam_Lg'] ?? '';


// Prepare link to the actual exam page
$examLink = "exam_page.php"; // replace with your actual exam page
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Exam Instructions</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; color: #1f2937; }
        .card-shadow { box-shadow: 0 10px 20px -5px rgba(0,0,0,0.05), 0 0px 10px -5px rgba(0,0,0,0.05); }
        .gradient-button-bg { background: linear-gradient(to right, #4c51bf, #6b46c1); }
        .icon-container { background-color: rgba(255,255,255,0.2); }
    </style>
</head>
<body class="flex flex-col items-center justify-center min-h-screen p-4">

    <div class="max-w-4xl w-full bg-white rounded-3xl p-8 md:p-12 space-y-12 border border-gray-100 card-shadow">

        <!-- Header and Intro -->
        <header class="text-center space-y-4">
            <h1 class="text-4xl md:text-5xl font-extrabold text-gray-900">Online Exam Instructions</h1>
            <p class="text-base md:text-lg text-gray-600 max-w-2xl mx-auto">
                Please read the following instructions carefully before you begin.
            </p>
        </header>

        <!-- Student Details and Exam Info Section -->
        <section class="bg-gray-50 rounded-2xl p-6 md:p-8 border border-gray-100 card-shadow">
            <h2 class="text-xl md:text-2xl font-bold text-gray-800 mb-4">Exam Details</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-gray-600">
                <div class="flex items-center space-x-2">
                    <span class="text-lg font-medium text-gray-900">Name:</span>
                    <span><?= htmlspecialchars($student) ?></span>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="text-lg font-medium text-gray-900">Student ID:</span>
                    <span><?= htmlspecialchars($regno) ?></span>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="text-lg font-medium text-gray-900">Exam Name:</span>
                    <span><?= htmlspecialchars($exam) ?></span>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="text-lg font-medium text-gray-900">Language:</span>
                    <span><?= htmlspecialchars($Exam_Lg) ?></span>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="text-lg font-medium text-gray-900">Grade:</span>
                    <span><?= htmlspecialchars($grade) ?></span>
                </div>
            </div>
        </section>

        <!-- Instructions Section -->
        <section class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Timing Card -->
            <div class="bg-gray-50 rounded-2xl p-6 md:p-8 shadow-sm hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <div class="flex items-center mb-4 text-indigo-700">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 mr-3" viewBox="0 0 24 24" fill="currentColor">
                        <path fill-rule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zM12.75 6a.75.75 0 00-1.5 0v6c0 .414.168.81.47 1.112l5.592 5.591a.75.75 0 101.06-1.06l-5.02-5.022V6z" clip-rule="evenodd" />
                    </svg>
                    <h3 class="text-lg font-bold">Timing & Submission</h3>
                </div>
                <ul class="space-y-3 text-gray-600 text-sm">
                    <li>The exam duration is <b>90 minutes</b>. A timer will be displayed on the screen.</li>
                    <li>Your exam will be submitted automatically when the time expires.</li>
                    <li>The timer will begin as soon as you click the "Start Exam" button below.</li>
                </ul>
            </div>

            <!-- Technical Card -->
            <div class="bg-gray-50 rounded-2xl p-6 md:p-8 shadow-sm hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <div class="flex items-center mb-4 text-green-700">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 mr-3" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M4.5 3.75a3 3 0 00-3 3v10.5a3 3 0 003 3h15a3 3 0 003-3V6.75a3 3 0 00-3-3h-15z" />
                        <path fill-rule="evenodd" d="M13.5 6a.75.75 0 00-1.5 0v6c0 .414.168.81.47 1.112l5.592 5.591a.75.75 0 101.06-1.06l-5.02-5.022V6z" clip-rule="evenodd" />
                        <path fill-rule="evenodd" d="M3 13.5a.75.75 0 01.75-.75h1.5a.75.75 0 010 1.5h-1.5a.75.75 0 01-.75-.75z" clip-rule="evenodd" />
                        <path fill-rule="evenodd" d="M3 17.25a.75.75 0 01.75-.75h1.5a.75.75 0 010 1.5h-1.5a.75.75 0 01-.75-.75z" clip-rule="evenodd" />
                    </svg>
                    <h3 class="text-lg font-bold">Technical Requirements</h3>
                </div>
                <ul class="space-y-3 text-gray-600 text-sm">
                    <li>Ensure you have a <b>stable internet connection</b> to prevent interruptions.</li>
                    <li>You must not refresh or close your browser tab during the exam.</li>
                    <li>Please enable your webcam and microphone for proctoring purposes.</li>
                </ul>
            </div>

            <!-- Rules Card -->
            <div class="bg-gray-50 rounded-2xl p-6 md:p-8 shadow-sm hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <div class="flex items-center mb-4 text-red-700">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 mr-3" viewBox="0 0 24 24" fill="currentColor">
                        <path fill-rule="evenodd" d="M12 2.25a.75.75 0 01.75.75v12.553l1.58-1.06a.75.75 0 11.838 1.257l-2.25 1.5a.75.75 0 01-.838 0l-2.25-1.5a.75.75 0 01.838-1.257l1.58 1.06V3a.75.75 0 01.75-.75zm0 17.5a.75.75 0 00-1.5 0V19a.75.75 0 001.5 0v.75zm1.5-1.5a.75.75 0 000-1.5h-3a.75.75 0 000 1.5h3z" clip-rule="evenodd" />
                    </svg>
                    <h3 class="text-lg font-bold">Important Rules</h3>
                </div>
                <ul class="space-y-3 text-gray-600 text-sm">
                    <li>This is a <b>closed-book exam</b>. No external resources or notes are permitted.</li>
                    <li>You must work independently. Any form of collaboration is strictly forbidden.</li>
                    <li>Keep a pen and paper on hand for any rough work you may need.</li>
                </ul>
            </div>
        </section>

        <!-- Start Exam Button -->
        <div class="text-center mt-12">
            <button onclick="showAlert()" class="w-full md:w-auto px-12 py-5 font-bold text-lg rounded-full shadow-lg text-white gradient-button-bg hover:scale-105 transition-all">
                Start Exam
            </button>
        </div>
    </div>

    <!-- Modal -->
<div id="alertModal" class="hidden fixed inset-0 bg-gray-900 bg-opacity-75 backdrop-blur-sm flex items-center justify-center p-4 z-50 opacity-0 transition-opacity duration-300">
    <div class="modal-content-container w-full max-w-sm bg-white rounded-xl shadow-2xl p-6 text-center space-y-4">
        <h3 class="text-xl font-bold text-gray-900">Are You Ready to Begin?</h3>
        <p class="text-sm text-gray-500">We will get into full </p>
        <div class="mt-4">
            <a href="camera_mic.php?Regno=<?= urlencode($regno) ?>&name=<?= urlencode($student) ?>&next=<?= urlencode($exam) ?>&grade=<?= urlencode($grade) ?>&Exam_Lg=<?= urlencode($Exam_Lg) ?>" 
                class="block px-6 py-2 gradient-button-bg text-white font-medium rounded-full w-full shadow-sm hover:brightness-125 transition">
                OK
            </a>
        </div>
    </div>
</div>

    <script>
        function showAlert() {
            const modal = document.getElementById('alertModal');
            modal.classList.remove('hidden');
            setTimeout(() => {
                modal.classList.add('opacity-100');
                modal.querySelector('.modal-content-container').classList.add('modal-show');
            }, 10);
        }
    </script>
</body>
</html>
