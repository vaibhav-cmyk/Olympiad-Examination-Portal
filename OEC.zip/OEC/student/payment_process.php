<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['IS_LOGIN']) || !isset($_SESSION['RegID'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selectedExams = $_POST['selected_exams'] ?? [];
    $totalAmount = $_POST['total_amount'] ?? 0;

    if (empty($selectedExams)) {
        echo "<h3 style='color:red;text-align:center;'>No exams selected.</h3>";
        exit;
    }
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Payment Summary</title>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                margin: 0;
                padding: 0;
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .summary-container {
                background: white;
                padding: 2.5rem;
                border-radius: 20px;
                box-shadow: 0 15px 30px rgba(0,0,0,0.1);
                width: 90%;
                max-width: 600px;
                text-align: center;
            }
            .summary-heading {
                color: #2c3e50;
                font-size: 2.5rem;
                font-weight: 700;
                margin-bottom: 2rem;
                position: relative;
                padding-bottom: 15px;
            }
            .summary-heading:after {
                content: '';
                position: absolute;
                bottom: 0;
                left: 50%;
                transform: translateX(-50%);
                width: 80px;
                height: 4px;
                background: linear-gradient(90deg, #3498db, #2ecc71);
                border-radius: 2px;
            }
            .exam-list {
                list-style: none;
                padding: 0;
                margin: 2rem 0;
            }
            .exam-item {
                background: #f8f9fa;
                margin: 1rem 0;
                padding: 1rem 1.5rem;
                border-radius: 10px;
                color: #34495e;
                font-size: 1.1rem;
                box-shadow: 0 3px 10px rgba(0,0,0,0.05);
                transition: transform 0.2s;
            }
            .exam-item:hover {
                transform: translateX(5px);
            }
            .total-amount {
                background: linear-gradient(135deg, #3498db, #2ecc71);
                color: white;
                padding: 1.5rem;
                border-radius: 15px;
                margin: 2rem 0;
                font-size: 1.5rem;
                font-weight: 600;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            }
            .currency {
                font-size: 1.8rem;
                margin-right: 5px;
            }
            .pay-button {
                background: linear-gradient(135deg, #3498db, #2ecc71);
                color: white;
                border: none;
                padding: 15px 40px;
                border-radius: 30px;
                font-size: 1.2rem;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
                text-transform: uppercase;
                letter-spacing: 1px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.2);
                display: inline-block;
                text-decoration: none;
            }
            .pay-button:hover {
                transform: translateY(-3px);
                box-shadow: 0 8px 20px rgba(0,0,0,0.3);
            }
            .pay-button:active {
                transform: translateY(-1px);
            }
            .summary-section {
                background: #fff;
                border-radius: 15px;
                padding: 2rem;
                margin-bottom: 2rem;
                box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            }
            .back-icon {
                position: fixed;
                top: 18px;
                left: 18px;
                z-index: 1001;
                background: white;
                border-radius: 50%;
                box-shadow: 0 2px 8px rgba(52,152,219,0.08);
                width: 48px;
                height: 48px;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                transition: box-shadow 0.2s;
            }
            .back-icon:hover {
                box-shadow: 0 4px 16px rgba(52,152,219,0.18);
            }
            @media (max-width: 600px) {
                .back-icon {
                    top: 10px;
                    left: 10px;
                    width: 40px;
                    height: 40px;
                }
                .summary-container {
                    padding-top: 2.5rem;
                }
            }
        </style>
    </head>
    <body>
        <div class="back-icon" onclick="window.location.href='student_dash.php?page=exams'" title="Back to Exams">
            <!-- SVG Back Arrow Icon -->
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15 19L8 12L15 5" stroke="#3498db" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <div class="summary-container">
            <h2 class="summary-heading">Payment Summary</h2>
            <div class="summary-section">
                <h3 style="color: #2c3e50; margin-bottom: 1.5rem;">Selected Exams</h3>
                <ul class="exam-list">
                    <?php foreach ($selectedExams as $exam): ?>
                        <li class="exam-item"><?php echo htmlspecialchars($exam); ?></li>
                    <?php endforeach; ?>
                </ul>
                <div class="total-amount">
                    Total Amount: <span class="currency">₹</span><?php echo htmlspecialchars($totalAmount); ?>
                </div>
            </div>

            <form id="paymentForm" action="pay_now.php" method="POST">
                <?php foreach ($selectedExams as $exam): ?>
                    <input type="hidden" name="selected_exams[]" value="<?php echo htmlspecialchars($exam); ?>">
                <?php endforeach; ?>
                <input type="hidden" name="total_amount" value="<?php echo htmlspecialchars($totalAmount); ?>">
                <button type="submit" class="pay-button">Proceed to Pay</button>
            </form>
        </div>

        <script>
            document.getElementById('paymentForm').addEventListener('submit', function(e) {
                e.preventDefault();
                this.submit();
            });
        </script>
    </body>
    </html>
    <?php
} else {
    echo '<!DOCTYPE html>';
    echo '<html><head><title>Invalid Access</title>';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<style>
        body { background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh; margin: 0; display: flex; align-items: center; justify-content: center; }
        .error-card { background: #fff; padding: 2.5rem 2rem; border-radius: 18px; box-shadow: 0 8px 32px rgba(44,62,80,0.10); text-align: center; max-width: 350px; width: 90%; }
        .error-title { color: #e74c3c; font-size: 2rem; font-weight: 700; margin-bottom: 1.2rem; }
        .error-desc { color: #555; font-size: 1.1rem; margin-bottom: 2.2rem; }
        .back-btn { display: inline-block; background: linear-gradient(90deg, #3498db, #2ecc71); color: #fff; border: none; border-radius: 25px; padding: 12px 32px; font-size: 1.1rem; font-weight: 600; text-decoration: none; box-shadow: 0 2px 8px rgba(52,152,219,0.10); transition: background 0.2s, box-shadow 0.2s; cursor: pointer; }
        .back-btn:hover { background: linear-gradient(90deg, #2ecc71, #3498db); box-shadow: 0 4px 16px rgba(52,152,219,0.18); }
        @media (max-width: 600px) { .error-card { padding: 1.5rem 0.5rem; } .error-title { font-size: 1.4rem; } }
    </style>';
    echo '</head><body>';
    echo '<div class="error-card">';
    echo '<div class="error-title">Invalid Access</div>';
    echo '<div class="error-desc"></div>';
    echo '<a href="student_dash.php?page=exams" class="back-btn">&#8592; Back</a>';
    echo '</div>';
    echo '</body></html>';
}
?>