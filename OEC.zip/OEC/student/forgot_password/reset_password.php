<?php
session_start();
$host = "localhost";
$user = "olympiad_user_system";
$pass = "riteshweb";
$db = "olympiad_user_system";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $email = $_SESSION['reset_email']; // saved during OTP verification

    if ($new_password !== $confirm_password) {
        header("Location: message.php?type=error&msg=" . urlencode("❌ Passwords do not match!"));
        exit;
    }

    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

    $sql = "UPDATE olympiad_registrations SET S_Pass=? WHERE Email_ID=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $hashed_password, $email);

    if ($stmt->execute()) {
        header("Location: message.php?type=success&msg=" . urlencode("✅ Password reset successfully! You can now login."));
    } else {
        header("Location: message.php?type=error&msg=" . urlencode("❌ Something went wrong. Try again!"));
    }

    $stmt->close();
    $conn->close();
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Set New Password</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-900 flex items-center justify-center min-h-screen font-sans text-gray-200 p-4">
  
  <div class="bg-slate-800 border border-teal-500/30 shadow-2xl shadow-teal-500/10 rounded-2xl p-8 sm:p-10 w-full max-w-md">
      
      <!-- Header -->
      <div class="text-center mb-8">
          <svg class="mx-auto h-12 w-12 text-teal-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.286zm0 13.036h.008v.008h-.008v-.008z" />
          </svg>
          <h1 class="text-3xl font-bold text-gray-100 mt-4">Set a New Password</h1>
          <p class="text-gray-400 mt-2">Your new password must be strong and secure.</p>
      </div>

      <!-- Form -->
      <form method="POST" class="space-y-6">
          <div>
              <label for="new_password" class="block text-sm font-medium text-gray-400 mb-2">New Password</label>
              <input type="password" name="new_password" id="new_password" placeholder="Enter new password"
                     class="w-full bg-slate-700 border border-gray-600 rounded-lg px-4 py-3 text-gray-200 placeholder-gray-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-all duration-300" 
                     required>
          </div>

          <div>
              <label for="confirm_password" class="block text-sm font-medium text-gray-400 mb-2">Confirm Password</label>
              <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm new password"
                     class="w-full bg-slate-700 border border-gray-600 rounded-lg px-4 py-3 text-gray-200 placeholder-gray-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-all duration-300" 
                     required>
          </div>

          <button type="submit"
                  class="w-full bg-gradient-to-r from-purple-600 to-teal-500 text-white font-semibold py-3 rounded-lg tracking-wide hover:from-purple-700 hover:to-teal-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-teal-500 shadow-lg shadow-purple-500/30 hover:shadow-teal-500/40 transform hover:-translate-y-1 transition-all duration-300 ease-in-out">
              Update Password
          </button>
      </form>
  </div>
</body>
</html>