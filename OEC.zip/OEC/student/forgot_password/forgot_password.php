<?php
session_start();
$message = "";

// Database connection
$conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);

    if (!empty($email)) {
        $stmt = $conn->prepare("SELECT * FROM olympiad_registrations WHERE Email_ID = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Email exists → redirect to OTP page
            $_SESSION['reset_email'] = $email; // ✅ use this session variable
            header("Location: email_verification/send_otp.php");
            exit();

        } else {
            $message = "Email does not exist in our system.";
        }
    } else {
        $message = "Please enter your registered email.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Password Recovery</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-900 flex items-center justify-center min-h-screen font-sans text-gray-200 p-4">
    
    <div class="bg-slate-800 border border-blue-500/30 shadow-2xl shadow-blue-500/10 rounded-2xl p-8 sm:p-10 w-full max-w-md">
        
        <div class="text-center mb-8">
            <svg class="mx-auto h-12 w-12 text-blue-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1121.75 8.25z" />
            </svg>
            <h1 class="text-3xl font-bold text-gray-100 mt-4">Password Recovery</h1>
            <p class="text-gray-400 mt-2">Enter your email to receive a secure reset code.</p>
        </div>

        <?php if($message): ?>
        <div class="bg-red-900/50 border border-red-500/50 text-red-300 px-4 py-3 rounded-lg mb-6 text-center text-sm">
            <span><?php echo $message; ?></span>
        </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">
            <div>
                <label for="email" class="block text-sm font-medium text-gray-400 mb-2">Email Address</label>
                <input type="email" name="email" id="email" placeholder="you@company.com"
                       class="w-full bg-slate-700 border border-gray-600 rounded-lg px-4 py-3 text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all duration-300"
                       required>
            </div>
            <button type="submit"
                    class="w-full bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-semibold py-3 rounded-lg tracking-wide hover:from-blue-700 hover:to-cyan-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-cyan-500 shadow-lg shadow-blue-500/30 hover:shadow-cyan-500/40 transform hover:-translate-y-1 transition-all duration-300 ease-in-out">
                Send Verification Code
            </button>
        </form>
    </div>
</body>
</html>