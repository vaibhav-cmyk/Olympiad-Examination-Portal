<?php
session_start();
require 'db.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$errorMessage = '';
$emailFromGet = $_GET['email'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $enteredOtp = $_POST['otp'];

    // Fetch latest OTP
    $stmt = $conn->prepare("SELECT otp, expires_at FROM email_otps WHERE email = ? ORDER BY id DESC LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if ($result) {
        if ($result['otp'] == $enteredOtp && strtotime($result['expires_at']) > time()) {
            // ✅ OTP verified
            $_SESSION['verified_email'] = $email;
            header("Location: ../reset_password.php"); // redirect to password reset page
            exit();
        } elseif ($result['otp'] != $enteredOtp) {
            $errorMessage = "❌ Invalid OTP! Please try again.";
        } else {
            $errorMessage = "❌ OTP expired!";
        }
    } else {
        $errorMessage = "❌ No OTP found for this email!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>OTP Verification</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-r from-purple-100 to-pink-200 flex items-center justify-center min-h-screen">
  <div class="bg-white p-8 rounded-2xl shadow-lg w-full max-w-md">
    <h2 class="text-2xl font-bold text-gray-800 text-center mb-6">Verify OTP</h2>

    <?php if (!empty($errorMessage)): ?>
      <div class="bg-red-100 text-red-700 p-3 rounded mb-4 text-center">
        <?php echo $errorMessage; ?>
      </div>
    <?php endif; ?>

    <form method="POST" class="space-y-4">
      <input type="hidden" name="email" value="<?php echo htmlspecialchars($emailFromGet); ?>">

      <div>
        <label class="block text-gray-700 font-semibold mb-1">Enter OTP</label>
        <input type="text" name="otp" placeholder="Enter OTP"
               class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500" required>
      </div>

      <button type="submit"
              class="w-full bg-purple-600 text-white font-semibold py-2 rounded hover:bg-purple-700 transition">
        Verify OTP
      </button>
    </form>

    <p class="text-center text-gray-600 mt-4">
      OTP sent to <b><?php echo htmlspecialchars($emailFromGet); ?></b>
    </p>
  </div>
</body>
</html>
