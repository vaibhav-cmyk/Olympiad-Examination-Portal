<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ✅ Ensure email is set from forgot_password.php
// if (!isset($_SESSION['forgot_email']) || empty($_SESSION['forgot_email'])) {
//     header("Location: ../forgot_password.php");
//     exit();
// }

// $email = $_SESSION['forgot_email'];
if (!isset($_SESSION['reset_email']) || empty($_SESSION['reset_email'])) {
    header("Location: ../forgot_password.php");
    exit();
}

$email = $_SESSION['reset_email']; // ✅ same session variable as above

$errorMessage = "";

// Database connection
require 'db.php';

// PHPMailer
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Generate OTP
$otp = rand(100000, 999999);
$expiry = date("Y-m-d H:i:s", strtotime('+10 minutes'));

// Store OTP in DB
$stmt = $conn->prepare("INSERT INTO email_otps (email, otp, expires_at) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $email, $otp, $expiry);
$stmt->execute();

// Send OTP email
try {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'oec.code@gmail.com'; // your Gmail
    $mail->Password = 'yozrrtxkvtoecqct';  // App Password
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('oec.code@gmail.com', 'Olympiad Council');
    $mail->addAddress($email);
    $mail->Subject = 'Your Olympiad Council OTP';
    $mail->Body = "Your verification code is: $otp \n\nIt is valid for 10 minutes.";

    $mail->send();

    // Redirect to OTP verification page
    header("Location: verify.php?email=" . urlencode($email));
    exit();

} catch (Exception $e) {
    $errorMessage = "Could not send OTP. Error: {$mail->ErrorInfo}";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sending OTP</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-r from-blue-100 to-blue-300 flex items-center justify-center min-h-screen">
    <div class="bg-white p-8 rounded-2xl shadow-lg w-full max-w-md text-center">
        <?php if (!empty($errorMessage)): ?>
        <h2 class="text-xl font-bold text-red-600 mb-4">OTP Failed</h2>
        <p class="text-gray-700 mb-4"><?php echo $errorMessage; ?></p>
        <a href="../forgot_password.php" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Try Again</a>
        <?php else: ?>
        <h2 class="text-xl font-bold text-gray-800 mb-4">Sending OTP...</h2>
        <p class="text-gray-600">Please wait while we send the verification code to your email.</p>
        <div class="mt-4 flex justify-center">
            <div class="animate-spin rounded-full h-10 w-10 border-t-2 border-blue-600"></div>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
