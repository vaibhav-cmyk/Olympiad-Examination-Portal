<?php
$host = "localhost";
$db   = "olympiad_user_system";
$user = "olympiad_user_system";
$pass = "riteshweb";

$conn = new mysqli($host, $user, $pass, $db);


?>
