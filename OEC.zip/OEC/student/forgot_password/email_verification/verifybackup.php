<?php
session_start(); // Start the session to access variables
require 'db.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $enteredOtp = $_POST['otp'];

    // Get the latest OTP for the given email
    $stmt = $conn->prepare("SELECT otp, expires_at FROM email_otps WHERE email = ? ORDER BY id DESC LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if ($result) {
        if ($result['otp'] == $enteredOtp && strtotime($result['expires_at']) > time()) {
            // ✅ OTP is correct and not expired
            // Note: The session variables for email and country were already set in index.php
            // We just need to redirect to the correct page.
            
            // FIXED: Corrected typo from 'regiter.php' to 'register.php'
            header("Location: ../register.php");
            exit();
        } else if ($result['otp'] != $enteredOtp) {
            $errorMessage = "❌ Invalid OTP! Please try again.";
        } else {
            $errorMessage = "❌ OTP has expired! Please request a new one.";
        }
    } else {
        $errorMessage = "❌ No OTP found for this email!";
    }
}
?>

<!-- HTML Form for OTP entry -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>OTP Verification</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #f3e5f5, #ce93d8);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .card {
      animation: zoomIn 0.5s ease;
    }

    @keyframes zoomIn {
      0% {
        transform: scale(0.95);
        opacity: 0;
      }
      100% {
        transform: scale(1);
        opacity: 1;
      }
    }
  </style>
</head>
<body>

  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5">
        <div class="card shadow-lg rounded-4 p-4">
          <div class="card-body">
            <h3 class="card-title text-center text-dark mb-4">Verify OTP</h3>
            
            <?php if (!empty($errorMessage)): ?>
                <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
            <?php endif; ?>

            <form method="POST">
              <input type="hidden" name="email" value="<?php echo htmlspecialchars($_GET['email'] ?? ''); ?>">

              <div class="mb-3">
                <label for="otp" class="form-label">OTP</label>
                <input type="text" class="form-control" id="otp" name="otp" placeholder="Enter OTP" required>
              </div>

              <div class="d-grid">
                <button type="submit" class="btn btn-success btn-lg">Verify</button>
              </div>
            </form>
          </div>
        </div>
        <p class="text-center text-muted mt-3">Please check your email for the OTP.</p>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
