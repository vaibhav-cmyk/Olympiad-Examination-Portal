<?php
if (session_status() === PHP_SESSION_NONE) session_start();

// ================= DB Connection =================
$servername = "localhost";     // or "127.0.0.1"
$username   = "root";          // your MySQL username
$password   = "";              // your MySQL password (blank in XAMPP by default)
$database   = "olympiad_db";   // your database name

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// ================= Input Params ==================
$regno    = $_GET['Regno']  ?? '';
$name     = $_GET['name']   ?? '';
$next     = $_GET['next']   ?? '';     // may be slugged (with hyphens)
$grade    = intval($_GET['grade'] ?? 0);
$language = $_GET['Exam_Lg'] ?? 'English';

// Normalize subject from slug to title-case words
$subjectTitle = ucwords(str_replace('-', ' ', trim($next))); 

// ================= Fetch Questions ===============
$stmt = $conn->prepare("
  SELECT id, class, subject, language, section, question, option_a, option_b, option_c, option_d
  FROM questions
  WHERE class = ? AND LOWER(subject) = LOWER(?) AND LOWER(language) = LOWER(?)
  ORDER BY id ASC
");
$stmt->bind_param("iss", $grade, $subjectTitle, $language);
$stmt->execute();
$result = $stmt->get_result();

$questions = [];
while ($row = $result->fetch_assoc()) $questions[] = $row;

if (empty($questions)) {
  http_response_code(404);
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title><?= htmlspecialchars($subjectTitle) ?> — Grade <?= htmlspecialchars($grade) ?> Exam</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- SweetAlert2 -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <!-- Google Font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

  <style>
    :root { --brand: #4f46e5; }
    body { font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif; background:#f8fafc; }
    .exam-shell { max-width: 980px; }
    .sticky-topbar {
      position: sticky; top: 0; z-index: 1030; background: #ffffffcc; backdrop-filter: blur(6px);
      border-bottom: 1px solid rgba(0,0,0,.06);
    }
    .timer-badge { font-weight:700; letter-spacing:.5px; }
    .question-card { border:1px solid rgba(0,0,0,.06); border-radius:1rem; box-shadow: 0 10px 20px rgba(2,6,23,0.04); }
    .question-index { width: 40px; height: 40px; border-radius: 10px; background: #eef2ff; color:#3730a3; display:flex; align-items:center; justify-content:center; font-weight:700; }
    .option-item input { margin-right:.5rem; }
    .progress { height:10px; }
    .brand { color: var(--brand); }
    .btn-brand { background: var(--brand); color:#fff; border:none; }
    .btn-brand:hover { background: #4338ca; color:#fff; }
  </style>
</head>
<body>
  <!-- Sticky header -->
  <div class="sticky-topbar">
    <div class="container py-3 d-flex align-items-center justify-content-between exam-shell">
      <div class="d-flex flex-column">
        <div class="fw-bold fs-5 brand"><?= htmlspecialchars($subjectTitle) ?></div>
        <div class="text-muted small">
          Grade <?= htmlspecialchars($grade) ?> • <?= htmlspecialchars($language) ?> •
          Candidate: <?= htmlspecialchars($name) ?> (Reg: <?= htmlspecialchars($regno) ?>)
        </div>
      </div>
      <div class="text-end">
        <div class="timer-badge badge text-bg-light border">
          <span class="me-2">Time Left:</span>
          <span id="timeLeft" class="text-danger">60:00</span>
        </div>
        <div class="mt-2" style="min-width:240px">
          <div class="progress">
            <div id="timeBar" class="progress-bar" role="progressbar" style="width: 100%;" aria-valuemin="0" aria-valuemax="3600"></div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <main class="container my-4 exam-shell">
    <?php if (empty($questions)): ?>
      <div class="alert alert-warning shadow-sm">
        No questions found for <strong><?= htmlspecialchars($subjectTitle) ?></strong>, Grade <strong><?= htmlspecialchars($grade) ?></strong>, Language <strong><?= htmlspecialchars($language) ?></strong>.
      </div>
    <?php else: ?>
      <form id="examForm" method="post" action="submit_exam.php" class="mb-5">
        <input type="hidden" name="regno"    value="<?= htmlspecialchars($regno) ?>">
        <input type="hidden" name="name"     value="<?= htmlspecialchars($name) ?>">
        <input type="hidden" name="subject"  value="<?= htmlspecialchars($subjectTitle) ?>">
        <input type="hidden" name="grade"    value="<?= htmlspecialchars($grade) ?>">
        <input type="hidden" name="language" value="<?= htmlspecialchars($language) ?>">
        <input type="hidden" name="started_at" id="started_at" value="">

        <div class="d-flex justify-content-between align-items-center mb-3">
          <div class="text-muted">Total Questions: <strong><?= count($questions) ?></strong></div>
          <div>
            <button type="button" class="btn btn-outline-secondary me-2" id="saveExitBtn">Save & Exit</button>
            <button type="submit" class="btn btn-brand" id="submitBtn">Submit Now</button>
          </div>
        </div>

        <?php foreach ($questions as $i => $q): ?>
          <div class="question-card p-3 p-md-4 mb-3">
            <div class="d-flex align-items-start gap-3">
              <div class="question-index"><?= $i+1 ?></div>
              <div class="flex-grow-1">
                <div class="small text-uppercase text-muted fw-semibold mb-1"><?= htmlspecialchars($q['section'] ?? 'Section') ?></div>
                <div class="mb-3"><?= $q['question'] ?></div>
                <?php
                  $qid = intval($q['id']);
                  $opts = [
                    'A' => $q['option_a'],
                    'B' => $q['option_b'],
                    'C' => $q['option_c'],
                    'D' => $q['option_d'],
                  ];
                ?>
                <?php foreach ($opts as $key => $html): ?>
                  <div class="form-check option-item mb-1">
                    <input class="form-check-input" type="radio" name="answers[<?= $qid ?>]" id="q<?= $qid ?>_<?= $key ?>" value="<?= $key ?>">
                    <label class="form-check-label" for="q<?= $qid ?>_<?= $key ?>"><?= $html ?></label>
                  </div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>

        <div class="d-flex justify-content-end">
          <button type="submit" class="btn btn-brand btn-lg" id="finalSubmitBtn">Submit Exam</button>
        </div>
      </form>
    <?php endif; ?>
  </main>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <script>
    // ====== 60-minute Timer with persistence & auto-submit ======
    (function() {
      const TOTAL = 60 * 60; // seconds
      const BAR = document.getElementById('timeBar');
      const LABEL = document.getElementById('timeLeft');
      const FORM = document.getElementById('examForm');
      const SAVE_EXIT = document.getElementById('saveExitBtn');
      const STARTED = document.getElementById('started_at');

      const key = `exam_clock::<?= addslashes($regno) ?>::<?= addslashes($subjectTitle) ?>::<?= addslashes($grade) ?>::<?= addslashes($language) ?>`;

      let startedAt = localStorage.getItem(key);
      if (!startedAt) {
        startedAt = Math.floor(Date.now() / 1000);
        localStorage.setItem(key, startedAt);
      } else {
        startedAt = parseInt(startedAt, 10);
      }
      STARTED.value = startedAt;

      function fmt(sec) {
        const m = Math.floor(sec / 60);
        const s = sec % 60;
        return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
      }

      function tick() {
        const now = Math.floor(Date.now()/1000);
        let elapsed = now - startedAt;
        if (elapsed < 0) elapsed = 0;

        let left = TOTAL - elapsed;
        if (left <= 0) {
          LABEL.textContent = "00:00";
          BAR.style.width = "0%";
          autoSubmit();
          return;
        }
        LABEL.textContent = fmt(left);
        const pct = Math.max(0, Math.min(100, (left / TOTAL) * 100));
        BAR.style.width = pct + "%";
      }

      let submitted = false;
      function autoSubmit() {
        if (submitted) return;
        submitted = true;

        const inputs = FORM.querySelectorAll('input, button, select, textarea');
        inputs.forEach(i => i.disabled = true);

        Swal.fire({
          icon: 'info',
          title: 'Time is up!',
          text: 'Your answers are being submitted automatically.',
          allowOutsideClick: false,
          allowEscapeKey: false,
          showConfirmButton: false,
          didOpen: () => {
            FORM.submit();
          }
        });
      }

      function clearClock() { localStorage.removeItem(key); }

      FORM?.addEventListener('submit', () => {
        clearClock();
      });

      SAVE_EXIT?.addEventListener('click', () => {
        Swal.fire({
          icon: 'question',
          title: 'Save & Exit?',
          text: 'You can return later within the allotted time. The timer continues to run.',
          showCancelButton: true,
          confirmButtonText: 'Save & Exit',
        }).then(res => {
          if (res.isConfirmed) {
            window.location.href = 'student_dash.php';
          }
        });
      });

      window.addEventListener('beforeunload', function (e) {
        e.preventDefault();
        e.returnValue = '';
      });

      tick();
      setInterval(tick, 1000);
    })();
  </script>
</body>
</html>
