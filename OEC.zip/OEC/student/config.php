<?php
// Razorpay Configuration
define('RAZORPAY_KEY_ID', 'rzp_live_2QPIqbj2TQEQzy');
define('RAZORPAY_KEY_SECRET', 'Ta7PySWgL6eOzMznM1p5Gl2d');










// Database Configuration (if needed)
// define('DB_HOST', 'localhost');
// define('DB_USER', 'olympiad_user_system');
// define('DB_PASS', 'riteshweb');
// define('DB_NAME', 'olympiad_user_system');
?> 