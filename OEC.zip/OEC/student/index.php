<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
date_default_timezone_set("Asia/Kolkata");

// Redirect if already logged in
if (isset($_SESSION['IS_LOGIN'])) {
    header('Location: student_dash.php');
    exit();
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['Mobileno']);
    $password = trim($_POST['pass']);
    $isIndian = $_POST['isindian'];

    $conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("SELECT * FROM olympiad_registrations WHERE MobileNo = ? OR Email_ID = ?");
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['S_Pass'])) {
            $_SESSION['IS_LOGIN'] = true;
            $_SESSION['username'] = $row['Stud_name'];
            $_SESSION['RegID'] = $row['RegID'];
            $_SESSION['userid'] = $row['RegNo'];
            $_SESSION['country'] = $isIndian == '1' ? 'Indian' : 'International';
            $_SESSION['grade'] = $row['Grade'];

            header('Location: student_dash.php');
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "User not found.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    body {
      font-family: 'Roboto', sans-serif;
      background: linear-gradient(45deg, #9c27b0, #e91e63);
      min-height: 100vh;
      margin: 0;
    }

    .demo-container {
      min-height: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
      margin-top:100px;
    }

    .login-box {
      background: #fff;
      border-radius: 30px;
      padding: 80px 30px 30px;
      position: relative;
      box-shadow: 0px 0px 20px rgba(0,0,0,0.2);
      max-width: 500px;
      width: 100%;
      margin: auto;
    }

    .brand_logo_container {
      position: absolute;
      top: -60px;
      left: 50%;
      transform: translateX(-50%);
      background: #2e004f;
      height: 100px;
      width: 100px;
      border-radius: 50%;
      padding: 10px;
      display: flex;
      justify-content: center;
      align-items: center;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    }

    .brand_logo {
      height: 80px;
      width: 80px;
      border-radius: 50%;
      border: 3px solid white;
      object-fit: cover;
    }

    h2 {
      font-weight: bold;
    }

    .slctctry p {
      padding: 10px 25px;
      cursor: pointer;
      background-color: #f1f1f1;
      font-weight: bold;
      margin: 0;
    }

    .slctctry .active.p1 {
      background-color: #e91e63;
      color: #fff;
      border-radius: 50px 0 0 50px;
    }

    .slctctry .active.p2 {
      background-color: #ff9800;
      color: #fff;
      border-radius: 0 50px 50px 0;
    }

    .form-control-lg {
      font-size: 16px;
      padding: 20px;
      border-radius: 50px;
    }

    #forget {
      margin-top: 10px;
      font-size: 16px;
      color: #ff1744;
      text-align: center;
      font-weight: bold;
    }

    #forget a {
      color: inherit;
      text-decoration: none;
    }

    #forget a:hover {
      text-decoration: underline;
    }

    .btn-lg {
      padding: 12px 26px;
      font-size: 14px;
      font-weight: 700;
      border-radius: 25px;
    }

     /* ================== RESPONSIVE MEDIA QUERIES ================== */

    /* Extra small devices (portrait phones, less than 576px) */
    @media (max-width: 575.98px) {
     

      .login-box {
        padding: 60px 20px 25px;
        border-radius: 20px;
      }

      .brand_logo_container {
        height: 80px;
        width: 80px;
        top: -40px;
      }

      .brand_logo {
        height: 65px;
        width: 65px;
      }

      .form-control-lg {
        font-size: 15px;
        padding: 15px 12px;
        border-radius: 15px;
      }

      h2 {
        font-size: 20px;
      }

       
     
      /* Sign in button full width */
      .btn-lg {
        width: 100%;
        font-size: 15px;
        padding: 12px;
      }

      /* HOME + Registration stacked */
      .btn-group-mobile {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }

      .btn-group-mobile button {
        width: 100%;
      }
    }

    /* Small devices (landscape phones, 576px - 767px) */
   

    /* Medium devices (tablets, 768px - 991px) */
    @media (min-width: 768px) and (max-width: 991.98px) {
      .login-box {
        width: 80%;
        padding: 80px 35px 35px;
      }
      .form-control-lg {
        font-size: 16px;
        padding: 22px 20px;
      }
      h2 {
        font-size: 26px;
      }
    }

    /* Large devices (desktops, 992px - 1199px) */
    @media (min-width: 992px) and (max-width: 1199.98px) {
      .login-box {
        width: 70%;
      }
      h2 {
        font-size: 28px;
      }
    }

    /* Extra large devices (1200px and up) */
    @media (min-width: 1200px) {
      .login-box {
        max-width: 500px;
      }
    }

  </style>
</head>
<body>
  <div class="demo-container">
    <div class="login-box">
      <div class="brand_logo_container">
        <img src="img/img/oecfavicon.png" class="brand_logo" alt="Logo">
      </div>
      <h2 class="text-center mb-3">
        <i class="fas fa-globe text-primary"></i> Student Login
      </h2>
      <hr>
      <div class="d-flex justify-content-center slctctry mb-3">
        <p class="active p1" onclick="setType('1')"><i class="fas fa-flag"></i> Indian</p>
        <p class="active p2" onclick="setType('0'); window.location.href='../foreign_student';"><i class="fas fa-globe"></i> International</p>
      </div>
      <?php if ($error): ?>
        <div class="alert alert-danger text-center"><?php echo $error; ?></div>
      <?php endif; ?>
      <form method="post">
        <input type="hidden" name="isindian" id="isindian" value="1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
          </div>
          <input type="text" name="Mobileno" class="form-control form-control-lg" placeholder="Enter Mobile" required>
        </div>
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text"><i class="fas fa-lock"></i></span>
          </div>
          <input type="password" name="pass" class="form-control form-control-lg" placeholder="Enter Password" required>
        </div>
        
        <p id="forget" class="text-sm mb-4">
  <a href="forgot_password/forgot_password.php" 
     class="inline-block bg-blue-100 text-blue-600 hover:bg-blue-200 hover:text-white px-3 py-1 rounded-md font-bold transition duration-200 ">
    <i class="fas fa-key mr-1"></i> Forgot password?
  </a>
</p>





        <div class="text-center mb-3">
          <button type="submit" class="btn btn-lg shadow" style="background-color:#1976d2; color:white;">
            <i class="fas fa-sign-in-alt"></i> SIGN IN
          </button>
        </div>
      </form>
      <div class="text-center btn-group-mobile">
        <button onclick="window.location.href='../../index.html'" class="btn btn-success rounded-pill small-btn">
          <i class="fas fa-home"></i> HOME
        </button>
        <button onclick="window.location.href='registration/index.php'" class="btn btn-warning rounded-pill small-btn" style="font-weight:bold;">
          <i class="fas fa-user-plus"></i> Registration
        </button>
      </div>
    </div>
  </div>

  <script>
    function setType(val) {
      document.getElementById("isindian").value = val;
      const p1 = document.querySelector(".p1");
      const p2 = document.querySelector(".p2");
      if (val === "1") {
        p1.classList.add("active");
        p2.classList.remove("active");
      } else {
        p2.classList.add("active");
        p1.classList.remove("active");
      }
    }
// Disable Right-Click
        document.addEventListener("contextmenu", function (e) {
            e.preventDefault();
            alert("⚠️🚫 Right-click is disabled!\n\n🔒 This is an official website of Olympiad Examination Council.\n🐀󄐠Any malicious activity is strictly prohibited.\n👮‍♂️ Legal action will be taken against offenders.");
        });

        // Disable DevTools, View Source, etc.
        documen
        
        t.addEventListener("keydown", function (e) {
            if (
                e.keyCode === 123 || // F12
                (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I/J
                (e.ctrlKey && e.keyCode === 85) // Ctrl+U
            ) {
                e.preventDefault();
                alert("🚫⚠️ This action is disabled for security reasons.\n\n🔐 Unauthorized inspection or tampering is forbidden.\n👮‍♂️ Violators may face strict legal consequences.");
            }
        });






    
  </script>
</body>
</html>
