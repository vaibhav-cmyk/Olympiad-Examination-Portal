<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mobile'])) {
    $mobile = $_POST['mobile'];
    $stmt = $conn->prepare("SELECT RegID FROM olympiad_registrations WHERE MobileNo = ?");
    $stmt->bind_param("s", $mobile);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        echo 'exists';
    } else {
        echo 'not_exists';
    }
    $stmt->close();
    $conn->close();
    exit;
}
echo 'not_exists'; 