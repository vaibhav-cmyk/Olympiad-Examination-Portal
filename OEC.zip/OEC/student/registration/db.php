<?php
$servername = "localhost";
$username = "olympiad_user_system";
$password = "riteshweb"; // replace with actual password
$dbname = "olympiad_user_system"; // replace with actual DB name

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
