<?php
header('Content-Type: application/json');

// Database connection details
$host = 'localhost';
$db = 'olympiad_user_system';
$user = 'olympiad_user_system';
$pass = 'riteshweb';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    echo json_encode(['exists' => false, 'error' => 'Database connection failed']);
    exit;
}

$type = $_GET['type'] ?? '';
$value = $_GET['value'] ?? '';

if ($type === 'mobile') {
    $stmt = $conn->prepare('SELECT RegID FROM olympiad_registrations WHERE MobileNo = ?');
    $stmt->bind_param('s', $value);
} elseif ($type === 'email') {
    $stmt = $conn->prepare('SELECT RegID FROM olympiad_registrations WHERE Email_ID = ?');
    $stmt->bind_param('s', $value);
} else {
    echo json_encode(['exists' => false, 'error' => 'Invalid type']);
    $conn->close();
    exit;
}

$stmt->execute();
$stmt->store_result();
$exists = $stmt->num_rows > 0;
$stmt->close();
$conn->close();

echo json_encode(['exists' => $exists]); 