<?php
session_start();

// Initialize error message
$error_message = '';

// --- Form Submission Logic ---
// This block handles the server-side validation when the form is submitted.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Store posted values in session to repopulate form on error
    $_SESSION['country_name'] = $_POST['country_name'] ?? '';
    $_SESSION['country_code'] = $_POST['country_code'] ?? '';
    $_SESSION['mobile'] = $_POST['mobile'] ?? '';
    $_SESSION['email'] = $_POST['email'] ?? '';

    // --- Database Connection ---
    // IMPORTANT: In a production environment, store these credentials securely
    // and not directly in the code.
    $host = "localhost";
    $db = "olympiad_user_system";
    $user = "olympiad_user_system";
    $pass = "riteshweb";
    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        // Use a generic error to avoid revealing server details
        die("Critical Error: Could not connect to the database. Please try again later.");
    }

    // --- Logic for Indian Users (+91) ---
    if (isset($_POST['country_code']) && $_POST['country_code'] === '+91') {
        $mobile = $_POST['mobile'] ?? '';
        // Use prepared statements to prevent SQL injection
        $stmt = $conn->prepare("SELECT RegID FROM olympiad_registrations WHERE MobileNo = ?");
        $stmt->bind_param("s", $mobile);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error_message = 'This mobile number is already registered.';
        } else {
            // Mobile is unique, proceed to the next registration step
            $stmt->close();
            $conn->close();
            header("Location: register.php"); // Redirect to the main registration page
            exit;
        }
        $stmt->close();

    // --- Logic for International Users ---
    } else {
        $email = $_POST['email'] ?? '';
        // Use prepared statements to prevent SQL injection
        $stmt = $conn->prepare("SELECT Student_ID FROM olympiad_registration WHERE Email_ID = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error_message = 'This email address is already registered.';
        } else {
            // Email is unique, proceed to OTP verification
            $stmt->close();
            $conn->close();
            header("Location: ../../foreign_student_registration/email_verification/send_otp.php"); // Redirect to OTP page
            exit;
        }
        $stmt->close();
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OEC Student Verification | Olympiad Examination Council</title>

    <!-- Frameworks & Libraries -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <!-- Google Fonts: Poppins for a modern, clean look -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
    :root {
        --primary-color: #6a11cb;
        --secondary-color: #2575fc;
        --white-color: #ffffff;
        --light-gray: #f8f9fa;
        --dark-gray: #343a40;
        --danger-color: #e74c3c;
    }

    body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
        background-size: 400% 400%;
        animation: gradientBG 15s ease infinite;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 1rem;
    }

    @keyframes gradientBG {
        0% {
            background-position: 0% 50%;
        }

        50% {
            background-position: 100% 50%;
        }

        100% {
            background-position: 0% 50%;
        }
    }

    .form-container {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(15px);
        -webkit-backdrop-filter: blur(15px);
        border-radius: 1.5rem;
        padding: 2.5rem 3rem;
        border: 1px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
        animation: fadeIn 0.8s ease-out forwards;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .oec-header {
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        padding-bottom: 1rem;
        margin-bottom: 1.5rem;
    }

    .form-control,
    .form-select {
        background-color: rgba(255, 255, 255, 0.8);
        border: 1px solid rgba(0, 0, 0, 0.1);
        border-radius: 0.5rem;
        height: 50px;
        padding-left: 2.5rem;
        /* Space for icon */
        transition: all 0.3s ease;
    }

    .form-control:focus,
    .form-select:focus {
        background-color: var(--white-color);
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgba(106, 17, 203, 0.2);
    }

    .input-group-text {
        background: transparent;
        border: none;
        position: absolute;
        left: 15px;
        top: 50%;
        transform: translateY(-50%);
        z-index: 10;
        color: #888;
    }

    .form-label {
        font-weight: 500;
        color: var(--dark-gray);
    }

    .btn-primary {
        background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
        border: none;
        border-radius: 0.5rem;
        padding: 0.8rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-primary:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    }

    .btn-outline {
        border-radius: 0.5rem;
        padding: 0.6rem 1rem;
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .btn-outline-dark:hover {
        background-color: var(--dark-gray);
        color: var(--white-color);
    }

    .btn-outline-success:hover {
        background-color: #198754;
        color: var(--white-color);
    }

    .error-message {
        background-color: rgba(231, 76, 60, 0.1);
        color: var(--danger-color);
        border: 1px solid var(--danger-color);
        font-weight: 500;
        border-radius: 0.5rem;
        padding: 0.8rem;
        text-align: center;
    }

    /* Smooth transition for conditional fields */
    .conditional-field {
        overflow: hidden;
        transition: max-height 0.5s ease-in-out, opacity 0.3s ease-in-out;
        max-height: 0;
        opacity: 0;
    }

    .conditional-field.visible {
        max-height: 100px;
        /* Adjust if field is taller */
        opacity: 1;
    }
    </style>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <div class="form-container">

                    <div class="oec-header d-flex align-items-center gap-3">
                        <img src="img/oecfavicon.png" alt="OEC Logo" style="width:50px;" />
                        <div>
                            <h5 class="fw-bold text-dark mb-0">Olympiad Examination Council</h5>

                        </div>
                    </div>
                    <div class="text-center mb-8">
                        <h4 class="text-white text-4xl font-bold">Create Student Account</h4>
                    </div>


                    <?php if (!empty($error_message)): ?>
                    <div class="error-message mb-3">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error_message; ?>
                    </div>
                    <?php endif; ?>

                    <form id="verificationForm" method="post" action="">
                        <input type="hidden" id="country_name" name="country_name"
                            value="<?php echo htmlspecialchars($_SESSION['country_name'] ?? ''); ?>">

                        <div class="mb-3">
                            <label for="country_code" class="form-label">Country</label>
                            <div class="input-group mb-2">
                                <span class="input-group-text"></i></span>
                                <input type="text" id="country_search" class="form-control" placeholder="Search countries...">
                            </div>
                            <div class="input-group">
                                <span class="input-group-text"></span>
                                <select name="country_code" id="country_code" required class="form-select"
                                    onchange="updateFormForCountry()">
                                    <option value="" disabled selected>Select Country </option>
                                    <option data-country-code="IN" value="+91"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+91') echo 'selected'; ?>>
                                        +91 (India)</option>
                                    <option data-country-code="AF" value="+93"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+93') echo 'selected'; ?>>
                                        +93 (Afghanistan)</option>
                                    <option data-country-code="AX" value="+358"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+358') echo 'selected'; ?>>
                                        +358 (Aland Islands)</option>
                                    <option data-country-code="AL" value="+355"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+355') echo 'selected'; ?>>
                                        +355 (Albania)</option>
                                    <option data-country-code="DZ" value="+213"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+213') echo 'selected'; ?>>
                                        +213 (Algeria)</option>
                                    <option data-country-code="AS" value="+1-684"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-684') echo 'selected'; ?>>
                                        +1-684 (American Samoa)</option>
                                    <option data-country-code="AD" value="+376"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+376') echo 'selected'; ?>>
                                        +376 (Andorra)</option>
                                    <option data-country-code="AO" value="+244"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+244') echo 'selected'; ?>>
                                        +244 (Angola)</option>
                                    <option data-country-code="AI" value="+1-264"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-264') echo 'selected'; ?>>
                                        +1-264 (Anguilla)</option>
                                    <option data-country-code="AQ" value="+672"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+672') echo 'selected'; ?>>
                                        +672 (Antarctica)</option>
                                    <option data-country-code="AG" value="+1-268"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-268') echo 'selected'; ?>>
                                        +1-268 (Antigua and Barbuda)</option>
                                    <option data-country-code="AR" value="+54"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+54') echo 'selected'; ?>>
                                        +54 (Argentina)</option>
                                    <option data-country-code="AM" value="+374"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+374') echo 'selected'; ?>>
                                        +374 (Armenia)</option>
                                    <option data-country-code="AW" value="+297"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+297') echo 'selected'; ?>>
                                        +297 (Aruba)</option>
                                    <option data-country-code="AU" value="+61"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+61') echo 'selected'; ?>>
                                        +61 (Australia)</option>
                                    <option data-country-code="AT" value="+43"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+43') echo 'selected'; ?>>
                                        +43 (Austria)</option>
                                    <option data-country-code="AZ" value="+994"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+994') echo 'selected'; ?>>
                                        +994 (Azerbaijan)</option>
                                    <option data-country-code="BS" value="+1-242"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-242') echo 'selected'; ?>>
                                        +1-242 (Bahamas)</option>
                                    <option data-country-code="BH" value="+973"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+973') echo 'selected'; ?>>
                                        +973 (Bahrain)</option>
                                    <option data-country-code="BD" value="+880"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+880') echo 'selected'; ?>>
                                        +880 (Bangladesh)</option>
                                    <option data-country-code="BB" value="+1-246"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-246') echo 'selected'; ?>>
                                        +1-246 (Barbados)</option>
                                    <option data-country-code="BY" value="+375"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+375') echo 'selected'; ?>>
                                        +375 (Belarus)</option>
                                    <option data-country-code="BE" value="+32"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+32') echo 'selected'; ?>>
                                        +32 (Belgium)</option>
                                    <option data-country-code="BZ" value="+501"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+501') echo 'selected'; ?>>
                                        +501 (Belize)</option>
                                    <option data-country-code="BJ" value="+229"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+229') echo 'selected'; ?>>
                                        +229 (Benin)</option>
                                    <option data-country-code="BM" value="+1-441"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-441') echo 'selected'; ?>>
                                        +1-441 (Bermuda)</option>
                                    <option data-country-code="BT" value="+975"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+975') echo 'selected'; ?>>
                                        +975 (Bhutan)</option>
                                    <option data-country-code="BO" value="+591"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+591') echo 'selected'; ?>>
                                        +591 (Bolivia)</option>
                                    <option data-country-code="BA" value="+387"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+387') echo 'selected'; ?>>
                                        +387 (Bosnia and Herzegovina)</option>
                                    <option data-country-code="BW" value="+267"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+267') echo 'selected'; ?>>
                                        +267 (Botswana)</option>
                                    <option data-country-code="BR" value="+55"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+55') echo 'selected'; ?>>
                                        +55 (Brazil)</option>
                                    <option data-country-code="IO" value="+246"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+246') echo 'selected'; ?>>
                                        +246 (British Indian Ocean Territory)</option>
                                    <option data-country-code="VG" value="+1-284"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-284') echo 'selected'; ?>>
                                        +1-284 (British Virgin Islands)</option>
                                    <option data-country-code="BN" value="+673"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+673') echo 'selected'; ?>>
                                        +673 (Brunei)</option>
                                    <option data-country-code="BG" value="+359"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+359') echo 'selected'; ?>>
                                        +359 (Bulgaria)</option>
                                    <option data-country-code="BF" value="+226"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+226') echo 'selected'; ?>>
                                        +226 (Burkina Faso)</option>
                                    <option data-country-code="BI" value="+257"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+257') echo 'selected'; ?>>
                                        +257 (Burundi)</option>
                                    <option data-country-code="KH" value="+855"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+855') echo 'selected'; ?>>
                                        +855 (Cambodia)</option>

                                    <option data-country-code="CM" value="+237"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+237') echo 'selected'; ?>>
                                        +237 (Cameroon)</option>

                                    <option data-country-code="CA" value="+1"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1') echo 'selected'; ?>>
                                        +1 (Canada)</option>

                                    <option data-country-code="CV" value="+238"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+238') echo 'selected'; ?>>
                                        +238 (Cape Verde)</option>

                                    <option data-country-code="KY" value="+1-345"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-345') echo 'selected'; ?>>
                                        +1-345 (Cayman Islands)</option>

                                    <option data-country-code="CF" value="+236"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+236') echo 'selected'; ?>>
                                        +236 (Central African Republic)</option>

                                    <option data-country-code="TD" value="+235"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+235') echo 'selected'; ?>>
                                        +235 (Chad)</option>

                                    <option data-country-code="CL" value="+56"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+56') echo 'selected'; ?>>
                                        +56 (Chile)</option>

                                    <option data-country-code="CN" value="+86"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+86') echo 'selected'; ?>>
                                        +86 (China)</option>

                                    <option data-country-code="CX" value="+61"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+61') echo 'selected'; ?>>
                                        +61 (Christmas Island)</option>

                                    <option data-country-code="CC" value="+61"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+61') echo 'selected'; ?>>
                                        +61 (Cocos Islands)</option>

                                    <option data-country-code="CO" value="+57"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+57') echo 'selected'; ?>>
                                        +57 (Colombia)</option>

                                    <option data-country-code="KM" value="+269"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+269') echo 'selected'; ?>>
                                        +269 (Comoros)</option>

                                    <option data-country-code="CG" value="+242"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+242') echo 'selected'; ?>>
                                        +242 (Congo)</option>

                                    <option data-country-code="CD" value="+243"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+243') echo 'selected'; ?>>
                                        +243 (Congo, Democratic Republic of the)</option>

                                    <option data-country-code="CK" value="+682"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+682') echo 'selected'; ?>>
                                        +682 (Cook Islands)</option>

                                    <option data-country-code="CR" value="+506"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+506') echo 'selected'; ?>>
                                        +506 (Costa Rica)</option>

                                    <option data-country-code="HR" value="+385"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+385') echo 'selected'; ?>>
                                        +385 (Croatia)</option>

                                    <option data-country-code="CU" value="+53"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+53') echo 'selected'; ?>>
                                        +53 (Cuba)</option>

                                    <option data-country-code="CW" value="+599"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+599') echo 'selected'; ?>>
                                        +599 (Curacao)</option>

                                    <option data-country-code="CY" value="+357"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+357') echo 'selected'; ?>>
                                        +357 (Cyprus)</option>

                                    <option data-country-code="CZ" value="+420"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+420') echo 'selected'; ?>>
                                        +420 (Czech Republic)</option>

                                    <option data-country-code="CI" value="+225"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+225') echo 'selected'; ?>>
                                        +225 (Cote d'Ivoire)</option>

                                    <option data-country-code="DK" value="+45"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+45') echo 'selected'; ?>>
                                        +45 (Denmark)</option>

                                    <option data-country-code="DJ" value="+253"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+253') echo 'selected'; ?>>
                                        +253 (Djibouti)</option>

                                    <option data-country-code="DM" value="+1-767"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-767') echo 'selected'; ?>>
                                        +1-767 (Dominica)</option>

                                    <option data-country-code="DO" value="+1-809"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-809') echo 'selected'; ?>>
                                        +1-809 (Dominican Republic)</option>

                                    <option data-country-code="EC" value="+593"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+593') echo 'selected'; ?>>
                                        +593 (Ecuador)</option>

                                    <option data-country-code="EG" value="+20"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+20') echo 'selected'; ?>>
                                        +20 (Egypt)</option>

                                    <option data-country-code="SV" value="+503"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+503') echo 'selected'; ?>>
                                        +503 (El Salvador)</option>

                                    <option data-country-code="GQ" value="+240"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+240') echo 'selected'; ?>>
                                        +240 (Equatorial Guinea)</option>
                                    <option data-country-code="ER" value="+291"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+291') echo 'selected'; ?>>
                                        +291 (Eritrea)</option>

                                    <option data-country-code="EE" value="+372"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+372') echo 'selected'; ?>>
                                        +372 (Estonia)</option>

                                    <option data-country-code="ET" value="+251"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+251') echo 'selected'; ?>>
                                        +251 (Ethiopia)</option>

                                    <option data-country-code="FK" value="+500"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+500') echo 'selected'; ?>>
                                        +500 (Falkland Islands)</option>

                                    <option data-country-code="FO" value="+298"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+298') echo 'selected'; ?>>
                                        +298 (Faroe Islands)</option>

                                    <option data-country-code="FJ" value="+679"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+679') echo 'selected'; ?>>
                                        +679 (Fiji)</option>

                                    <option data-country-code="FI" value="+358"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+358') echo 'selected'; ?>>
                                        +358 (Finland)</option>

                                    <option data-country-code="FR" value="+33"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+33') echo 'selected'; ?>>
                                        +33 (France)</option>

                                    <option data-country-code="GF" value="+594"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+594') echo 'selected'; ?>>
                                        +594 (French Guiana)</option>

                                    <option data-country-code="PF" value="+689"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+689') echo 'selected'; ?>>
                                        +689 (French Polynesia)</option>

                                    <option data-country-code="GA" value="+241"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+241') echo 'selected'; ?>>
                                        +241 (Gabon)</option>

                                    <option data-country-code="GM" value="+220"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+220') echo 'selected'; ?>>
                                        +220 (Gambia)</option>

                                    <option data-country-code="GE" value="+995"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+995') echo 'selected'; ?>>
                                        +995 (Georgia)</option>

                                    <option data-country-code="DE" value="+49"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+49') echo 'selected'; ?>>
                                        +49 (Germany)</option>

                                    <option data-country-code="GH" value="+233"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+233') echo 'selected'; ?>>
                                        +233 (Ghana)</option>

                                    <option data-country-code="GI" value="+350"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+350') echo 'selected'; ?>>
                                        +350 (Gibraltar)</option>

                                    <option data-country-code="GR" value="+30"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+30') echo 'selected'; ?>>
                                        +30 (Greece)</option>

                                    <option data-country-code="GL" value="+299"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+299') echo 'selected'; ?>>
                                        +299 (Greenland)</option>

                                    <option data-country-code="GD" value="+1-473"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-473') echo 'selected'; ?>>
                                        +1-473 (Grenada)</option>

                                    <option data-country-code="GP" value="+590"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+590') echo 'selected'; ?>>
                                        +590 (Guadeloupe)</option>

                                    <option data-country-code="GU" value="+1-671"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-671') echo 'selected'; ?>>
                                        +1-671 (Guam)</option>

                                    <option data-country-code="GT" value="+502"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+502') echo 'selected'; ?>>
                                        +502 (Guatemala)</option>

                                    <option data-country-code="GG" value="+44-1481"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+44-1481') echo 'selected'; ?>>
                                        +44-1481 (Guernsey)</option>

                                    <option data-country-code="GN" value="+224"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+224') echo 'selected'; ?>>
                                        +224 (Guinea)</option>

                                    <option data-country-code="GW" value="+245"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+245') echo 'selected'; ?>>
                                        +245 (Guinea-Bissau)</option>

                                    <option data-country-code="GY" value="+592"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+592') echo 'selected'; ?>>
                                        +592 (Guyana)</option>

                                    <option data-country-code="HT" value="+509"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+509') echo 'selected'; ?>>
                                        +509 (Haiti)</option>

                                    <option data-country-code="HN" value="+504"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+504') echo 'selected'; ?>>
                                        +504 (Honduras)</option>

                                    <option data-country-code="HK" value="+852"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+852') echo 'selected'; ?>>
                                        +852 (Hong Kong)</option>

                                    <option data-country-code="HU" value="+36"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+36') echo 'selected'; ?>>
                                        +36 (Hungary)</option>

                                    <option data-country-code="IS" value="+354"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+354') echo 'selected'; ?>>
                                        +354 (Iceland)</option>
                                    <option data-country-code="ID" value="+62"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+62') echo 'selected'; ?>>
                                        +62 (Indonesia)</option>
                                    <option data-country-code="IR" value="+98"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+98') echo 'selected'; ?>>
                                        +98 (Iran)</option>

                                    <option data-country-code="IQ" value="+964"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+964') echo 'selected'; ?>>
                                        +964 (Iraq)</option>

                                    <option data-country-code="IE" value="+353"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+353') echo 'selected'; ?>>
                                        +353 (Ireland)</option>

                                    <option data-country-code="IM" value="+44-1624"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+44-1624') echo 'selected'; ?>>
                                        +44-1624 (Isle of Man)</option>

                                    <option data-country-code="IL" value="+972"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+972') echo 'selected'; ?>>
                                        +972 (Israel)</option>

                                    <option data-country-code="IT" value="+39"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+39') echo 'selected'; ?>>
                                        +39 (Italy)</option>

                                    <option data-country-code="JM" value="+1-876"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-876') echo 'selected'; ?>>
                                        +1-876 (Jamaica)</option>

                                    <option data-country-code="JP" value="+81"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+81') echo 'selected'; ?>>
                                        +81 (Japan)</option>

                                    <option data-country-code="JE" value="+44-1534"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+44-1534') echo 'selected'; ?>>
                                        +44-1534 (Jersey)</option>

                                    <option data-country-code="JO" value="+962"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+962') echo 'selected'; ?>>
                                        +962 (Jordan)</option>

                                    <option data-country-code="KZ" value="+7"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+7') echo 'selected'; ?>>
                                        +7 (Kazakhstan)</option>

                                    <option data-country-code="KE" value="+254"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+254') echo 'selected'; ?>>
                                        +254 (Kenya)</option>

                                    <option data-country-code="KI" value="+686"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+686') echo 'selected'; ?>>
                                        +686 (Kiribati)</option>

                                    <option data-country-code="XK" value="+383"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+383') echo 'selected'; ?>>
                                        +383 (Kosovo)</option>

                                    <option data-country-code="KW" value="+965"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+965') echo 'selected'; ?>>
                                        +965 (Kuwait)</option>

                                    <option data-country-code="KG" value="+996"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+996') echo 'selected'; ?>>
                                        +996 (Kyrgyzstan)</option>

                                    <option data-country-code="LA" value="+856"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+856') echo 'selected'; ?>>
                                        +856 (Laos)</option>

                                    <option data-country-code="LV" value="+371"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+371') echo 'selected'; ?>>
                                        +371 (Latvia)</option>

                                    <option data-country-code="LB" value="+961"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+961') echo 'selected'; ?>>
                                        +961 (Lebanon)</option>

                                    <option data-country-code="LS" value="+266"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+266') echo 'selected'; ?>>
                                        +266 (Lesotho)</option>

                                    <option data-country-code="LR" value="+231"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+231') echo 'selected'; ?>>
                                        +231 (Liberia)</option>

                                    <option data-country-code="LY" value="+218"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+218') echo 'selected'; ?>>
                                        +218 (Libya)</option>

                                    <option data-country-code="LI" value="+423"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+423') echo 'selected'; ?>>
                                        +423 (Liechtenstein)</option>

                                    <option data-country-code="LT" value="+370"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+370') echo 'selected'; ?>>
                                        +370 (Lithuania)</option>

                                    <option data-country-code="LU" value="+352"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+352') echo 'selected'; ?>>
                                        +352 (Luxembourg)</option>

                                    <option data-country-code="MO" value="+853"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+853') echo 'selected'; ?>>
                                        +853 (Macau)</option>

                                    <option data-country-code="MK" value="+389"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+389') echo 'selected'; ?>>
                                        +389 (Macedonia)</option>

                                    <option data-country-code="MG" value="+261"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+261') echo 'selected'; ?>>
                                        +261 (Madagascar)</option>

                                    <option data-country-code="MW" value="+265"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+265') echo 'selected'; ?>>
                                        +265 (Malawi)</option>

                                    <option data-country-code="MY" value="+60"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+60') echo 'selected'; ?>>
                                        +60 (Malaysia)</option>

                                    <option data-country-code="MV" value="+960"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+960') echo 'selected'; ?>>
                                        +960 (Maldives)</option>

                                    <option data-country-code="ML" value="+223"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+223') echo 'selected'; ?>>
                                        +223 (Mali)</option>

                                    <option data-country-code="MT" value="+356"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+356') echo 'selected'; ?>>
                                        +356 (Malta)</option>

                                    <option data-country-code="MH" value="+692"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+692') echo 'selected'; ?>>
                                        +692 (Marshall Islands)</option>

                                    <option data-country-code="MQ" value="+596"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+596') echo 'selected'; ?>>
                                        +596 (Martinique)</option>

                                    <option data-country-code="MR" value="+222"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+222') echo 'selected'; ?>>
                                        +222 (Mauritania)</option>

                                    <option data-country-code="MU" value="+230"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+230') echo 'selected'; ?>>
                                        +230 (Mauritius)</option>

                                    <option data-country-code="YT" value="+262"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+262') echo 'selected'; ?>>
                                        +262 (Mayotte)</option>
                                    <option data-country-code="MX" value="+52"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+52') echo 'selected'; ?>>
                                        +52 (Mexico)</option>
                                    <option data-country-code="FM" value="+691"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+691') echo 'selected'; ?>>
                                        +691 (Micronesia)</option>
                                    <option data-country-code="MD" value="+373"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+373') echo 'selected'; ?>>
                                        +373 (Moldova)</option>
                                    <option data-country-code="MC" value="+377"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+377') echo 'selected'; ?>>
                                        +377 (Monaco)</option>
                                    <option data-country-code="MN" value="+976"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+976') echo 'selected'; ?>>
                                        +976 (Mongolia)</option>
                                    <option data-country-code="ME" value="+382"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+382') echo 'selected'; ?>>
                                        +382 (Montenegro)</option>
                                    <option data-country-code="MS" value="+1-664"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-664') echo 'selected'; ?>>
                                        +1-664 (Montserrat)</option>
                                    <option data-country-code="MA" value="+212"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+212') echo 'selected'; ?>>
                                        +212 (Morocco)</option>
                                    <option data-country-code="MZ" value="+258"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+258') echo 'selected'; ?>>
                                        +258 (Mozambique)</option>
                                    <option data-country-code="MM" value="+95"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+95') echo 'selected'; ?>>
                                        +95 (Myanmar)</option>
                                    <option data-country-code="NA" value="+264"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+264') echo 'selected'; ?>>
                                        +264 (Namibia)</option>
                                    <option data-country-code="NR" value="+674"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+674') echo 'selected'; ?>>
                                        +674 (Nauru)</option>
                                    <option data-country-code="NP" value="+977"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+977') echo 'selected'; ?>>
                                        +977 (Nepal)</option>
                                    <option data-country-code="NL" value="+31"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+31') echo 'selected'; ?>>
                                        +31 (Netherlands)</option>
                                    <option data-country-code="NC" value="+687"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+687') echo 'selected'; ?>>
                                        +687 (New Caledonia)</option>
                                    <option data-country-code="NZ" value="+64"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+64') echo 'selected'; ?>>
                                        +64 (New Zealand)</option>
                                    <option data-country-code="NI" value="+505"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+505') echo 'selected'; ?>>
                                        +505 (Nicaragua)</option>
                                    <option data-country-code="NE" value="+227"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+227') echo 'selected'; ?>>
                                        +227 (Niger)</option>
                                    <option data-country-code="NG" value="+234"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+234') echo 'selected'; ?>>
                                        +234 (Nigeria)</option>
                                    <option data-country-code="NU" value="+683"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+683') echo 'selected'; ?>>
                                        +683 (Niue)</option>
                                    <option data-country-code="NF" value="+672"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+672') echo 'selected'; ?>>
                                        +672 (Norfolk Island)</option>
                                    <option data-country-code="KP" value="+850"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+850') echo 'selected'; ?>>
                                        +850 (North Korea)</option>
                                    <option data-country-code="MP" value="+1-670"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-670') echo 'selected'; ?>>
                                        +1-670 (Northern Mariana Islands)</option>
                                    <option data-country-code="NO" value="+47"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+47') echo 'selected'; ?>>
                                        +47 (Norway)</option>
                                    <option data-country-code="OM" value="+968"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+968') echo 'selected'; ?>>
                                        +968 (Oman)</option>
                                    <option data-country-code="PW" value="+680"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+680') echo 'selected'; ?>>
                                        +680 (Palau)</option>
                                    <option data-country-code="PS" value="+970"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+970') echo 'selected'; ?>>
                                        +970 (Palestine)</option>
                                    <option data-country-code="PA" value="+507"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+507') echo 'selected'; ?>>
                                        +507 (Panama)</option>
                                    <option data-country-code="PG" value="+675"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+675') echo 'selected'; ?>>
                                        +675 (Papua New Guinea)</option>
                                    <option data-country-code="PY" value="+595"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+595') echo 'selected'; ?>>
                                        +595 (Paraguay)</option>
                                    <option data-country-code="PE" value="+51"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+51') echo 'selected'; ?>>
                                        +51 (Peru)</option>
                                    <option data-country-code="PH" value="+63"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+63') echo 'selected'; ?>>
                                        +63 (Philippines)</option>
                                    <option data-country-code="PN" value="+64"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+64') echo 'selected'; ?>>
                                        +64 (Pitcairn)</option>
                                    <option data-country-code="PL" value="+48"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+48') echo 'selected'; ?>>
                                        +48 (Poland)</option>
                                    <option data-country-code="PT" value="+351"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+351') echo 'selected'; ?>>
                                        +351 (Portugal)</option>
                                    <option data-country-code="PR" value="+1-787"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-787') echo 'selected'; ?>>
                                        +1-787 (Puerto Rico)</option>
                                    <option data-country-code="QA" value="+974"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+974') echo 'selected'; ?>>
                                        +974 (Qatar)</option>
                                    <option data-country-code="RE" value="+262"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+262') echo 'selected'; ?>>
                                        +262 (Reunion)</option>
                                    <option data-country-code="RO" value="+40"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+40') echo 'selected'; ?>>
                                        +40 (Romania)</option>
                                    <option data-country-code="RU" value="+7"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+7') echo 'selected'; ?>>
                                        +7 (Russia)</option>
                                    <option data-country-code="RW" value="+250"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+250') echo 'selected'; ?>>
                                        +250 (Rwanda)</option>
                                    <option data-country-code="BL" value="+590"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+590') echo 'selected'; ?>>
                                        +590 (Saint Barthelemy)</option>
                                    <option data-country-code="SH" value="+290"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+290') echo 'selected'; ?>>
                                        +290 (Saint Helena)</option>
                                    <option data-country-code="KN" value="+1-869"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-869') echo 'selected'; ?>>
                                        +1-869 (Saint Kitts and Nevis)</option>
                                    <option data-country-code="LC" value="+1-758"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-758') echo 'selected'; ?>>
                                        +1-758 (Saint Lucia)</option>
                                    <option data-country-code="MF" value="+590"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+590') echo 'selected'; ?>>
                                        +590 (Saint Martin)</option>
                                    <option data-country-code="PM" value="+508"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+508') echo 'selected'; ?>>
                                        +508 (Saint Pierre and Miquelon)</option>
                                    <option data-country-code="VC" value="+1-784"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-784') echo 'selected'; ?>>
                                        +1-784 (Saint Vincent and the Grenadines)</option>
                                    <option data-country-code="WS" value="+685"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+685') echo 'selected'; ?>>
                                        +685 (Samoa)</option>
                                    <option data-country-code="SM" value="+378"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+378') echo 'selected'; ?>>
                                        +378 (San Marino)</option>
                                    <option data-country-code="ST" value="+239"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+239') echo 'selected'; ?>>
                                        +239 (Sao Tome and Principe)</option>
                                    <option data-country-code="SA" value="+966"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+966') echo 'selected'; ?>>
                                        +966 (Saudi Arabia)</option>
                                    <option data-country-code="SN" value="+221"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+221') echo 'selected'; ?>>
                                        +221 (Senegal)</option>
                                    <option data-country-code="RS" value="+381"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+381') echo 'selected'; ?>>
                                        +381 (Serbia)</option>
                                    <option data-country-code="SC" value="+248"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+248') echo 'selected'; ?>>
                                        +248 (Seychelles)</option>
                                    <option data-country-code="SL" value="+232"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+232') echo 'selected'; ?>>
                                        +232 (Sierra Leone)</option>
                                    <option data-country-code="SG" value="+65"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+65') echo 'selected'; ?>>
                                        +65 (Singapore)</option>
                                    <option data-country-code="SX" value="+1-721"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-721') echo 'selected'; ?>>
                                        +1-721 (Sint Maarten)</option>
                                    <option data-country-code="SK" value="+421"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+421') echo 'selected'; ?>>
                                        +421 (Slovakia)</option>
                                    <option data-country-code="SI" value="+386"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+386') echo 'selected'; ?>>
                                        +386 (Slovenia)</option>
                                    <option data-country-code="SB" value="+677"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+677') echo 'selected'; ?>>
                                        +677 (Solomon Islands)</option>
                                    <option data-country-code="SO" value="+252"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+252') echo 'selected'; ?>>
                                        +252 (Somalia)</option>
                                    <option data-country-code="ZA" value="+27"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+27') echo 'selected'; ?>>
                                        +27 (South Africa)</option>
                                    <option data-country-code="KR" value="+82"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+82') echo 'selected'; ?>>
                                        +82 (South Korea)</option>
                                    <option data-country-code="SS" value="+211"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+211') echo 'selected'; ?>>
                                        +211 (South Sudan)</option>
                                    <option data-country-code="ES" value="+34"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+34') echo 'selected'; ?>>
                                        +34 (Spain)</option>
                                    <option data-country-code="LK" value="+94"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+94') echo 'selected'; ?>>
                                        +94 (Sri Lanka)</option>
                                    <option data-country-code="SD" value="+249"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+249') echo 'selected'; ?>>
                                        +249 (Sudan)</option>
                                    <option data-country-code="SR" value="+597"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+597') echo 'selected'; ?>>
                                        +597 (Suriname)</option>
                                    <option data-country-code="SJ" value="+47"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+47') echo 'selected'; ?>>
                                        +47 (Svalbard and Jan Mayen)</option>
                                    <option data-country-code="SZ" value="+268"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+268') echo 'selected'; ?>>
                                        +268 (Swaziland)</option>
                                    <option data-country-code="SE" value="+46"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+46') echo 'selected'; ?>>
                                        +46 (Sweden)</option>
                                    <option data-country-code="CH" value="+41"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+41') echo 'selected'; ?>>
                                        +41 (Switzerland)</option>
                                    <option data-country-code="SY" value="+963"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+963') echo 'selected'; ?>>
                                        +963 (Syria)</option>
                                    <option data-country-code="TW" value="+886"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+886') echo 'selected'; ?>>
                                        +886 (Taiwan)</option>
                                    <option data-country-code="TJ" value="+992"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+992') echo 'selected'; ?>>
                                        +992 (Tajikistan)</option>
                                    <option data-country-code="TZ" value="+255"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+255') echo 'selected'; ?>>
                                        +255 (Tanzania)</option>
                                    <option data-country-code="TH" value="+66"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+66') echo 'selected'; ?>>
                                        +66 (Thailand)</option>
                                    <option data-country-code="TL" value="+670"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+670') echo 'selected'; ?>>
                                        +670 (Timor-Leste)</option>
                                    <option data-country-code="TG" value="+228"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+228') echo 'selected'; ?>>
                                        +228 (Togo)</option>
                                    <option data-country-code="TK" value="+690"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+690') echo 'selected'; ?>>
                                        +690 (Tokelau)</option>
                                    <option data-country-code="TO" value="+676"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+676') echo 'selected'; ?>>
                                        +676 (Tonga)</option>
                                    <option data-country-code="TT" value="+1-868"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-868') echo 'selected'; ?>>
                                        +1-868 (Trinidad and Tobago)</option>
                                    <option data-country-code="TN" value="+216"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+216') echo 'selected'; ?>>
                                        +216 (Tunisia)</option>
                                    <option data-country-code="TR" value="+90"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+90') echo 'selected'; ?>>
                                        +90 (Turkey)</option>
                                    <option data-country-code="TM" value="+993"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+993') echo 'selected'; ?>>
                                        +993 (Turkmenistan)</option>
                                    <option data-country-code="TC" value="+1-649"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-649') echo 'selected'; ?>>
                                        +1-649 (Turks and Caicos Islands)</option>
                                    <option data-country-code="TV" value="+688"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+688') echo 'selected'; ?>>
                                        +688 (Tuvalu)</option>
                                    <option data-country-code="UG" value="+256"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+256') echo 'selected'; ?>>
                                        +256 (Uganda)</option>
                                    <option data-country-code="UA" value="+380"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+380') echo 'selected'; ?>>
                                        +380 (Ukraine)</option>
                                    <option data-country-code="AE" value="+971"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+971') echo 'selected'; ?>>
                                        +971 (United Arab Emirates)</option>
                                    <option data-country-code="GB" value="+44"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+44') echo 'selected'; ?>>
                                        +44 (United Kingdom)</option>
                                    <option data-country-code="US" value="+1"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1') echo 'selected'; ?>>
                                        +1 (United States)</option>
                                    <option data-country-code="UY" value="+598"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+598') echo 'selected'; ?>>
                                        +598 (Uruguay)</option>
                                    <option data-country-code="UZ" value="+998"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+998') echo 'selected'; ?>>
                                        +998 (Uzbekistan)</option>
                                    <option data-country-code="VU" value="+678"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+678') echo 'selected'; ?>>
                                        +678 (Vanuatu)</option>
                                    <option data-country-code="VA" value="+379"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+379') echo 'selected'; ?>>
                                        +379 (Vatican City)</option>
                                    <option data-country-code="VE" value="+58"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+58') echo 'selected'; ?>>
                                        +58 (Venezuela)</option>
                                    <option data-country-code="VN" value="+84"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+84') echo 'selected'; ?>>
                                        +84 (Vietnam)</option>
                                    <option data-country-code="VI" value="+1-340"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+1-340') echo 'selected'; ?>>
                                        +1-340 (Virgin Islands, U.S.)</option>
                                    <option data-country-code="WF" value="+681"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+681') echo 'selected'; ?>>
                                        +681 (Wallis and Futuna)</option>
                                    <option data-country-code="EH" value="+212"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+212') echo 'selected'; ?>>
                                        +212 (Western Sahara)</option>
                                    <option data-country-code="YE" value="+967"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+967') echo 'selected'; ?>>
                                        +967 (Yemen)</option>
                                    <option data-country-code="ZM" value="+260"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+260') echo 'selected'; ?>>
                                        +260 (Zambia)</option>
                                    <option data-country-code="ZW" value="+263"
                                        <?php if (isset($_SESSION['country_code']) && $_SESSION['country_code'] == '+263') echo 'selected'; ?>>
                                        +263 (Zimbabwe)</option>
                                </select>
                            </div>
                        </div>

                        <!-- Conditional Mobile Number Field -->
                        <div id="mobile_div" class="mb-3 conditional-field">
                            <label for="mobile" class="form-label">Mobile Number</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-mobile-alt"></i></span>
                                <input type="tel" name="mobile" id="mobile" placeholder="Enter 10-digit number"
                                    class="form-control" pattern="\d{10}" title="Enter a valid 10-digit number"
                                    value="<?php echo htmlspecialchars($_SESSION['mobile'] ?? ''); ?>">
                            </div>
                        </div>

                        <!-- Conditional Email Field -->
                        <div id="email_div" class="mb-3 conditional-field">
                            <label for="email" class="form-label">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input type="email" name="email" id="email" placeholder="you@example.com"
                                    class="form-control"
                                    value="<?php echo htmlspecialchars($_SESSION['email'] ?? ''); ?>">
                            </div>
                        </div>

                        <div class="d-grid mt-4">
                            <button type="submit" class="btn btn-primary btn-lg">
                                Proceed <i class="fas fa-paper-plane ms-2"></i>
                            </button>
                        </div>
                    </form>

                    <div class="text-center mt-4 d-flex justify-content-center gap-2 ">
                        <a href="../../../reg_guid.html" class="btn btn-sm btn-outline-dark text-bg-success">
                            Registration Guide <i class="fas fa-book-open ms-2"></i>
                        </a>
                        <a href="../index.php" class="btn btn-sm btn-outline-success text-bg-danger">
                            Login <i class="fas fa-sign-in-alt ms-2"></i>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <script>
    function updateFormForCountry() {
        const countrySelect = document.getElementById('country_code');
        const mobileDiv = document.getElementById('mobile_div');
        const emailDiv = document.getElementById('email_div');
        const mobileInput = document.getElementById('mobile');
        const emailInput = document.getElementById('email');

        // Set hidden country name input
        const selectedOption = countrySelect.options[countrySelect.selectedIndex];
        if (selectedOption && selectedOption.value) {
            // Extract name from text like "+91 (India)" -> "India"
            const countryNameMatch = selectedOption.text.match(/\(([^)]+)\)/);
            document.getElementById('country_name').value = countryNameMatch ? countryNameMatch[1].trim() :
                selectedOption.text.trim();
        }

        if (countrySelect.value === '+91') {
            // Show Mobile, Hide Email
            mobileDiv.classList.add('visible');
            emailDiv.classList.remove('visible');
            mobileInput.required = true;
            emailInput.required = false;
            emailInput.value = ''; // Clear other field
        } else if (countrySelect.value) {
            // Show Email, Hide Mobile
            mobileDiv.classList.remove('visible');
            emailDiv.classList.add('visible');
            mobileInput.required = false;
            emailInput.required = true;
            mobileInput.value = ''; // Clear other field
        } else {
            // Hide both if no country is selected
            mobileDiv.classList.remove('visible');
            emailDiv.classList.remove('visible');
            mobileInput.required = false;
            emailInput.required = false;
        }
    }

    // Function to filter country options based on search input
    function filterCountries() {
        const searchInput = document.getElementById('country_search');
        const select = document.getElementById('country_code');
        const filter = searchInput.value.toLowerCase();
        const options = select.options;

        for (let i = 0; i < options.length; i++) {
            const option = options[i];
            const text = option.text.toLowerCase();
            if (text.includes(filter) || i === 0) { // Always show the first option
                option.style.display = '';
            } else {
                option.style.display = 'none';
            }
        }
    }

    // Run on page load to set the initial state based on any pre-filled data
    document.addEventListener('DOMContentLoaded', function() {
        updateFormForCountry();
        // Add event listener for search input
        document.getElementById('country_search').addEventListener('input', filterCountries);
    });
    </script>
</body>

</html>