<?php
session_start();

// Redirect to the first page if the user hasn't completed the initial step.
if (!isset($_SESSION['country_code']) || $_SESSION['country_code'] !== '+91') {
    header("Location: index.php");
    exit();
}

// Get the mobile number from the session to pre-fill the form field.
$mobileNo = isset($_SESSION['mobile']) ? htmlspecialchars($_SESSION['mobile']) : '';

// A helper function to generate Roman numerals for grades.
function romanNumeral($num) {
    $map = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];
    return $map[$num - 1] ?? $num;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration - Olympiad Examination Council</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons for visual cues -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        /* --- Google Font --- */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap');

        /* --- Custom CSS Variables for a Classy Glassmorphic Theme --- */
        :root {
            --primary-color: #8A2BE2; /* A vibrant purple */
            --secondary-color: #FF1493; /* Deep Pink for contrast */
            --success-color: #20c997;
            --background-gradient: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
            --form-background: rgba(255, 255, 255, 0.1);
            --text-color: #f0f0f0;
            --muted-text-color: #a0a0c0;
            --border-color: rgba(255, 255, 255, 0.2);
            --shadow-color: rgba(0, 0, 0, 0.3);
            --transition-speed: 0.4s;
        }

        /* --- General Body & Container Styling --- */
        body {
            background-image: var(--background-gradient);
            font-family: 'Poppins', sans-serif;
            color: var(--text-color);
            line-height: 1.6;
            background-attachment: fixed;
        }

        .form-container {
            background: var(--form-background);
            padding: 2.5rem 3rem;
            border-radius: 1.5rem;
            box-shadow: 0 8px 32px 0 var(--shadow-color);
            margin-top: 2rem;
            margin-bottom: 2rem;
            border: 1px solid rgba(255, 255, 255, 0.18);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            animation: form-load-animation 0.8s ease-out;
        }
        
        @keyframes form-load-animation {
            from {
                opacity: 0;
                transform: translateY(30px) scale(0.98);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        /* --- Header Styling --- */
        .form-container h1 {
            background: linear-gradient(45deg, #fbc2eb 0%, #a6c1ee 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 700;
        }
        
        .form-container .text-muted {
            color: var(--muted-text-color) !important;
        }

        /* --- Animated Wizard Progress Bar --- */
        .progress-bar-container {
            display: flex;
            justify-content: space-between;
            counter-reset: step;
            margin-bottom: 3rem;
            position: relative;
        }
        .progress-bar-container::before {
            content: '';
            position: absolute;
            top: 14px;
            left: 0;
            width: 100%;
            height: 2px;
            background-color: var(--border-color);
            z-index: -2;
        }
        .progress-bar-container .step {
            width: 100%;
            text-align: center;
            position: relative;
        }
        .progress-bar-container .step::before {
            content: counter(step);
            counter-increment: step;
            width: 30px;
            height: 30px;
            line-height: 28px;
            border: 2px solid var(--border-color);
            display: block;
            text-align: center;
            margin: 0 auto 10px auto;
            border-radius: 50%;
            background-color: transparent;
            color: var(--muted-text-color);
            transition: all var(--transition-speed) ease;
            transform: scale(1);
        }
        .progress-bar-container .step::after {
            content: '';
            width: 0;
            height: 2px;
            background-image: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            position: absolute;
            left: -50%;
            top: 14px;
            z-index: -1;
            transition: width var(--transition-speed) ease;
        }
        .progress-bar-container .step:first-child::after {
            content: none;
        }
        .progress-bar-container .step.active::before {
            border-color: var(--primary-color);
            background-image: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            color: white;
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(138, 43, 226, 0.5);
        }
        .progress-bar-container .step.active + .step::after {
            width: 100%;
        }
        .step-label {
            font-size: 0.85rem;
            color: var(--muted-text-color);
            transition: all var(--transition-speed) ease;
        }
        .step.active .step-label {
            color: var(--text-color);
            font-weight: 500;
        }

        /* --- Form Step Animation --- */
        .form-step {
            display: none;
            animation: step-animation 0.6s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }
        .form-step.active {
            display: block;
        }
        @keyframes step-animation {
            from { opacity: 0; transform: translateX(50px); }
            to { opacity: 1; transform: translateX(0); }
        }

        /* --- Form Input & Select Styling --- */
        .form-control, .form-select {
            border-radius: 0.5rem;
            transition: all 0.3s ease-in-out;
            border: 1px solid var(--border-color);
            background-color: rgba(0, 0, 0, 0.2);
            color: var(--text-color);
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            background-color: rgba(0, 0, 0, 0.3);
            color: var(--text-color);
            box-shadow: 0 0 0 4px rgba(138, 43, 226, 0.25);
        }
        .form-control::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */
            color: var(--muted-text-color);
            opacity: 1; /* Firefox */
        }
        .form-select option {
            background: #202040;
            color: var(--text-color);
        }
        .form-control:disabled, .form-select:disabled {
            background-color: rgba(0, 0, 0, 0.4);
            opacity: 0.7;
        }
        .form-label {
            font-weight: 400;
            color: var(--muted-text-color);
        }
        
        /* --- Navigation Button Styling --- */
        .btn {
            border-radius: 0.5rem;
            padding: 0.75rem 1.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
            border: none;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .btn i {
            margin: 0 0.25rem;
            font-size: 0.9em;
        }
        .btn-primary {
            background-image: linear-gradient(45deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            box-shadow: 0 4px 15px 0 rgba(255, 20, 147, 0.4);
        }
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 7px 20px 0 rgba(255, 20, 147, 0.5);
        }
        .btn-secondary {
            background-color: rgba(255, 255, 255, 0.15);
            color: var(--text-color);
        }
        .btn-secondary:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
        .btn-success {
            background-color: var(--success-color);
            box-shadow: 0 4px 15px 0 rgba(32, 201, 151, 0.4);
        }
        .btn-success:hover {
             transform: translateY(-3px);
             box-shadow: 0 7px 20px 0 rgba(32, 201, 151, 0.5);
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-xl-9">
                
                <div class="form-container">
                    <!-- Header -->
                    <div class="text-center mb-5">
                        <img src="img/oecfavicon.png" alt="OEC Logo" style="width: 64px; height: 64px;" class="mx-auto mb-3">
                        <h1 class="h3 fw-bold">Student Registration</h1>
                        <p class="text-muted">Follow the steps to complete your registration.</p>
                    </div>

                    <!-- Progress Bar -->
                    <div class="progress-bar-container">
                        <div class="step active"><div class="step-label">Personal</div></div>
                        <div class="step"><div class="step-label">Contact</div></div>
                        <div class="step"><div class="step-label">Academic</div></div>
                        <div class="step"><div class="step-label">Password</div></div>
                    </div>

                    <form id="registrationForm" action="submit.php" method="post" class="needs-validation" novalidate>
                        
                        <!-- Step 1: Personal Information -->
                        <div class="form-step active">
                            <h5 class="mb-4 text-center">Personal Information</h5>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="Stud_name" class="form-label">Student Name</label>
                                    <input type="text" class="form-control" id="Stud_name" name="Stud_name" required>
                                    <div class="invalid-feedback">Please enter the student's name.</div>
                                </div>
                                <div class="col-md-6">
                                    <label for="Parent_name" class="form-label">Parent Name</label>
                                    <input type="text" class="form-control" id="Parent_name" name="Parent_name" required>
                                    <div class="invalid-feedback">Please enter the parent's name.</div>
                                </div>
                                <div class="col-md-6">
                                    <label for="Stud_dob" class="form-label">Date of Birth</label>
                                    <input type="date" class="form-control" id="Stud_dob" name="Stud_dob" required>
                                     <div class="invalid-feedback">Please select a valid date of birth.</div>
                                </div>
                                <div class="col-md-6">
                                    <label for="Gender" class="form-label">Gender</label>
                                    <select class="form-select" id="Gender" name="Gender" required>
                                        <option value="" disabled selected>-- Select Gender --</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Other">Other</option>
                                    </select>
                                    <div class="invalid-feedback">Please select a gender.</div>
                                </div>
                            </div>
                        </div>

                        <!-- Step 2: Contact Information -->
                        <div class="form-step">
                            <h5 class="mb-4 text-center">Contact Information</h5>
                            <div class="row g-3">
                                <div class="col-12">
                                    <label for="Home_addr" class="form-label">Address</label>
                                    <textarea class="form-control" id="Home_addr" name="Home_addr" rows="2" required></textarea>
                                    <div class="invalid-feedback">Please enter your address.</div>
                                </div>
                                <div class="col-md-6">
                                    <label for="S_State" class="form-label">State</label>
                                    <select class="form-select" id="S_State" name="S_State" required>
                                        <option value="" disabled selected>-- Select State --</option>
                                        <option value="AndraPradesh">Andhra Pradesh</option>
                                        <option value="ArunachalPradesh">Arunachal Pradesh</option>
                                        <option value="Assam">Assam</option>
                                        <option value="Bihar">Bihar</option>
                                        <option value="Chhattisgarh">Chhattisgarh</option>
                                        <option value="Goa">Goa</option>
                                        <option value="Gujarat">Gujarat</option>
                                        <option value="Haryana">Haryana</option>
                                        <option value="HimachalPradesh">Himachal Pradesh</option>
                                        <option value="JammuKashmir">Jammu and Kashmir</option>
                                        <option value="Jharkhand">Jharkhand</option>
                                        <option value="Karnataka">Karnataka</option>
                                        <option value="Kerala">Kerala</option>
                                        <option value="MadhyaPradesh">Madhya Pradesh</option>
                                        <option value="Maharashtra">Maharashtra</option>
                                        <option value="Manipur">Manipur</option>
                                        <option value="Meghalaya">Meghalaya</option>
                                        <option value="Mizoram">Mizoram</option>
                                        <option value="Nagaland">Nagaland</option>
                                        <option value="Odisha">Odisha</option>
                                        <option value="Punjab">Punjab</option>
                                        <option value="Rajasthan">Rajasthan</option>
                                        <option value="Sikkim">Sikkim</option>
                                        <option value="TamilNadu">Tamil Nadu</option>
                                        <option value="Telangana">Telangana</option>
                                        <option value="Tripura">Tripura</option>
                                        <option value="Uttarakhand">Uttarakhand</option>
                                        <option value="UttarPradesh">Uttar Pradesh</option>
                                        <option value="WestBengal">West Bengal</option>
                                        <option disabled style="background-color:#e9ecef;">--- UNION Territories ---</option>   
                                        <option value="Delhi">Delhi</option>
                                        <option value="Chandigarh">Chandigarh</option>
                                        <option value="Puducherry">Puducherry</option>
                                    </select>
                                    <div class="invalid-feedback">Please select a state.</div>
                                </div>
                                <div class="col-md-6">
                                    <label for="District" class="form-label">District</label>
                                    <select class="form-select" id="District" name="District" required>
                                        <option value="" disabled selected>-- Select State First --</option>
                                    </select>
                                    <div class="invalid-feedback">Please select a district.</div>
                                </div>
                                <div class="col-md-6">
                                    <label for="MobileNo" class="form-label">Mobile No</label>
                                    <input type="tel" class="form-control" id="MobileNo" name="MobileNo" required pattern="[0-9]{10}" title="Enter 10 digit mobile number" value="<?php echo $mobileNo; ?>">
                                    <div class="invalid-feedback">Please enter a valid 10-digit mobile number.</div>
                                </div>
                                <div class="col-md-6">
                                    <label for="WhatsAppNo" class="form-label">WhatsApp No</label>
                                    <input type="tel" class="form-control" id="WhatsAppNo" name="WhatsAppNo" required pattern="[0-9]{10}" title="Enter 10 digit mobile number">
                                    <div class="invalid-feedback">Please enter a valid 10-digit WhatsApp number.</div>
                                </div>
                                <div class="col-12">
                                    <label for="Email_ID" class="form-label">Email (Optional)</label>
                                    <input type="email" class="form-control" id="Email_ID" name="Email_ID">
                                </div>
                            </div>
                        </div>

                        <!-- Step 3: Academic Information -->
                        <div class="form-step">
                             <h5 class="mb-4 text-center">Academic Information</h5>
                             <div class="row g-3">
                                <div class="col-12">
                                    <label for="S_Cname" class="form-label">School/College Name</label>
                                    <input type="text" class="form-control" id="S_Cname" name="S_Cname" required>
                                    <div class="invalid-feedback">Please enter the school/college name.</div>
                                </div>
                                <div class="col-12">
                                    <label for="S_Caddr" class="form-label">School/College Address</label>
                                    <textarea class="form-control" id="S_Caddr" name="S_Caddr" rows="2" required></textarea>
                                    <div class="invalid-feedback">Please enter the school/college address.</div>
                                </div>
                                <div class="col-md-6">
                                    <label for="S_Cat" class="form-label">School Category</label>
                                    <select class="form-select" id="S_Cat" name="S_Cat" required>
                                        <option value="" disabled selected>-- Select Category --</option>
                                        <option value="State Board">State Board</option>
                                        <option value="CBSE">CBSE</option>
                                        <option value="ICSE">ICSE</option>
                                        <option value="IB">IB</option>
                                        <option value="IGSCE">IGSCE</option>
                                        <option value="CISCE">CISCE</option>
                                        <option value="CIE">CIE</option>


                                    </select>
                                    <div class="invalid-feedback">Please select a category.</div>
                                </div>
                                <div class="col-md-6">
                                    <label for="Grade" class="form-label">Grade</label>
                                    <select class="form-select" id="Grade" name="Grade" required>
                                        <option value="" disabled selected>-- Select Grade --</option>
                                        <?php
                                        for ($i = 1; $i <= 12; $i++) {
                                            echo "<option value=\"$i\">Grade " . romanNumeral($i) . "</option>";
                                        }
                                        ?>
                                    </select>
                                    <div class="invalid-feedback">Please select a grade.</div>
                                </div>
                                <div class="col-md-6">
                                    <label for="Exam_Lg" class="form-label">Exam Language</label>
                                    <select class="form-select" id="Exam_Lg" name="Exam_Lg" required>
                                        <option value="" disabled selected>-- Select Language --</option>
                                        <option value="English">English</option>
                                        <option value="Marathi">Marathi</option>
                                        <option value="Kannada">Kannada</option>
                                        <option value="Gujarati">Gujarati</option>
                                    </select>
                                    <div class="invalid-feedback">Please select a language.</div>
                                </div>
                                <div class="col-md-6">
                                    <label for="C_Branch" class="form-label">Branch (for Grade 11/12)</label>
                                    <select class="form-select" id="C_Branch" name="C_Branch" required>
                                        <option value="">-- Select Branch --</option>
                                        <option value="Not Applicable">Not Applicable</option>
                                        <option value="Science">Science</option>
                                        <option value="Commerce">Commerce</option>
                                        <option value="Arts">Arts</option>
                                    </select>
                                     <div class="invalid-feedback">Please select a branch.</div>
                                </div>
                            </div>
                        </div>

                        <!-- Step 4: Set Password -->
                        <div class="form-step">
                            <h5 class="mb-4 text-center">Set Your Password</h5>
                            <div class="row g-3 justify-content-center">
                                <div class="col-md-8">
                                    <label for="S_Pass" class="form-label">Password</label>
                                    <input type="password" class="form-control" id="S_Pass" name="S_Pass" required>
                                    <div class="invalid-feedback">Please enter a password.</div>
                                </div>
                                <div class="col-md-8">
                                    <label for="S_ConfirmPass" class="form-label">Confirm Password</label>
                                    <input type="password" class="form-control" id="S_ConfirmPass" name="S_ConfirmPass" required>
                                    <div class="invalid-feedback">Passwords do not match.</div>
                                </div>
                            </div>
                        </div>

                        <!-- Navigation Buttons -->
                        <div class="d-flex justify-content-between mt-5">
                            <button type="button" class="btn btn-secondary" id="prevBtn" style="display: none;"><i class="bi bi-arrow-left"></i> Previous</button>
                            <button type="button" class="btn btn-primary" id="nextBtn">Next <i class="bi bi-arrow-right"></i></button>
                            <button type="submit" class="btn btn-success" id="submitBtn" style="display: none;"><i class="bi bi-check-lg"></i> Submit Registration</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // --- Element References ---
            const form = document.getElementById('registrationForm');
            const steps = Array.from(document.querySelectorAll('.form-step'));
            const progressSteps = Array.from(document.querySelectorAll('.progress-bar-container .step'));
            const nextBtn = document.getElementById('nextBtn');
            const prevBtn = document.getElementById('prevBtn');
            const submitBtn = document.getElementById('submitBtn');
            
            let currentStep = 0;

            // --- Wizard Navigation Logic ---
            nextBtn.addEventListener('click', () => {
                if (validateStep(currentStep)) {
                    if (currentStep < steps.length - 1) {
                        currentStep++;
                        updateFormSteps();
                    }
                }
            });

            prevBtn.addEventListener('click', () => {
                if (currentStep > 0) {
                    currentStep--;
                    updateFormSteps();
                }
            });

            function updateFormSteps() {
                steps.forEach((step, index) => {
                    step.classList.toggle('active', index === currentStep);
                });

                progressSteps.forEach((step, index) => {
                    if (index < currentStep + 1) {
                        step.classList.add('active');
                    } else {
                        step.classList.remove('active');
                    }
                });

                prevBtn.style.display = currentStep > 0 ? 'inline-block' : 'none';
                nextBtn.style.display = currentStep < steps.length - 1 ? 'inline-block' : 'none';
                submitBtn.style.display = currentStep === steps.length - 1 ? 'inline-block' : 'none';
            }

            function validateStep(stepIndex) {
                let isValid = true;
                const currentStepInputs = steps[stepIndex].querySelectorAll('input[required], select[required], textarea[required]');
                
                currentStepInputs.forEach(input => {
                    if (!input.checkValidity()) {
                        input.classList.add('is-invalid');
                        isValid = false;
                    } else {
                        input.classList.remove('is-invalid');
                    }
                });
                
                // Special password match validation for the last step
                if (stepIndex === steps.length - 1) {
                    const passInput = document.getElementById('S_Pass');
                    const confirmPassInput = document.getElementById('S_ConfirmPass');
                     if (passInput.value !== confirmPassInput.value) {
                         confirmPassInput.classList.add('is-invalid');
                         isValid = false;
                     } else {
                         confirmPassInput.classList.remove('is-invalid');
                     }
                }

                return isValid;
            }

            form.addEventListener('submit', function(e) {
                if (!validateStep(currentStep)) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                // Handle branch select logic before final submission
                manageBranchSelectOnSubmit();
            });


            // --- Existing Form Logic Integration ---
            const stateSelect = document.getElementById('S_State');
            const districtSelect = document.getElementById('District');
            const gradeSelect = document.getElementById('Grade');
            const branchSelect = document.getElementById('C_Branch');

            const districtData = {
                AndraPradesh: ["Anantapur", "Chittoor", "East Godavari", "Guntur", "Kadapa", "Krishna", "Kurnool", "Prakasam", "Nellore", "Srikakulam", "Visakhapatnam", "Vizianagaram", "West Godavari"],
                ArunachalPradesh: ["Anjaw", "Changlang", "Dibang Valley", "East Kameng", "East Siang", "Kra Daadi", "Kurung Kumey", "Lohit", "Longding", "Lower Dibang Valley", "Lower Subansiri", "Namsai", "Papum Pare", "Siang", "Tawang", "Tirap", "Upper Siang", "Upper Subansiri", "West Kameng", "West Siang", "Itanagar"],
                Assam: ["Baksa", "Barpeta", "Biswanath", "Bongaigaon", "Cachar", "Charaideo", "Chirang", "Darrang", "Dhemaji", "Dhubri", "Dibrugarh", "Goalpara", "Golaghat", "Hailakandi", "Hojai", "Jorhat", "Kamrup Metropolitan", "Kamrup (Rural)", "Karbi Anglong", "Karimganj", "Kokrajhar", "Lakhimpur", "Majuli", "Morigaon", "Nagaon", "Nalbari", "Dima Hasao", "Sivasagar", "Sonitpur", "South Salmara Mankachar", "Tinsukia", "Udalguri", "West Karbi Anglong"],
                Bihar: ["Araria", "Arwal", "Aurangabad", "Banka", "Begusarai", "Bhagalpur", "Bhojpur", "Buxar", "Darbhanga", "East Champaran", "Gaya", "Gopalganj", "Jamui", "Jehanabad", "Kaimur", "Katihar", "Khagaria", "Kishanganj", "Lakhisarai", "Madhepura", "Madhubani", "Munger", "Muzaffarpur", "Nalanda", "Nawada", "Patna", "Purnia", "Rohtas", "Saharsa", "Samastipur", "Saran", "Sheikhpura", "Sheohar", "Sitamarhi", "Siwan", "Supaul", "Vaishali", "West Champaran"],
                Karnataka: ["Bagalkot", "Bangalore Rural", "Bangalore Urban", "Belgaum", "Bellary", "Bidar", "Vijayapura", "Chamarajanagar", "Chikkaballapur", "Chikkamagaluru", "Chitradurga", "Dakshina Kannada", "Davanagere", "Dharwad", "Gadag", "Gulbarga", "Hassan", "Haveri", "Kodagu", "Kolar", "Koppal", "Mandya", "Mysore", "Raichur", "Ramanagara", "Shimoga", "Tumkur", "Udupi", "Uttara Kannada", "Yadgir"],
                Delhi: ["Central Delhi", "East Delhi", "New Delhi", "North Delhi", "North East Delhi", "North West Delhi", "Shahdara", "South Delhi", "South East Delhi", "South West Delhi", "West Delhi"],
                Puducherry: ["Karaikal", "Mahe", "Puducherry", "Yanam"],
                Chhattisgarh: ["Balod", "Baloda Bazar", "Balrampur", "Bastar", "Bemetara", "Bijapur", "Bilaspur", "Dantewada", "Dhamtari", "Durg", "Gariaband", "Janjgir-Champa", "Jashpur", "Kabirdham", "Kanker", "Kondagaon", "Korba", "Koriya", "Mahasamund", "Mungeli", "Narayanpur", "Raigarh", "Raipur", "Rajnandgaon", "Sukma", "Surajpur", "Surguja"],
                Goa: ["North Goa", "South Goa"],
                Gujarat: ["Ahmedabad", "Amreli", "Anand", "Aravalli", "Banaskantha", "Bharuch", "Bhavnagar", "Botad", "Chhota Udaipur", "Dahod", "Dang", "Devbhoomi Dwarka", "Gandhinagar", "Gir Somnath", "Jamnagar", "Junagadh", "Kheda", "Kutch", "Mahisagar", "Mehsana", "Morbi", "Narmada", "Navsari", "Panchmahal", "Patan", "Porbandar", "Rajkot", "Sabarkantha", "Surat", "Surendranagar", "Tapi", "Vadodara", "Valsad"],
                Haryana: ["Ambala", "Bhiwani", "Charkhi Dadri", "Faridabad", "Fatehabad", "Gurugram", "Hisar", "Jhajjar", "Jind", "Kaithal", "Karnal", "Kurukshetra", "Mahendragarh", "Nuh", "Palwal", "Panchkula", "Panipat", "Rewari", "Rohtak", "Sirsa", "Sonipat", "Yamunanagar"],
                HimachalPradesh: ["Bilaspur", "Chamba", "Hamirpur", "Kangra", "Kinnaur", "Kullu", "Lahaul and Spiti", "Mandi", "Shimla", "Sirmaur", "Solan", "Una"],
                JammuKashmir: ["Anantnag", "Bandipora", "Baramulla", "Budgam", "Doda", "Ganderbal", "Jammu", "Kathua", "Kishtwar", "Kulgam", "Kupwara", "Poonch", "Pulwama", "Rajouri", "Ramban", "Reasi", "Samba", "Shopian", "Srinagar", "Udhampur"],
                Jharkhand: ["Bokaro", "Chatra", "Deoghar", "Dhanbad", "Dumka", "East Singhbhum", "Garhwa", "Giridih", "Godda", "Gumla", "Hazaribagh", "Jamtara", "Khunti", "Koderma", "Latehar", "Lohardaga", "Pakur", "Palamu", "Ramgarh", "Ranchi", "Sahibganj", "Seraikela Kharsawan", "Simdega", "West Singhbhum"],
                Kerala: ["Alappuzha", "Ernakulam", "Idukki", "Kannur", "Kasaragod", "Kollam", "Kottayam", "Kozhikode", "Malappuram", "Palakkad", "Pathanamthitta", "Thiruvananthapuram", "Thrissur", "Wayanad"],
                MadhyaPradesh: ["Agar Malwa", "Alirajpur", "Anuppur", "Ashoknagar", "Balaghat", "Barwani", "Betul", "Bhind", "Bhopal", "Burhanpur", "Chhatarpur", "Chhindwara", "Damoh", "Datia", "Dewas", "Dhar", "Dindori", "Guna", "Gwalior", "Harda", "Hoshangabad", "Indore", "Jabalpur", "Jhabua", "Katni", "Khandwa", "Khargone", "Mandla", "Mandsaur", "Morena", "Narsinghpur", "Neemuch", "Niwari", "Panna", "Raisen", "Rajgarh", "Ratlam", "Rewa", "Sagar", "Satna", "Sehore", "Seoni", "Shahdol", "Shajapur", "Sheopur", "Shivpuri", "Sidhi", "Singrauli", "Tikamgarh", "Ujjain", "Umaria", "Vidisha"],
                Maharashtra: ["Ahmednagar", "Akola", "Amravati", "Aurangabad", "Beed", "Bhandara", "Buldhana", "Chandrapur", "Dhule", "Gadchiroli", "Gondia", "Hingoli", "Jalgaon", "Jalna", "Kolhapur", "Latur", "Mumbai City", "Mumbai Suburban", "Nagpur", "Nanded", "Nandurbar", "Nashik", "Osmanabad", "Palghar", "Parbhani", "Pune", "Raigad", "Ratnagiri", "Sangli", "Satara", "Sindhudurg", "Solapur", "Thane", "Wardha", "Washim", "Yavatmal"],
                Manipur: ["Bishnupur", "Chandel", "Churachandpur", "Imphal East", "Imphal West", "Jiribam", "Kakching", "Kamjong", "Kangpokpi", "Noney", "Pherzawl", "Senapati", "Tamenglong", "Tengnoupal", "Thoubal", "Ukhrul"],
                Meghalaya: ["East Garo Hills", "East Jaintia Hills", "East Khasi Hills", "North Garo Hills", "Ri Bhoi", "South Garo Hills", "South West Garo Hills", "South West Khasi Hills", "West Garo Hills", "West Jaintia Hills", "West Khasi Hills"],
                Mizoram: ["Aizawl", "Champhai", "Kolasib", "Lawngtlai", "Lunglei", "Mamit", "Saiha", "Serchhip", "Hnahthial", "Khawzawl", "Saitual"],
                Nagaland: ["Dimapur", "Kiphire", "Kohima", "Longleng", "Mokokchung", "Mon", "Peren", "Phek", "Tuensang", "Wokha", "Zunheboto"],
                Odisha: ["Angul", "Balangir", "Balasore", "Bargarh", "Bhadrak", "Boudh", "Cuttack", "Deogarh", "Dhenkanal", "Gajapati", "Ganjam", "Jagatsinghpur", "Jajpur", "Jharsuguda", "Kalahandi", "Kandhamal", "Kendrapara", "Kendujhar", "Khordha", "Koraput", "Malkangiri", "Mayurbhanj", "Nabarangpur", "Nayagarh", "Nuapada", "Puri", "Rayagada", "Sambalpur", "Sonepur", "Sundargarh"],
                Punjab: ["Amritsar", "Barnala", "Bathinda", "Faridkot", "Fatehgarh Sahib", "Fazilka", "Ferozepur", "Gurdaspur", "Hoshiarpur", "Jalandhar", "Kapurthala", "Ludhiana", "Malerkotla", "Mansa", "Moga", "Mohali", "Muktsar", "Pathankot", "Patiala", "Rupnagar", "Sangrur", "Shaheed Bhagat Singh Nagar", "Tarn Taran"],
                Rajasthan: ["Ajmer", "Alwar", "Banswara", "Baran", "Barmer", "Bharatpur", "Bhilwara", "Bikaner", "Bundi", "Chittorgarh", "Churu", "Dausa", "Dholpur", "Dungarpur", "Hanumangarh", "Jaipur", "Jaisalmer", "Jalore", "Jhalawar", "Jhunjhunu", "Jodhpur", "Karauli", "Kota", "Nagaur", "Pali", "Pratapgarh", "Rajsamand", "Sawai Madhopur", "Sikar", "Sirohi", "Sri Ganganagar", "Tonk", "Udaipur"],
                Sikkim: ["East Sikkim", "North Sikkim", "South Sikkim", "West Sikkim", "Pakyong", "Soreng"],
                TamilNadu: ["Ariyalur", "Chengalpattu", "Chennai", "Coimbatore", "Cuddalore", "Dharmapuri", "Dindigul", "Erode", "Kallakurichi", "Kanchipuram", "Kanyakumari", "Karur", "Krishnagiri", "Madurai", "Mayiladuthurai", "Nagapattinam", "Namakkal", "Nilgiris", "Perambalur", "Pudukkottai", "Ramanathapuram", "Ranipet", "Salem", "Sivaganga", "Tenkasi", "Thanjavur", "Theni", "Thoothukudi", "Tiruchirappalli", "Tirunelveli", "Tirupathur", "Tiruppur", "Tiruvallur", "Tiruvannamalai", "Tiruvarur", "Vellore", "Viluppuram", "Virudhunagar"],
                Telangana: ["Adilabad", "Bhadradri Kothagudem", "Hyderabad", "Jagtial", "Jangaon", "Jayashankar Bhupalapally", "Jogulamba Gadwal", "Kamareddy", "Karimnagar", "Khammam", "Komaram Bheem", "Mahabubabad", "Mahabubnagar", "Mancherial", "Medak", "Medchal–Malkajgiri", "Mulugu", "Nagarkurnool", "Nalgonda", "Narayanpet", "Nirmal", "Nizamabad", "Peddapalli", "Rajanna Sircilla", "Ranga Reddy", "Sangareddy", "Siddipet", "Suryapet", "Vikarabad", "Wanaparthy", "Warangal Rural", "Warangal Urban", "Yadadri Bhuvanagiri"],
                Tripura: ["Dhalai", "Gomati", "Khowai", "North Tripura", "Sepahijala", "South Tripura", "Unakoti", "West Tripura"],
                UttarPradesh: ["Agra", "Aligarh", "Prayagraj", "Ambedkar Nagar", "Amethi", "Amroha", "Auraiya", "Azamgarh", "Baghpat", "Bahraich", "Ballia", "Balrampur", "Banda", "Barabanki", "Bareilly", "Basti", "Bijnor", "Badaun", "Bulandshahr", "Chandauli", "Chitrakoot", "Deoria", "Etah", "Etawah", "Faizabad", "Farrukhabad", "Fatehpur", "Firozabad", "Gautam Buddh Nagar", "Ghaziabad", "Ghazipur", "Gonda", "Gorakhpur", "Hamirpur", "Hapur", "Hardoi", "Hathras", "Jalaun", "Jaunpur", "Jhansi", "Kannauj", "Kanpur Dehat", "Kanpur Nagar", "Kasganj", "Kaushambi", "Kheri", "Kushinagar", "Lalitpur", "Lucknow", "Maharajganj", "Mahoba", "Mainpuri", "Mathura", "Mau", "Meerut", "Mirzapur", "Moradabad", "Muzaffarnagar", "Pilibhit", "Pratapgarh", "Raebareli", "Rampur", "Saharanpur", "Sambhal", "Sant Kabir Nagar", "Sant Ravidas Nagar", "Shahjahanpur", "Shamli", "Shrawasti", "Siddharthnagar", "Sitapur", "Sonbhadra", "Sultanpur", "Unnao", "Varanasi"],
                Uttarakhand: ["Almora", "Bageshwar", "Chamoli", "Champawat", "Dehradun", "Haridwar", "Nainital", "Pauri Garhwal", "Pithoragarh", "Rudraprayag", "Tehri Garhwal", "Udham Singh Nagar", "Uttarkashi"],
                WestBengal: ["Alipurduar", "Bankura", "Birbhum", "Cooch Behar", "Dakshin Dinajpur", "Darjeeling", "Hooghly", "Howrah", "Jalpaiguri", "Jhargram", "Kalimpong", "Kolkata", "Malda", "Murshidabad", "Nadia", "North 24 Parganas", "Paschim Bardhaman", "Paschim Medinipur", "Purba Bardhaman", "Purba Medinipur", "Purulia", "South 24 Parganas", "Uttar Dinajpur"]
            };

            function populateDistricts() {
                const selectedState = stateSelect.value;
                districtSelect.innerHTML = '<option value="" disabled selected>-- Select District --</option>';
                if (districtData[selectedState]) {
                    districtData[selectedState].forEach(district => {
                        districtSelect.add(new Option(district, district));
                    });
                }
            }

            function manageBranchSelect() {
                const grade = parseInt(gradeSelect.value);
                branchSelect.required = (grade === 11 || grade === 12);
                if (grade >= 1 && grade <= 10) {
                    branchSelect.value = 'Not Applicable';
                    branchSelect.disabled = true;
                } else if (grade === 11 || grade === 12) {
                    branchSelect.disabled = false;
                    if (branchSelect.value === 'Not Applicable') branchSelect.value = '';
                } else {
                    branchSelect.value = '';
                    branchSelect.disabled = true;
                }
            }
            
            function manageBranchSelectOnSubmit() {
                const grade = parseInt(gradeSelect.value);
                if (grade >= 1 && grade <= 10) {
                    branchSelect.value = "Not Applicable";
                }
                branchSelect.disabled = false;
            }

            stateSelect.addEventListener('change', populateDistricts);
            gradeSelect.addEventListener('change', manageBranchSelect);

            // Initial setup calls
            updateFormSteps();
            manageBranchSelect();
        });
    </script>

</body>
</html>

