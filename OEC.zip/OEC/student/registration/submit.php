<?php
include 'db.php';
session_start(); // Ensure session is started to use $_SESSION['country_code']

// Assign all values to variables
$stud_name = $_POST['Stud_name'];
$parent_name = $_POST['Parent_name'];
$dob = $_POST['Stud_dob'];
$gender = $_POST['Gender']; // Now string: Male, Female, Other
$address = $_POST['Home_addr'];
$country = $_SESSION['country_code'];
$state = $_POST['S_State'];
$district = $_POST['District'];
$mobile = $_POST['MobileNo'];
$whatsapp = $_POST['WhatsAppNo'];
$email = $_POST['Email_ID'];
$school_name = $_POST['S_Cname'];
$school_address = $_POST['S_Caddr'];
$school_cat = $_POST['S_Cat']; // Now string: State Board, CBSE, etc.
$grade = $_POST['Grade']; // Keep as number
$branch = $_POST['C_Branch']; // Now string: Not Applicable, Science, etc.
$exam_lang = $_POST['Exam_Lg']; // Now string: English, Marathi, etc.
$hashed_pass = password_hash($_POST['S_Pass'], PASSWORD_DEFAULT);

// Check if mobile number already exists
$check_stmt = $conn->prepare("SELECT RegID FROM olympiad_registrations WHERE MobileNo = ?");
$check_stmt->bind_param("s", $mobile);
$check_stmt->execute();
$check_stmt->store_result();

if ($check_stmt->num_rows > 0) {
    echo '<!DOCTYPE html><html><head><title>Registration Error</title>';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    echo '<style>
        body { background: linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%); min-height: 100vh; margin: 0; display: flex; justify-content: center; align-items: center; }
        .error-box {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 4px 24px rgba(106, 17, 203, 0.15);
            padding: 40px 30px;
            text-align: center;
            max-width: 400px;
            animation: popIn 1s cubic-bezier(.68,-0.55,.27,1.55);
        }
        .error-title {
            color: #cb116a;
            font-size: 2em;
            margin-bottom: 18px;
            font-weight: bold;
            letter-spacing: 1px;
            animation: fadeIn 1.2s 0.2s both;
        }
        .error-msg {
            color: #fc2525;
            font-size: 1.2em;
            font-weight: bold;
            margin-top: 10px;
            animation: fadeIn 1.2s 0.5s both;
        }
        @media (max-width: 480px) {
            .error-box {
                padding: 16px 2vw;
                max-width: 100vw;
                border-radius: 0;
                box-shadow: none;
            }
            .error-title {
                font-size: 1.1em;
            }
            .error-msg {
                font-size: 1em;
            }
        }
        @media (max-width: 600px) {
            .error-box {
                padding: 18px 6vw;
                max-width: 98vw;
            }
            .error-title {
                font-size: 1.2em;
            }
            .error-msg {
                font-size: 1em;
            }
        }
        @keyframes popIn {
            0% { opacity: 0; transform: scale(0.7) translateY(40px); }
            80% { opacity: 1; transform: scale(1.05) translateY(-10px); }
            100% { opacity: 1; transform: scale(1) translateY(0); }
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style></head><body>';
    echo '<div class="error-box">';
    echo '<div class="error-title">Registration Error</div>';
    echo '<div class="error-msg">This mobile number is already registered.</div>';
    echo '</div></body></html>';
    $check_stmt->close();
    $conn->close();
    exit;
}
$check_stmt->close();

// Prepare and bind the insert query
$stmt = $conn->prepare("INSERT INTO olympiad_registrations (
    Stud_name, Parent_name, Stud_dob, Gender, Home_addr, Country, S_State, District,
    MobileNo, WhatsAppNo, Email_ID, S_Cname, S_Caddr, S_Cat, Grade, C_Branch, Exam_Lg, S_Pass
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param("ssssssssssssssssss",
    $stud_name,
    $parent_name,
    $dob,
    $gender,
    $address,
    $country,
    $state,
    $district,
    $mobile,
    $whatsapp,
    $email,
    $school_name,
    $school_address,
    $school_cat,
    $grade,
    $branch,
    $exam_lang,
    $hashed_pass
);

if (!$state || !$district) {
    echo "Please make sure both State and District are selected.";
    exit;
}

if (!isset($_POST['C_Branch']) || trim($_POST['C_Branch']) === "") {
    echo "Error: Branch is required.";
    exit;
}

// Execute the insert query
if ($stmt->execute()) {
    // Get the last inserted RegID
    $last_regid = $conn->insert_id;

    // Generate RegNo by adding 26000 to the RegID
    $regno = 2600000 + ($last_regid - 1);

    // Now update the RegNo in the same record
    $update_stmt = $conn->prepare("UPDATE olympiad_registrations SET RegNo = ? WHERE RegID = ?");
    $update_stmt->bind_param("ii", $regno, $last_regid);

    if ($update_stmt->execute()) {
        echo '<!DOCTYPE html><html><head><title>Registration Successful</title>';
        echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
        echo '<style>
            body { background: linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%); min-height: 100vh; margin: 0; display: flex; justify-content: center; align-items: center; }
            .success-box {
                background: #fff;
                border-radius: 16px;
                box-shadow: 0 4px 24px rgba(106, 17, 203, 0.15);
                padding: 40px 30px;
                text-align: center;
                max-width: 400px;
                animation: popIn 1s cubic-bezier(.68,-0.55,.27,1.55);
            }
            .success-title {
                color: #6a11cb;
                font-size: 2em;
                margin-bottom: 18px;
                font-weight: bold;
                letter-spacing: 1px;
                animation: fadeIn 1.2s 0.2s both;
            }
            .regno {
                color: #2575fc;
                font-size: 1.5em;
                font-weight: bold;
                margin-top: 10px;
                animation: fadeIn 1.2s 0.5s both;
            }
                .btn {
                    display: inline-block;
                    padding: 10px 20px;
                    margin: 10px 5px;
                    font-size: 16px;
                    border: none;
                    border-radius: 5px;
                    text-decoration: none;
                    color: white;
                    cursor: pointer;
                    transition: background-color 0.3s ease;
                }
                .btn-login {
                    background-color: #007bff;
                }
                .btn-home {
                    background-color: #28a745;
                }
                .btn i {
                    margin-right: 8px;
                }
                .btn:hover {
                    opacity: 0.9;
                }
            @media (max-width: 480px) {
                .success-box {
                    padding: 16px 2vw;
                    max-width: 100vw;
                    border-radius: 0;
                    box-shadow: none;
                }
                .success-title {
                    font-size: 1.1em;
                }
                .regno {
                    font-size: 1em;
                }
            }
            @media (max-width: 600px) {
                .success-box {
                    padding: 18px 6vw;
                    max-width: 98vw;
                }
                .success-title {
                    font-size: 1.2em;
                }
                .regno {
                    font-size: 1em;
                }
            }
            @keyframes popIn {
                0% { opacity: 0; transform: scale(0.7) translateY(40px); }
                80% { opacity: 1; transform: scale(1.05) translateY(-10px); }
                100% { opacity: 1; transform: scale(1) translateY(0); }
            }
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
        </style></head><body>';
        echo '<div class="success-box">';
        echo '<div class="success-title">Registration Successful!</div>';
        echo '<div>Your Registration Number is:</div>';
        echo '<div class="regno">' . $regno . '</div>';
        echo '<a href="../index.php" class="btn btn-login"><i class="fa-solid fa-right-to-bracket"></i>Login</a>';
        echo '<a href="index.php" class="btn btn-home"><i class="fa-solid fa-house"></i>Home</a>';
        echo '</div></body></html>';
    } else {
        echo "Error in updating RegNo: " . $update_stmt->error;
    }

    // Close the update statement
    $update_stmt->close();
} else {
    echo "Error: " . $stmt->error;
}

// Close the insert statement and the database connection
$stmt->close();
$conn->close();
?>
