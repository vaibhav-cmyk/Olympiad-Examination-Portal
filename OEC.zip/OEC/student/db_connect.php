<?php
$host = 'localhost';
$dbname = 'olympiad_user_system';  // make sure you created this in phpMyAdmin
$username = 'olympiad_user_system'; // default XAMPP MySQL username
$password = 'riteshweb';     // default XAMPP MySQL password is empty

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?> 