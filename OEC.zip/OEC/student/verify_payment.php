<?php
session_start();
require_once 'config.php';
require_once 'db_connect.php';
require_once 'razorpay_api.php';
require_once 'check_payment_status.php';

// Check if user is logged in
if (!isset($_SESSION['IS_LOGIN']) || !isset($_SESSION['RegID'])) {
    header("Location: index.php");
    exit();
}

// Temporary debug - remove this after testing

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $razorpay_payment_id = $_POST['razorpay_payment_id'] ?? '';
    $razorpay_order_id = $_POST['razorpay_order_id'] ?? '';
    $razorpay_signature = $_POST['razorpay_signature'] ?? '';

    // Validate required parameters
    if (empty($razorpay_payment_id) || empty($razorpay_order_id) || empty($razorpay_signature)) {
        echo "<h3 style='color:red;text-align:center;'>Payment verification failed: Missing payment parameters.</h3>";
        exit;
    }

    // Check if session data exists
    $selectedExams = $_SESSION['selected_exams'] ?? [];
    $totalAmount = $_SESSION['total_amount'] ?? 0;
    $regId = $_SESSION['RegID'] ?? null;
    $regNo = $_SESSION['userid'] ?? null;
    $sessionOrderId = $_SESSION['razorpay_order_id'] ?? '';

    if (empty($selectedExams) || $totalAmount <= 0 || empty($regId) || empty($regNo)) {
        echo "<h3 style='color:red;text-align:center;'>Payment verification failed: Invalid session data.</h3>";
        exit;
    }

    // Verify that the order ID matches the session
    if ($sessionOrderId !== $razorpay_order_id) {
        echo "<h3 style='color:red;text-align:center;'>Payment verification failed: Order ID mismatch.</h3>";
        exit;
    }

    // Use enhanced payment verification
    $checker = new PaymentStatusChecker();
    $verificationResult = $checker->verifyPayment($razorpay_payment_id, $razorpay_order_id, $razorpay_signature);

    // --- BEGIN: Exam fee mapping logic ---
    // Exam config copied from dash_exam.php
    $exam_config = [
        '1-4' => [
            ['name' => 'International Mathematics Olympiad', 'fee_inr' => 175],
            ['name' => 'International English Olympiad', 'fee_inr' => 175]
        ],
        '5-10' => [
            ['name' => 'International Mathematics Olympiad', 'fee_inr' => 175],
            ['name' => 'International English Olympiad', 'fee_inr' => 175],
            ['name' => 'International Science Olympiad', 'fee_inr' => 175],
            ['name' => 'International Space Olympiad', 'fee_inr' => 400]
        ]
        // 11-12 handled below
    ];
    // Fetch grade and branch
    $grade = intval($_SESSION['grade'] ?? 0);
    if (isset($_SESSION['C_Branch'])) {
        $branch = $_SESSION['C_Branch'];
    } else {
        // Fetch from DB if not in session
        $regID = $_SESSION['RegID'];
        $branch = null;
        $conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");
        if (!$conn->connect_error) {
            $stmt = $conn->prepare("SELECT C_Branch FROM olympiad_registrations WHERE RegID = ?");
            $stmt->bind_param("i", $regID);
            $stmt->execute();
            $stmt->bind_result($branch);
            $stmt->fetch();
            $stmt->close();
            $conn->close();
            $_SESSION['C_Branch'] = $branch;
        }
    }
    function getExamsByGradeAndBranch($grade, $branch, $config) {
        if ($grade >= 1 && $grade <= 4) return $config['1-4'];
        if ($grade >= 5 && $grade <= 10) return $config['5-10'];
        if ($grade == 11 || $grade == 12) {
            $branch = strtolower(trim($branch));
            if ($branch === 'science') {
                return [
                    ['name' => 'International Physics Olympiad', 'fee_inr' => 250],
                    ['name' => 'International Chemistry Olympiad', 'fee_inr' => 250],
                    ['name' => 'International Mathematics Olympiad', 'fee_inr' => 250],
                    ['name' => 'International Biology Olympiad', 'fee_inr' => 250],
                ];
            } elseif ($branch === 'commerce') {
                return [
                    ['name' => 'International English Olympiad', 'fee_inr' => 250],
                    ['name' => 'International Commerce Olympiad', 'fee_inr' => 250],
                ];
            } elseif ($branch === 'arts') {
                return [
                    ['name' => 'International English Olympiad', 'fee_inr' => 250],
                    ['name' => 'International Geography Olympiad', 'fee_inr' => 250],
                    ['name' => 'International Economics Olympiad', 'fee_inr' => 250],
                ];
            } else {
                return [];
            }
        }
        return [];
    }
    $exam_fee_map = [];
    foreach (getExamsByGradeAndBranch($grade, $branch, $exam_config) as $examInfo) {
        $exam_fee_map[$examInfo['name']] = $examInfo['fee_inr'];
    }
    // --- END: Exam fee mapping logic ---

    if ($verificationResult['valid']) {
        // Payment is verified - proceed with database insertion
        try {
            // Begin transaction
            $pdo->beginTransaction();

            // Insert payment record for each exam with its individual fee
            foreach ($selectedExams as $exam) {
                $fee = $exam_fee_map[$exam] ?? 0;
                $stmt = $pdo->prepare("INSERT INTO payment_transactions (RegID, RegNo, Exam, Amount, PaymentID, PaymentStatus, PaymentDate, AccountStatus) VALUES (?, ?, ?, ?, ?, 'Success', NOW(), 'Active')");
                $stmt->execute([$regId, $regNo, $exam, $fee, $razorpay_payment_id]);
            }

            // Commit transaction
            $pdo->commit();

            // Display success message
            ?>
            <!DOCTYPE html>
            <html>
            <head>
                <title>Payment Successful</title>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
                <style>
                    body {
                        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                        margin: 0;
                        padding: 0;
                        min-height: 100vh;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }
                    .success-container {
                        background: white;
                        padding: 3rem;
                        border-radius: 20px;
                        box-shadow: 0 15px 30px rgba(0,0,0,0.1);
                        width: 90%;
                        max-width: 600px;
                        text-align: center;
                    }
                    .success-icon {
                        font-size: 4rem;
                        color: #27ae60;
                        margin-bottom: 1rem;
                    }
                    .success-heading {
                        color: #2c3e50;
                        font-size: 2.5rem;
                        font-weight: 600;
                        margin-bottom: 1.5rem;
                    }
                    .payment-details {
                        background: #f8f9fa;
                        padding: 2rem;
                        border-radius: 15px;
                        margin: 2rem 0;
                        text-align: left;
                    }
                    .detail-row {
                        display: flex;
                        justify-content: space-between;
                        margin: 0.5rem 0;
                        padding: 0.5rem 0;
                        border-bottom: 1px solid #e9ecef;
                    }
                    .detail-label {
                        font-weight: 600;
                        color: #495057;
                    }
                    .detail-value {
                        color: #6c757d;
                    }
                    .exam-list {
                        list-style: none;
                        padding: 0;
                        margin: 1rem 0;
                    }
                    .exam-item {
                        background: #fff;
                        padding: 0.75rem 1rem;
                        margin: 0.5rem 0;
                        border-radius: 8px;
                        border-left: 4px solid #27ae60;
                        color: #2c3e50;
                    }
                    .button-group {
                        display: flex;
                        gap: 1rem;
                        justify-content: center;
                        margin-top: 2rem;
                    }
                    .home-button, .download-button {
                        background: linear-gradient(135deg, #3498db, #27ae60);
                        color: white;
                        border: none;
                        padding: 12px 28px;
                        border-radius: 25px;
                        font-size: 1.1rem;
                        cursor: pointer;
                        text-decoration: none;
                        display: inline-block;
                        transition: all 0.2s ease-in-out;
                        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                    }
                    .home-button:hover, .download-button:hover {
                        transform: translateY(-2px);
                        box-shadow: 0 6px 16px rgba(0,0,0,0.15);
                    }
                    .verification-badge {
                        background: #d4edda;
                        color: #155724;
                        padding: 0.5rem 1rem;
                        border-radius: 20px;
                        font-size: 0.9rem;
                        margin: 1rem 0;
                        display: inline-block;
                    }
                </style>
            </head>
            <body>
                <div class="success-container">
                    <div class="success-icon">✅</div>
                    <h2 class="success-heading">Payment Successful!</h2>
                    <div class="verification-badge">✓ Payment Verified by Razorpay</div>
                    
                    <div class="payment-details">
                        <div class="detail-row">
                            <span class="detail-label">Payment ID:</span>
                            <span class="detail-value"><?php echo htmlspecialchars($razorpay_payment_id); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Order ID:</span>
                            <span class="detail-value"><?php echo htmlspecialchars($razorpay_order_id); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Amount Paid:</span>
                            <span class="detail-value">₹<?php echo htmlspecialchars($totalAmount); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Payment Method:</span>
                            <span class="detail-value"><?php echo htmlspecialchars(ucfirst($verificationResult['payment_data']['method'] ?? 'Online')); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Payment Date:</span>
                            <span class="detail-value"><?php echo date('d M Y, h:i A'); ?></span>
                        </div>
                        
                        <h4 style="color: #2c3e50; margin: 1.5rem 0 1rem 0;">Selected Exams:</h4>
                        <ul class="exam-list">
                            <?php foreach ($selectedExams as $exam): ?>
                                <li class="exam-item"><?php echo htmlspecialchars($exam); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    
                    <p style="color: #6c757d; margin: 2rem 0;">Thank you for your payment. You will receive a confirmation email shortly.</p>
                    
                    <div class="button-group">
                        <a href="student_dash.php" class="home-button">Return to Dashboard</a>
                        <button id="download-btn" class="download-button">Download Receipt</button>
                    </div>
                </div>
                <script>
                    document.getElementById('download-btn').addEventListener('click', function () {
                        const element = document.querySelector('.payment-details');
                        const opt = {
                            margin:       0.5,
                            filename:     'payment_receipt_<?php echo htmlspecialchars($razorpay_order_id); ?>.pdf',
                            image:        { type: 'jpeg', quality: 0.98 },
                            html2canvas:  { scale: 2 },
                            jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
                        };
                        html2pdf().set(opt).from(element).save();
                    });
                </script>
            </body>
            </html>
            <?php

        } catch (Exception $e) {
            // Rollback transaction on error
            $pdo->rollBack();
            echo "<h3 style='color:red;text-align:center;'>Error saving payment details: " . $e->getMessage() . "</h3>";
        }

        // Clear session data after successful payment
        unset($_SESSION['selected_exams']);
        unset($_SESSION['total_amount']);
        unset($_SESSION['payment_amount']);
        unset($_SESSION['razorpay_order_id']);

    } else {
        // Payment verification failed
        echo "<h3 style='color:red;text-align:center;'>Payment verification failed: " . htmlspecialchars($verificationResult['reason']) . ". Please contact support.</h3>";
        
        // Log the failed payment attempt (for debugging purposes)
        error_log("Payment verification failed for Payment ID: " . $razorpay_payment_id . ", Order ID: " . $razorpay_order_id . ", Reason: " . $verificationResult['reason']);
    }
} else {
    echo "<h3 style='color:red;text-align:center;'>Invalid Access</h3>";
}
?> 