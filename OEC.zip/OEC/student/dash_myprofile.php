<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("registration/db.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Check login
if (!isset($_SESSION['userid'])) {
    header("Location: index.php");
    exit;
}

$userid = $_SESSION['userid'];

// Fetch student details
$student = [];
$stmt = $conn->prepare("SELECT * FROM olympiad_registrations WHERE RegNo = ?");
$stmt->bind_param("s", $userid);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
} else {
    echo '<div style="color:red;text-align:center;margin-top:20px;">No student data found for your account. Please contact support.</div>';
}

// Handle AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    if ($_POST['action'] === 'getdt') {
        $sql = "SELECT * FROM olympiad_registrations WHERE RegNo = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $userid);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode($data);
        exit;
    }

    if ($_POST['action'] == 'updt') {
        $RegNo = $_POST['RegNo'];
        $Stud_name = $_POST['sname'];
        $Parent_name = $_POST['parent_name'];
        $Stud_dob = $_POST['stud_dob'];
        $Gender = $_POST['sgender'];

        if (empty($RegNo)) {
            echo json_encode(["status" => "error", "message" => "Registration number is missing."]);
            exit;
        }

        $sql = "UPDATE olympiad_registrations SET 
                Stud_name = ?, 
                Parent_name = ?, 
                Stud_dob = ?, 
                Gender = ?
                WHERE RegNo = ?";

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            echo json_encode(["status" => "error", "message" => "SQL Error: " . $conn->error]);
            exit;
        }

        $stmt->bind_param("sssss", $Stud_name, $Parent_name, $Stud_dob, $Gender, $RegNo);

        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                echo json_encode(["status" => "success", "message" => "Profile updated successfully."]);
            } else {
                echo json_encode(["status" => "warning", "message" => "No changes made or invalid RegNo."]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Update failed: " . $stmt->error]);
        }

        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Profile</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        :root {
            --primary-bg: #f8f9fa;
            --card-bg: #ffffff;
            --text-dark: #343a40;
            --text-muted: #6c757d;
            --border-color: #dee2e6;
            --primary-accent: #6b186e;
            --primary-accent-hover: #512da8;
        }

        body {
            font-family: 'Poppins', sans-serif; /* Assuming Poppins is loaded from student_dash */
            background-color: var(--primary-bg);
            color: var(--text-dark);
        }

        .profile-header {
            text-align: center;
            padding: 1.5rem;
            border-radius: 12px;
            color: #fff;
            background: linear-gradient(135deg, var(--primary-accent), var(--primary-accent-hover));
            margin-top: 55px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .profile-container {
            padding: 2rem 0;
        }

        .profile-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 2.5rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        }
        
        .profile-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
        }

        .profile-field {
            margin-bottom: 1rem;
        }
        
        .profile-field label {
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
            display: block;
        }

        .profile-field .value {
            background-color: #f1f3f5;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            color: var(--text-muted);
            font-weight: 500;
        }

        .btn-custom-edit {
            background: linear-gradient(135deg, #ffc107, #ff9800);
            color: #fff;
            border-radius: 50px;
            padding: 12px 35px;
            font-weight: 600;
            border: none;
            font-size: 16px;
            box-shadow: 0 4px 15px rgba(255, 193, 7, 0.2);
            transition: all 0.3s ease;
        }
        .btn-custom-edit:hover {
            color: #fff;
            transform: translateY(-3px);
            box-shadow: 0 7px 20px rgba(255, 193, 7, 0.3);
        }

        /* Modal styling */
        .modal-header {
            background: var(--primary-accent);
            color: #fff;
            border-bottom: none;
        }
        .modal-header .close {
            color: #fff;
            opacity: 0.9;
        }
    </style>
</head>
<body>
<div class="container profile-container">
    <div class="profile-header">
        <h4>My Profile</h4>
    </div>

    <div class="profile-card mt-4">
        <div class="profile-grid">
            <div class="profile-field"><label>Registration No</label><div class="value"><?= htmlspecialchars($student['RegNo'] ?? '') ?></div></div>
            <div class="profile-field"><label>Name</label><div class="value"><?= htmlspecialchars($student['Stud_name'] ?? '') ?></div></div>
            <div class="profile-field"><label>Parent Name</label><div class="value"><?= htmlspecialchars($student['Parent_name'] ?? '') ?></div></div>
            <div class="profile-field"><label>Date of Birth</label><div class="value"><?= htmlspecialchars($student['Stud_dob'] ?? '') ?></div></div>
            <div class="profile-field"><label>Gender</label><div class="value"><?= htmlspecialchars($student['Gender'] ?? '') ?></div></div>
            <div class="profile-field"><label>Address</label><div class="value"><?= htmlspecialchars($student['Home_addr'] ?? '') ?></div></div>
            <div class="profile-field"><label>State</label><div class="value"><?= htmlspecialchars($student['S_State'] ?? '') ?></div></div>
            <div class="profile-field"><label>District</label><div class="value"><?= htmlspecialchars($student['District'] ?? '') ?></div></div>
            <div class="profile-field"><label>Email ID</label><div class="value"><?= htmlspecialchars($student['Email_ID'] ?? '') ?></div></div>
            <div class="profile-field"><label>Mobile No</label><div class="value"><?= htmlspecialchars($student['MobileNo'] ?? '') ?></div></div>
            <div class="profile-field"><label>WhatsApp No</label><div class="value"><?= htmlspecialchars($student['WhatsAppNo'] ?? '') ?></div></div>
            <div class="profile-field"><label>School/College Name</label><div class="value"><?= htmlspecialchars($student['S_Cname'] ?? '') ?></div></div>
            <div class="profile-field"><label>School/College Address</label><div class="value"><?= htmlspecialchars($student['S_Caddr'] ?? '') ?></div></div>
            <div class="profile-field"><label>School Category</label><div class="value"><?= htmlspecialchars($student['S_Cat'] ?? '') ?></div></div>
            <div class="profile-field"><label>Grade</label><div class="value"><?= htmlspecialchars($student['Grade'] ?? '') ?></div></div>
            <div class="profile-field"><label>Exam Language</label><div class="value"><?= htmlspecialchars($student['Exam_Lg'] ?? '') ?></div></div>
            <div class="profile-field"><label>Branch</label><div class="value"><?= htmlspecialchars($student['C_Branch'] ?? '') ?></div></div>
        </div>
        <div class="text-center mt-5">
            <button class="btn-custom-edit" onclick="editMe()">Edit My Profile</button>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form id="editForm">
          <div class="modal-header">
            <h5 class="modal-title">Edit My Profile</h5>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
              <input type="hidden" name="RegNo" id="RegNo"> <!-- Hidden RegNo -->

              <div class="form-group">
                  <label for="sname">Student Name</label>
                  <input type="text" class="form-control" name="sname" id="sname">
              </div>
              <div class="form-group">
                  <label for="parent_name">Parent Name</label>
                  <input type="text" class="form-control" name="parent_name" id="parent_name">
              </div>
              <div class="form-group">
                  <label for="stud_dob">Date of Birth</label>
                  <input type="date" class="form-control" name="stud_dob" id="stud_dob">
              </div>
              <div class="form-group">
                  <label for="sgender">Gender</label>
                  <select class="form-control" name="sgender" id="sgender">
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                  </select>
              </div>
          </div>
          <div class="modal-footer">
              <button type="submit" class="btn btn-success">Update</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
      </form>
    </div>
  </div>
</div>


<!-- jQuery & Bootstrap -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<script>
function getProfile() {
    $.post("dash_myprofile.php", { action: "getdt" }, function (data) {
        if (data.length > 0) {
            const item = data[0];
            $('#RegNo').val(item.RegNo);
            $('#sname').val(item.Stud_name);
            $('#parent_name').val(item.Parent_name);
            $('#stud_dob').val(item.Stud_dob);
            $('#sgender').val(item.Gender);
        }
    }, "json");
}
function editMe() {
    getProfile();
    $('#editModal').modal('show');
}

$('#editForm').submit(function (e) {
    e.preventDefault();
    const formData = $(this).serialize() + "&action=updt";
    $.post("dash_myprofile.php", formData, function (response) {
        alert(response.message);
        if (response.status === "success") {
            $('#editModal').modal('hide');
            location.reload(); // Refresh to reflect updated values
        }
    }, "json");
});

</script>

</body>
</html>
