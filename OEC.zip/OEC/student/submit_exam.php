<?php
if (session_status() === PHP_SESSION_NONE) session_start();

$servername = "localhost";     
$username   = "olympiad_user_system";          
$password   = "riteshweb";              
$database   = "olympiad_user_system";   

// ✅ Create connection
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect POST
$regno     = $_POST['regno']    ?? '';
$name      = $_POST['name']     ?? '';
$subject   = $_POST['subject']  ?? '';
$grade     = intval($_POST['grade'] ?? 0);
$language  = $_POST['language'] ?? 'English';
$startedAt = intval($_POST['started_at'] ?? 0);
$answers   = $_POST['answers']  ?? [];


// Fetch correct answers
$qids = array_map('intval', array_keys($answers));
$questions = [];
if (!empty($qids)) {
  $placeholders = implode(',', array_fill(0, count($qids), '?'));
  $types = str_repeat('i', count($qids));
  $stmt = $conn->prepare("SELECT id, question, option_a, option_b, option_c, option_d, section, correct_answer FROM questions WHERE id IN ($placeholders)");
  $stmt->bind_param($types, ...$qids);
  $stmt->execute();
  $res = $stmt->get_result();
  while ($row = $res->fetch_assoc()) $questions[$row['id']] = $row;
}

// Grade calculation
$totalQs = count($answers);
$attempted = 0;
$correct   = 0;
$review    = [];

foreach ($answers as $qid => $ans) {
  $attempted++;
  $qid = intval($qid);
  $ans = strtoupper(trim($ans));
  $correctAns = $questions[$qid]['correct_answer'] ?? '';
  $isCorrect = ($ans === $correctAns);
  if ($isCorrect) $correct++;

  $review[] = [
    'id' => $qid,
    'section' => $questions[$qid]['section'] ?? '',
    'question' => $questions[$qid]['question'] ?? '',
    'chosen' => $ans,
    'correct' => $correctAns,
    'options' => [
      'A' => $questions[$qid]['option_a'] ?? '',
      'B' => $questions[$qid]['option_b'] ?? '',
      'C' => $questions[$qid]['option_c'] ?? '',
      'D' => $questions[$qid]['option_d'] ?? '',
    ],
    'is_correct' => $isCorrect,
  ];
}

$score = $correct; // marks
$percent = $attempted > 0 ? round(($score / $attempted) * 100, 2) : 0;

// === Save summary into exam_marks ===
$submittedAt = time();
$stmt = $conn->prepare("INSERT INTO exam_marks 
  (regno, name, subject, class, language, marks, submitted_at) 
  VALUES (?,?,?,?,?,?,?)");
$stmt->bind_param("sssissi", $regno, $name, $subject, $grade, $language, $score, $submittedAt);
$stmt->execute();
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Result — <?= htmlspecialchars($subject) ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root { --brand: #4f46e5; }
    body { background:#f8fafc; font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif; }
    .shell { max-width: 980px; }
    .cardish { border:1px solid rgba(0,0,0,.06); border-radius:1rem; box-shadow: 0 10px 20px rgba(2,6,23,0.04); }
    .brand { color: var(--brand); }
    .badge-correct { background:#16a34a; }
    .badge-wrong { background:#dc2626; }
  </style>
</head>
<body>
  <main class="container my-4 shell">
    <div class="cardish bg-white p-4 p-md-5 mb-4">
      <div class="d-flex flex-wrap justify-content-between align-items-center">
        <div>
          <h3 class="brand mb-1">Result</h3>
          <div class="text-muted">
            <?= htmlspecialchars($subject) ?> • Grade <?= htmlspecialchars($grade) ?> • <?= htmlspecialchars($language) ?>
          </div>
          <div class="text-muted small">
            Candidate: <?= htmlspecialchars($name) ?> (Reg: <?= htmlspecialchars($regno) ?>)
          </div>
        </div>
        <div class="text-end">
          <div class="display-6 fw-bold"><?= $score ?><span class="fs-5 text-muted"> / <?= $attempted ?></span></div>
          <div class="text-muted">Marks Obtained</div>
          <div class="mt-2">
            <div class="progress" style="height:10px;">
              <div class="progress-bar" role="progressbar" style="width: <?= $percent ?>%;" aria-valuenow="<?= $percent ?>" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <div class="small text-muted mt-1"><?= $percent ?>%</div>
          </div>
        </div>
      </div>
    </div>

    <div class="cardish bg-white p-4 p-md-5">
      <h5 class="mb-3">Answer Review</h5>
      <?php if (empty($review)): ?>
        <div class="alert alert-warning">No answers submitted.</div>
      <?php else: ?>
        <?php foreach ($review as $idx => $r): ?>
          <div class="border rounded-3 p-3 p-md-4 mb-3">
            <div class="d-flex justify-content-between align-items-start mb-2">
              <div class="fw-semibold">Q<?= $idx+1 ?> <span class="text-muted small">• <?= htmlspecialchars($r['section']) ?></span></div>
              <?php if ($r['is_correct']): ?>
                <span class="badge badge-correct">Correct</span>
              <?php else: ?>
                <span class="badge badge-wrong">Incorrect</span>
              <?php endif; ?>
            </div>
            <div class="mb-3"><?= $r['question'] ?></div>
            <div class="row g-2">
              <?php foreach (['A','B','C','D'] as $opt): ?>
                <div class="col-12 col-md-6">
                  <div class="p-2 rounded border
                    <?php
                      if ($r['chosen'] === $opt && $r['is_correct']) echo ' border-success';
                      elseif ($r['chosen'] === $opt && !$r['is_correct']) echo ' border-danger';
                      elseif ($r['correct'] === $opt) echo ' border-success';
                    ?>">
                    <div class="small text-muted mb-1">Option <?= $opt ?></div>
                    <div><?= $r['options'][$opt] ?></div>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
            <div class="mt-2 small">
              Your answer: <strong><?= $r['chosen'] ?: '—' ?></strong> |
              Correct answer: <strong><?= $r['correct'] ?></strong>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <div class="d-flex justify-content-end mt-3">
      <a href="student_dash.php" class="btn btn-outline-secondary me-2">Back to Dashboard</a>
      <a href="exam_module.php?<?= http_build_query([
        'Regno' => $regno,
        'name' => $name,
        'next' => strtolower(str_replace(' ', '-', $subject)),
        'grade' => $grade,
        'Exam_Lg' => $language
      ]) ?>" class="btn btn-primary">Retake</a>
    </div>
  </main>
</body>
</html>
