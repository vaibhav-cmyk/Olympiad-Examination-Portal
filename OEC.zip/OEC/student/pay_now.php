<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once 'config.php';
require_once 'db_connect.php';
require_once 'razorpay_api.php';

// Check if user is logged in
if (!isset($_SESSION['IS_LOGIN']) || !isset($_SESSION['RegID'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selectedExams = $_POST['selected_exams'] ?? [];
    $totalAmount = $_POST['total_amount'] ?? 0;

    if (empty($selectedExams) || $totalAmount <= 0) {
        echo "<h3 style='color:red;text-align:center;'>Invalid payment details.</h3>";
        exit;
    }

    // Store in session for later use
    $_SESSION['selected_exams'] = $selectedExams;
    $_SESSION['total_amount'] = $totalAmount;
    $_SESSION['payment_amount'] = $totalAmount * 100; // Convert to paise for Razorpay

    // Create Razorpay order
    $api = new RazorpayAPI(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET);
    
    try {
        $orderData = [
            'receipt'         => 'rcptid_' . time(),
            'amount'          => $totalAmount * 100, // Amount in paise
            'currency'        => 'INR',
            'payment_capture' => 1
        ];

        $razorpayOrder = $api->createOrder($orderData);
        $razorpayOrderId = $razorpayOrder['id'];
        
        // Store order ID in session
        $_SESSION['razorpay_order_id'] = $razorpayOrderId;

    } catch (Exception $e) {
        echo "<div style='max-width: 500px; margin: 60px auto; padding: 2rem; background: #fff3f3; border: 1.5px solid #ffb3b3; border-radius: 15px; box-shadow: 0 6px 24px rgba(255,0,0,0.07); text-align: center;'>\n"
           . "<h2 style='color: #d32f2f; font-size: 2rem; margin-bottom: 0.5rem; letter-spacing: 1px;'>NETWORK ERROR</h2>\n"
           . "<div style='color: #b71c1c; font-size: 1.1rem; margin-bottom: 1.2rem;'>Error creating order: Failed to create order.</div>\n"
           . "<div style='color: #333; font-size: 1rem; background: #fff0e0; border-radius: 8px; padding: 0.8rem 1rem; margin-bottom: 1.2rem;'>" . htmlspecialchars($e->getMessage()) . "</div>\n"
           . "<div style='color: #6d4c41; font-size: 1rem; margin-top: 1.2rem;'><b>NOTE :</b> make sure a stable network before processing the payment.</div>\n"
           . "<a href='pay_now.php' style='display:inline-block;margin-top:1.5rem;padding:10px 28px;background:linear-gradient(90deg,#ffb347,#ffcc80);color:#b71c1c;font-weight:600;border-radius:25px;text-decoration:none;box-shadow:0 2px 8px rgba(255,179,71,0.12);transition:background 0.2s;'>Try Again</a>\n"
           . "</div>";
        exit;
    }

    // Display payment form
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Payment</title>
        <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                margin: 0;
                padding: 0;
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .payment-container {
                background: white;
                padding: 2rem;
                border-radius: 15px;
                box-shadow: 0 10px 20px rgba(0,0,0,0.1);
                width: 90%;
                max-width: 500px;
                text-align: center;
            }
            .payment-heading {
                color: #2c3e50;
                font-size: 2.2rem;
                font-weight: 600;
                margin-bottom: 1.5rem;
                position: relative;
                padding-bottom: 15px;
            }
            .payment-heading:after {
                content: '';
                position: absolute;
                bottom: 0;
                left: 50%;
                transform: translateX(-50%);
                width: 60px;
                height: 3px;
                background: linear-gradient(90deg, #3498db, #2ecc71);
                border-radius: 2px;
            }
            .payment-details {
                background: #f8f9fa;
                padding: 1.5rem;
                border-radius: 10px;
                margin: 1.5rem 0;
            }
            .amount {
                font-size: 1.5rem;
                color: #2c3e50;
                font-weight: 600;
                margin: 1rem 0;
            }
            .currency {
                color: #27ae60;
            }
            .payment-button {
                background: linear-gradient(135deg, #3498db, #2ecc71);
                color: white;
                border: none;
                padding: 12px 30px;
                border-radius: 25px;
                font-size: 1.1rem;
                cursor: pointer;
                transition: transform 0.2s, box-shadow 0.2s;
                margin-top: 1rem;
                display: inline-block;
                text-decoration: none;
            }
            .payment-button:hover {
                transform: translateY(-2px);
                box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            }
            .selected-exams {
                text-align: left;
                margin: 1rem 0;
                padding: 0 1rem;
            }
            .selected-exams li {
                color: #34495e;
                margin: 0.5rem 0;
                padding: 0.5rem;
                background: #fff;
                border-radius: 5px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            }
            .back-icon {
                position: fixed;
                top: 18px;
                left: 18px;
                z-index: 1001;
                background: white;
                border-radius: 50%;
                box-shadow: 0 2px 8px rgba(52,152,219,0.08);
                width: 48px;
                height: 48px;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                transition: box-shadow 0.2s;
            }
            .back-icon:hover {
                box-shadow: 0 4px 16px rgba(52,152,219,0.18);
            }
            @media (max-width: 600px) {
                .back-icon {
                    top: 10px;
                    left: 10px;
                    width: 40px;
                    height: 40px;
                }
                .payment-container {
                    padding-top: 2.5rem;
                }
            }
        </style>
    </head>
    <body>
        <div class="back-icon" onclick="window.location.href='student_dash.php?page=exams'" title="Back to Exams">
            <!-- SVG Back Arrow Icon -->
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15 19L8 12L15 5" stroke="#3498db" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <div class="payment-container">
            <h2 class="payment-heading">Complete Your Payment</h2>
            <div class="payment-details">
                <h3>Selected Exams:</h3>
                <ul class="selected-exams">
                    <?php foreach ($selectedExams as $exam): ?>
                        <li><?php echo htmlspecialchars($exam); ?></li>
                    <?php endforeach; ?>
                </ul>
                <div class="amount">
                    Total Amount: <span class="currency">₹<?php echo htmlspecialchars($totalAmount); ?></span>
                </div>
            </div>
            <form id="paymentForm" action="verify_payment.php" method="POST">
                <script>
                    var options = {
                        "key": "<?php echo RAZORPAY_KEY_ID; ?>",
                        "amount": "<?php echo $totalAmount * 100; ?>",
                        "currency": "INR",
                        "name": "Exam Payment",
                        "description": "Payment for selected exams",
                        "order_id": "<?php echo $razorpayOrderId; ?>",
                        "handler": function (response){
                            document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
                            document.getElementById('razorpay_order_id').value = response.razorpay_order_id;
                            document.getElementById('razorpay_signature').value = response.razorpay_signature;
                            document.getElementById('paymentForm').submit();
                        },
                        "modal": {
                            "ondismiss": function() {
                                // Redirect to failure page when modal is dismissed
                                window.location.href = 'payment_failed.php';
                            }
                        },
                        "prefill": {
                            "name": "",
                            "email": "",
                            "contact": ""
                        },
                        "theme": {
                            "color": "#3498db"
                        }
                    };
                    var rzp1 = new Razorpay(options);
                    
                    // Handle payment failure
                    rzp1.on('payment.failed', function (response){
                        var errorDetails = response.error;
                        var errorUrl = 'payment_failed.php?';
                        errorUrl += 'error_code=' + encodeURIComponent(errorDetails.code || '');
                        errorUrl += '&error_description=' + encodeURIComponent(errorDetails.description || '');
                        errorUrl += '&error_source=' + encodeURIComponent(errorDetails.source || '');
                        errorUrl += '&error_step=' + encodeURIComponent(errorDetails.step || '');
                        errorUrl += '&error_reason=' + encodeURIComponent(errorDetails.reason || '');
                        window.location.href = errorUrl;
                    });
                </script>
                <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
                <input type="hidden" name="razorpay_order_id" id="razorpay_order_id">
                <input type="hidden" name="razorpay_signature" id="razorpay_signature">
                <button type="button" class="payment-button" onclick="rzp1.open()">Proceed to Pay</button>
            </form>
        </div>
        <!-- Disable Right-Click + DevTools -->
<script>
document.addEventListener("contextmenu", function (e) {
    e.preventDefault();
    alert("⚠️🚫 Right-click is disabled!\n\n🔒 This is an official website.\n🛑 Any malicious activity is strictly prohibited.\n👮‍♂️ Legal action will be taken against offenders.");
});

document.addEventListener("keydown", function (e) {
    if (
        e.keyCode === 123 || // F12
        (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I/J
        (e.ctrlKey && e.keyCode === 85) // Ctrl+U
    ) {
        e.preventDefault();
        alert("🚫⚠️ This action is disabled for security reasons.\n\n🔐 Unauthorized inspection or tampering is forbidden.\n👮‍♂️ Violators may face strict legal consequences.");
    }
});
</script>
    </body>
    </html>
    <?php
} else {
    echo '<!DOCTYPE html>';
    echo '<html><head><title>Invalid Access</title>';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<style>
        body { background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh; margin: 0; display: flex; align-items: center; justify-content: center; }
        .error-card { background: #fff; padding: 2.5rem 2rem; border-radius: 18px; box-shadow: 0 8px 32px rgba(44,62,80,0.10); text-align: center; max-width: 350px; width: 90%; }
        .error-title { color: #e74c3c; font-size: 2rem; font-weight: 700; margin-bottom: 1.2rem; }
        .error-desc { color: #555; font-size: 1.1rem; margin-bottom: 2.2rem; }
        .back-btn { display: inline-block; background: linear-gradient(90deg, #3498db, #2ecc71); color: #fff; border: none; border-radius: 25px; padding: 12px 32px; font-size: 1.1rem; font-weight: 600; text-decoration: none; box-shadow: 0 2px 8px rgba(52,152,219,0.10); transition: background 0.2s, box-shadow 0.2s; cursor: pointer; }
        .back-btn:hover { background: linear-gradient(90deg, #2ecc71, #3498db); box-shadow: 0 4px 16px rgba(52,152,219,0.18); }
        @media (max-width: 600px) { .error-card { padding: 1.5rem 0.5rem; } .error-title { font-size: 1.4rem; } }
    </style>';
    echo '</head><body>';
    echo '<div class="error-card">';
    echo '<div class="error-title">Invalid Access</div>';
    echo '<div class="error-desc">You do not have permission to view this page or you accessed it incorrectly.</div>';
    echo '<a href="student_dash.php?page=exams" class="back-btn">&#8592; Back</a>';
    echo '</div>';
    echo '</body></html>';
}
?> 