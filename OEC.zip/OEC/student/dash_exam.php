<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// DEBUGGING — Optional (Remove after testing)
if (!isset($_SESSION['grade'])) {
    echo "<div style='color:red; text-align:center;'>Session grade not found. Debug info:</div>";
    echo "<pre>" . print_r($_SESSION, true) . "</pre>";
}

$grade = intval($_SESSION['grade'] ?? 0);
// Fetch branch from session or DB
if (isset($_SESSION['C_Branch'])) {
    $branch = $_SESSION['C_Branch'];
} else {
    // Fetch from DB if not in session
    $regID = $_SESSION['RegID'];
    $branch = null;
  $conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");

    if (!$conn->connect_error) {
        $stmt = $conn->prepare("SELECT C_Branch FROM olympiad_registrations WHERE RegID = ?");
        $stmt->bind_param("i", $regID);
        $stmt->execute();
        $stmt->bind_result($branch);
        $stmt->fetch();
        $stmt->close();
        $conn->close();
        $_SESSION['C_Branch'] = $branch;
    }
}

$astatus = $_SESSION['AStatus'] ?? 0;

// Fetch paid exams for this student
$regID = $_SESSION['RegID'];
$paidExams = [];
$conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");

if (!$conn->connect_error) {
    $stmt = $conn->prepare("SELECT Exam FROM payment_transactions WHERE RegID = ? AND PaymentStatus = 'Success'");
    $stmt->bind_param("i", $regID);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $paidExams[] = $row['Exam'];
    }
    $stmt->close();
    $conn->close();
}

$exam_config = [
    '1-4' => [
        ['name' => 'International Mathematics Olympiad', 'link' => 'international-mathematics-olympiad', 'fee_inr' => 175],
        ['name' => 'International English Olympiad', 'link' => 'international-English-olympiad', 'fee_inr' => 175],
    ],
    '5-10' => [
        ['name' => 'International Mathematics Olympiad', 'link' => 'international-mathematics-olympiad', 'fee_inr' => 175],
        ['name' => 'International English Olympiad', 'link' => 'international-English-olympiad', 'fee_inr' => 175],
        ['name' => 'International Science Olympiad', 'link' => 'international-Sciencepace-olympiad', 'fee_inr' => 175],
        ['name' => 'International Space Olympiad', 'link' => 'international-space-olympiad', 'fee_inr' => 400]
    ],
    // 11-12 will be handled by branch below
];

function getExamsByGradeAndBranch($grade, $branch, $config) {
    if ($grade >= 1 && $grade <= 4) return $config['1-4'];
    if ($grade >= 5 && $grade <= 10) return $config['5-10'];
    if ($grade == 11 || $grade == 12) {
        $branch = strtolower(trim($branch));
        if ($branch === 'science') {
            return [
                ['name' => 'International Physics Olympiad', 'link' => 'international-physics-olympiad', 'fee_inr' => 250],
                ['name' => 'International Chemistry Olympiad', 'link' => 'international-chemistry-olympiad', 'fee_inr' => 250],
                ['name' => 'International Mathematics Olympiad', 'link' => 'international-Mathematics-olympiad', 'fee_inr' => 250],
                ['name' => 'International Biology Olympiad', 'link' => 'international-biology-olympiad', 'fee_inr' => 250],
            ];
        } elseif ($branch === 'commerce') {
            return [
                ['name' => 'International English Olympiad', 'link' => 'international-English-olympiad', 'fee_inr' => 250],
                ['name' => 'International Commerce Olympiad', 'link' => 'international-commerce-olympiad', 'fee_inr' => 250],
            ];
        } elseif ($branch === 'arts') {
            return [
                ['name' => 'International English Olympiad', 'link' => 'international-English-olympiad', 'fee_inr' => 250],
                ['name' => 'International Geography Olympiad', 'link' => 'international-geography-olympiad', 'fee_inr' => 250],
                ['name' => 'International Economics Olympiad', 'link' => 'international-Economics-olympiad', 'fee_inr' => 250],
            ];
        } else {
            // If branch is not set or not applicable, show nothing or a message
            return [];
        }
    }
    return [];
}

$exams = getExamsByGradeAndBranch($grade, $branch, $exam_config);
?>
<?php
// Capture all GET parameters from the current URL
$urlParams = $_GET; // associative array
$queryString = http_build_query($urlParams); // converts array to query string
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Exams</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body { background-color: #f6f5f8; }
        .exam-container {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            margin-top: 30px;
            justify-content: center;
            max-height: 65vh; /* Set a max height for all devices */
            overflow-y: auto;  /* Add a vertical scrollbar when content overflows */
            padding: 10px; /* Add some padding around the cards */
        }
        /* Custom Scrollbar for Webkit browsers */
        .exam-container::-webkit-scrollbar {
            width: 8px;
        }
        .exam-container::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        .exam-container::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 10px;
        }
        .exam-container::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .exam-card { background-color: #6b186e; color: #fff; padding: 30px; border-radius: 10px; width: 280px; position: relative; box-shadow: 0 4px 10px rgba(0,0,0,0.2); transition: 0.3s; text-align: center; }
        .exam-card:hover { background-color: #7c1b80; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.9); }
        .fee-badge { position: absolute; top: 10px; right: 10px; background: #ffc107; color: #000; padding: 3px 10px; border-radius: 20px; font-weight: bold; font-size: 14px; }
        .exam-title { font-size: 18px; font-weight: bold; }
        /* Floating Cart Styles */
        .cart-box {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            display: none; /* Hidden by default */
        }
        .cart-fab {
            background: linear-gradient(135deg, #6b186e, #512da8);
            color: #fff;
            border-radius: 50px;
            padding: 15px 28px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 20px;
            transition: all 0.2s ease;
        }
        .cart-fab:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 16px rgba(0,0,0,0.3);
        }
        .cart-details {
            display: none;
            position: absolute;
            bottom: 70px;
            right: 0;
            background-color: #fff;
            color: #333;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.15);
            width: 320px;
        }
        .cart-items-list {
            list-style: none; padding: 0; margin: 0 0 15px 0;
            max-height: 150px; overflow-y: auto;
        }
        .cart-item {
            display: flex; justify-content: space-between; align-items: center;
            padding: 8px 0; border-bottom: 1px solid #eee;
        }
        .remove-item { cursor: pointer; color: #e74c3c; font-weight: bold; }
        .cart-total { font-weight: bold; font-size: 18px; text-align: right; margin-bottom: 15px; }
        @media (max-width: 991.98px) {
            .cart-box {
                left: 0; /* Full width on smaller screens */
            }
        }
        @media (max-width: 767.98px) {
            .exam-container {
                flex-direction: column;
                align-items: center;
                gap: 20px;
                max-height: calc(100vh - 220px); /* Specific height for mobile to avoid cart */
                -webkit-overflow-scrolling: touch;
                padding-bottom: 10px;
            }
            .exam-card { width: 95vw; padding: 18px; font-size: 15px; }
            .exam-title .olympiad-word { display: block; }
            .fee-badge { left: 10px; right: auto; }
        }
        @media (max-width: 575.98px) {
            .exam-card { font-size: 13px; padding: 10px; }
            .fee-badge { font-size: 12px; padding: 3px 7px; }
        }
    </style>
</head>
<body>

<div class="container">
    <h3 class="text-center mt-4 font-weight-bold text-dark" style="letter-spacing: 1px; font-size: 30px; margin-top: 48px !important;">Available Exams</h3>
    <div class="exam-container">
        <?php foreach ($exams as $exam): ?>
            <?php
            $isPaid = in_array($exam['name'], $paidExams);
            echo '<!-- Card: ' . $exam['name'] . ' | Paid: ' . ($isPaid ? 'YES' : 'NO') . ' -->';
            ?>
            <div class="exam-card">
                <div class="fee-badge">&#8377;<?= $exam['fee_inr'] ?></div>
                <div class="exam-title"><?= preg_replace('/\s+(Olympiad)/i', ' <span class="olympiad-word">$1</span>', $exam['name']) ?></div>
  <button class="btn mt-3 start-exam-btn <?= $isPaid ? 'btn-success' : 'btn-light' ?>"
        data-link="<?= $exam['link'] ?>"
        data-paid="<?= $isPaid ? '1' : '0' ?>"
        data-exam="<?= htmlspecialchars($exam['name']) ?>"
        data-params="<?= htmlspecialchars($queryString) ?>">
    Start Exam
</button>


                <?php if (!$isPaid): ?>
                    <button class="btn btn-warning mt-3 select-exam" data-name="<?= $exam['name'] ?>" data-fee="<?= $exam['fee_inr'] ?>">Select</button>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>




<div class="cart-box">
    <div class="cart-details" id="cartDetails">
        <h4>Your Cart</h4>
        <ul class="cart-items-list" id="cartItemsList"></ul>
        <div class="cart-total" id="cartTotal"></div>
        <form method="post" action="payment_process.php" id="paymentForm">
            <div id="selectedInputs"></div>
            <input type="hidden" name="total_amount" id="total_amount_hidden">
            <button type="submit" class="btn btn-success w-100">Proceed to Pay</button>
        </form>
    </div>
    <div class="cart-fab" id="cartFab">
        <span>🛒</span>
        <span id="cartItemCount" class=" fw-bold">0</span>
        <span>|</span>
        <span id="cartTotalPrice" class="ms-3 fw-bold">₹0</span>
        <span class="ms-3 fw-bold">PAY</span>
    </div>
</div>

<!-- Floating Scroll to Last Exam Button (Mobile Only) -->
<!-- <button id="scrollToLastExam" style="display:none;position:fixed;bottom:90px;right:18px;z-index:1100;padding:14px 18px;border-radius:50%;background:#6b186e;color:#fff;border:none;box-shadow:0 2px 8px rgba(0,0,0,0.18);font-size:22px;transition:background 0.2s;" title="Scroll to Last Exam">
    &#8595;
</button> -->

<script>
    const selectedExams = new Map();

    function updateCartDisplay() {
        const cartItemsList = $('#cartItemsList');
        const selectedInputs = $('#selectedInputs');
        cartItemsList.empty();
        selectedInputs.empty();
        let total = 0;

        selectedExams.forEach((fee, name) => {
            cartItemsList.append(`<li class="cart-item"><span>${name}</span><span class="remove-item" data-name="${name}">&times;</span></li>`);
            selectedInputs.append(`<input type="hidden" name="selected_exams[]" value="${name}">`);
            total += fee;
        });

        $('#cartItemCount').text(selectedExams.size);
        $('#cartTotalPrice').text(`₹${total}`);
        $('#cartTotal').text(`Total: ₹${total}`);
        $('#total_amount_hidden').val(total);

        if (selectedExams.size > 0) {
            $('.cart-box').fadeIn();
        } else {
            $('.cart-box').fadeOut();
            $('#cartDetails').hide(); // Hide details if cart is empty
        }
    }
    
    $('#cartFab').on('click', function() {
        $('#cartDetails').toggle();
    });

    $(document).on('click', '.select-exam', function () {
        const name = $(this).data('name');
        const fee = parseInt($(this).data('fee'));
        if (!selectedExams.has(name)) {
            selectedExams.set(name, fee);
            $(this).text('Remove').removeClass('btn-warning').addClass('btn-danger');
        } else {
            selectedExams.delete(name);
            $(this).text('Select').removeClass('btn-danger').addClass('btn-warning');
        }
        updateCartDisplay();
    });

    $(document).on('click', '.remove-item', function () {
        const name = $(this).data('name');
        selectedExams.delete(name);
        $(".select-exam[data-name='" + name.replace(/'/g, "\\'") + "']")
            .text('Select')
            .removeClass('btn-danger')
            .addClass('btn-warning');
        updateCartDisplay();
    });
$(document).on('click', '.start-exam-btn', function () {
    var paid = $(this).data('paid');
    var link = $(this).data('link');
    var params = $(this).data('params'); // all GET params
    var examName = encodeURIComponent($(this).data('exam')); // get exam name

    if (paid == '1') {
        alert("🎉 Payment Successful!\nExams will be held after a few days by the Olympiad Examination Council. Stay tuned!\n\nOK");
        // Redirect to instruction page with all original URL params + exam name
        window.location.href = "student_dash.php?next=" + encodeURIComponent(link) + "&exam_name=" + examName + "&" + params;
    } else {
        alert('Please pay the exam fee to start the exam.');
    }
});

    // Show/hide scroll button on mobile and handle scroll
    function updateScrollButtonVisibility() {
        if (window.innerWidth <= 767 && $('.exam-card').length > 1) {
            $('#scrollToLastExam').show();
        } else {
            $('#scrollToLastExam').hide();
        }
    }

    $(window).on('resize', updateScrollButtonVisibility);
    $(document).ready(function() {
        updateScrollButtonVisibility();
        $('#scrollToLastExam').on('click', function() {
            var $lastCard = $('.exam-card:last');
            if ($lastCard.length) {
                // Scroll the page to the last card
                $('html, body').animate({
                    scrollTop: $lastCard.offset().top - 20 // 20px padding from top
                }, 500);
            }
        });

        // Gesture-based scroll-to-bottom (swipe down)
        let touchStartY = null;
        let touchStartTime = null;
        $('.exam-container').on('touchstart', function(e) {
            if (e.originalEvent.touches.length === 1) {
                touchStartY = e.originalEvent.touches[0].clientY;
                touchStartTime = Date.now();
            }
        });
        $('.exam-container').on('touchend', function(e) {
            if (touchStartY !== null && e.originalEvent.changedTouches.length === 1) {
                let touchEndY = e.originalEvent.changedTouches[0].clientY;
                let touchEndTime = Date.now();
                let deltaY = touchEndY - touchStartY;
                let deltaTime = touchEndTime - touchStartTime;
                // Detect a quick swipe down (at least 80px in under 400ms)
                if (deltaY > 80 && deltaTime < 400) {
                    var $lastCard = $('.exam-card:last');
                    if ($lastCard.length) {
                        $('html, body').animate({
                            scrollTop: $lastCard.offset().top - 20
                        }, 500);
                    }
                }
            }
            touchStartY = null;
            touchStartTime = null;
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
