<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('registration/db.php'); // replace with your actual DB config

// Ensure user is logged in
if (!isset($_SESSION['RegID'])) {
    echo "<div style='color:red;'>You must be logged in to change your password.</div>";
    exit;
}

$regID = $_SESSION['RegID'];
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $currentpass = trim($_POST['currentpass'] ?? '');
    $newpass = trim($_POST['pass'] ?? '');
    $confirmpass = trim($_POST['cpass'] ?? '');

    // Basic validations
    if (strlen($newpass) < 6 || strlen($newpass) > 15) {
        $error = "New password must be 6 to 15 characters.";
    } elseif ($newpass !== $confirmpass) {
        $error = "New password and confirm password do not match.";
    } else {
        // Fetch current hashed password
        $stmt = $conn->prepare("SELECT S_Pass FROM olympiad_registrations WHERE RegID = ?");
        $stmt->bind_param("i", $regID);
        $stmt->execute();
        $stmt->bind_result($storedHash);

        if ($stmt->fetch()) {
            if (password_verify($currentpass, $storedHash)) {
                $stmt->close(); // ✅ Close before creating another statement

                // Update new password
                $newHash = password_hash($newpass, PASSWORD_DEFAULT);
                $update = $conn->prepare("UPDATE olympiad_registrations SET S_Pass = ? WHERE RegID = ?");
                $update->bind_param("si", $newHash, $regID);

                if ($update->execute()) {
                    $success = "Password updated successfully.";
                } else {
                    $error = "Failed to update password. Please try again.";
                }
                $update->close();
            } else {
                $error = "Current password is incorrect.";
                $stmt->close();
            }
        } else {
            $error = "User not found.";
            $stmt->close();
        }
    }
}
?>

<!-- HTML Form -->
<div class="card" style="max-width:500px;margin:auto;margin-top:80px;">
    <div class="card-body">
        <h4 class="text-center mb-6">Change Password</h4>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php elseif ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="form-group mb-3">
                <input type="password" name="currentpass" class="form-control" placeholder="Enter Current Password" required>
            </div>
            <div class="form-group mb-3">
                <input type="password" name="pass" class="form-control" placeholder="Enter New Password" required>
            </div>
            <div class="form-group mb-4">
                <input type="password" name="cpass" class="form-control" placeholder="Enter Confirm Password" required>
            </div>
            <button type="submit" class="btn btn-danger btn-block w-100">UPDATE</button>
        </form>
    </div>
</div>

<!-- CSS -->
<style>
body {
    background-color: #f2f2f2;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
}

.card {
    background: #ffffff;
    border-radius: 10px;
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
    padding: 40px 30px;
}

.card-body h4 {
    font-weight: bold;
    color: #222;
    text-align: center;
    margin-bottom: 30px;
}

.form-control {
    height: 45px;
    font-size: 16px;
    border-radius: 5px;
    border: 1px solid #ccc;
}

.btn-danger {
    background-color: #e53935;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    padding: 10px;
    transition: background-color 0.3s ease;
}

.btn-danger:hover {
    background-color: #d32f2f;
    cursor: pointer;
}

.alert {
    padding: 10px 15px;
    border-radius: 5px;
    font-size: 15px;
    margin-bottom: 15px;
}

.alert-danger {
    background-color: #f8d7da;
    color: #721c24;
}

.alert-success {
    background-color: #d4edda;
    color: #155724;
}
</style>
