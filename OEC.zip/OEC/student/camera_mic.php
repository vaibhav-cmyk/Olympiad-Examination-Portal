<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam System Check</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen p-4 font-inter text-gray-800">

    <div class="bg-white rounded-2xl shadow-xl p-8 max-w-lg w-full text-center border-t-8 border-blue-500">
        <h1 class="text-3xl font-bold text-blue-600 mb-2">System Check</h1>
        <p class="text-gray-600 mb-8">Confirm your camera and microphone are working before the exam begins.</p>

        <div class="flex flex-col sm:flex-row justify-around items-center space-y-8 sm:space-y-0 sm:space-x-8">
            <!-- Camera Status & Video Feed -->
            <div class="flex flex-col items-center w-full">
                <div class="w-full bg-gray-200 rounded-lg overflow-hidden border-2 border-gray-300">
                    <video id="videoFeed" class="w-full h-auto" autoplay muted playsinline></video>
                </div>
                <div class="mt-4 text-xl font-medium">Camera: <span id="cameraStatus" class="text-yellow-600">Checking...</span></div>
            </div>

            <!-- Microphone Status -->
            <div class="flex flex-col items-center mt-8 sm:mt-0 w-full">
                <div class="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mb-2">
                    <span id="micIcon" class="text-5xl text-gray-500" role="img" aria-label="Microphone Icon">🎤</span>
                </div>
                <div class="text-xl font-medium">Microphone: <span id="micStatus" class="text-yellow-600">Checking...</span></div>
            </div>
        </div>

        <p id="infoMessage" class="text-gray-500 text-sm mt-8">Please grant permission to access your devices.</p>
        
        <button id="fullscreenButton" class="w-full mt-6 px-6 py-3 bg-blue-500 text-white font-bold rounded-lg shadow-lg hover:bg-blue-600 transition-colors duration-300 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-300">
            Enter Exam Now
        </button>
        <p id="fullscreenInfo" class="text-xs text-gray-400 mt-2 hidden">Press <kbd class="px-1 py-0.5 rounded-md bg-gray-200 text-gray-700">ESC</kbd> to exit fullscreen.</p>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const videoFeed = document.getElementById('videoFeed');
            const cameraStatus = document.getElementById('cameraStatus');
            const micStatus = document.getElementById('micStatus');
            const micIcon = document.getElementById('micIcon');
            const infoMessage = document.getElementById('infoMessage');
            const fullscreenBtn = document.getElementById('fullscreenButton');

            // Function to request and display media stream
            const getMedia = async () => {
                try {
                    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
                    videoFeed.srcObject = stream;
                    cameraStatus.textContent = 'On';
                    cameraStatus.className = 'text-green-600';
                    micStatus.textContent = 'On';
                    micStatus.className = 'text-green-600';
                    micIcon.className = 'text-5xl text-green-500';
                    infoMessage.textContent = "Your camera and microphone are working. You are not being recorded.";
                } catch (err) {
                    console.error("Error accessing media devices:", err);
                    cameraStatus.textContent = 'Off';
                    cameraStatus.className = 'text-red-600';
                    micStatus.textContent = 'Off';
                    micStatus.className = 'text-red-600';
                    micIcon.className = 'text-5xl text-red-500';
                    if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
                        infoMessage.textContent = "Access denied. Please enable camera/mic permissions in your browser settings to continue.";
                    } else if (err.name === "NotFoundError") {
                        infoMessage.textContent = "No camera or microphone found. Please connect a device and try again.";
                    } else {
                        infoMessage.textContent = "An error occurred. Please refresh the page and try again.";
                    }
                }
            };

            // Start the media check
            getMedia();

            // Fullscreen + Redirect logic
            fullscreenBtn.addEventListener('click', () => {
                console.log("Attempting to enter fullscreen...");
                const element = document.documentElement;
                if (element.requestFullscreen) {
                    element.requestFullscreen();
                } else if (element.mozRequestFullScreen) { // Firefox
                    element.mozRequestFullScreen();
                } else if (element.webkitRequestFullscreen) { // Chrome, Safari, Opera
                    element.webkitRequestFullscreen();
                } else if (element.msRequestFullscreen) { // IE/Edge
                    element.msRequestFullscreen();
                }

                document.getElementById('fullscreenInfo').classList.remove('hidden');

                // Redirect to exam_module.php with same query params
                const params = new URLSearchParams(window.location.search);
                window.location.href = "exam_module.php?" + params.toString();
            });

            document.addEventListener('fullscreenchange', () => {
                if (!document.fullscreenElement) {
                    document.getElementById('fullscreenInfo').classList.add('hidden');
                }
            });
        });
    </script>
</body>
</html>
