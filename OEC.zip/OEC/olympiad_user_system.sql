-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 23, 2025 at 09:16 PM
-- Server version: 10.6.21-MariaDB
-- PHP Version: 8.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `olympiad_user_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `id` int(11) NOT NULL,
  `donor_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `pan` varchar(10) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `fund_type` varchar(50) NOT NULL,
  `message` text DEFAULT NULL,
  `payment_status` varchar(20) DEFAULT 'pending',
  `payment_reference` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `downloads`
--

CREATE TABLE `downloads` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_otps`
--

CREATE TABLE `email_otps` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `otp` varchar(6) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `email_otps`
--

INSERT INTO `email_otps` (`id`, `email`, `otp`, `expires_at`, `created_at`) VALUES
(66, 'shridharp921@gmail.com', '375295', '2025-07-22 16:17:19', '2025-07-22 14:07:19'),
(67, 'shridharpatil723@gmail.com', '162992', '2025-07-27 12:24:07', '2025-07-27 06:44:07'),
(68, 'shridharpatil723@gmail.com', '332375', '2025-07-27 12:39:03', '2025-07-27 06:59:03'),
(69, 'shridharpatil723@gmail.com', '989572', '2025-07-27 12:39:12', '2025-07-27 06:59:12'),
(70, 'shridharpatil723@gmail.com', '944221', '2025-07-27 12:42:45', '2025-07-27 07:02:45'),
(71, 'shridharpatil723@gmail.com', '175357', '2025-07-27 12:51:31', '2025-07-27 07:11:31'),
(72, 'shridharpatil723@gmail.com', '910016', '2025-07-27 12:53:37', '2025-07-27 07:13:37'),
(73, 'shridharpatil723@gmail.com', '517706', '2025-07-27 12:53:41', '2025-07-27 07:13:41'),
(74, 'shridharpatil723@gmail.com', '347641', '2025-07-27 13:01:54', '2025-07-27 07:21:54'),
(75, 'shridharpatil723@gmail.com', '796950', '2025-07-27 13:03:17', '2025-07-27 07:23:17'),
(76, 'eqopamajoco07@gmail.com', '135424', '2025-07-27 17:59:20', '2025-07-27 12:19:20'),
(77, 'utotaquqocid26@gmail.com', '967429', '2025-07-27 23:23:40', '2025-07-27 17:43:40'),
(78, 'shridharpatil723@gmail.com', '520111', '2025-07-28 10:55:03', '2025-07-28 05:15:03'),
(79, 'shridharpatil723@gmail.com', '978639', '2025-07-28 10:55:07', '2025-07-28 05:15:07'),
(80, 'shridharpatil723@gmail.com', '695456', '2025-07-28 10:58:27', '2025-07-28 05:18:27'),
(81, 'shridharpatil723@gmail.com', '618384', '2025-07-28 11:07:33', '2025-07-28 05:27:33'),
(82, 'shridharpatil723@gmail.com', '343670', '2025-07-28 11:17:06', '2025-07-28 05:37:06'),
(83, 'mmetx19@gmail.com', '863564', '2025-07-28 23:27:14', '2025-07-28 17:47:14'),
(84, 'ehipeyul255@gmail.com', '617986', '2025-07-29 02:25:47', '2025-07-28 20:45:47'),
(85, 'shridharp921@gmail.com', '864162', '2025-08-20 15:47:14', '2025-08-20 10:07:14'),
(86, 'shridharp921@gmail.com', '394145', '2025-08-20 15:47:23', '2025-08-20 10:07:23'),
(87, 'shridharp921@gmail.com', '434184', '2025-08-20 15:47:42', '2025-08-20 10:07:42'),
(88, 'shridharpatil723@gmail.com', '111207', '2025-08-20 15:59:02', '2025-08-20 10:19:02'),
(89, 'shridharpatil723@gmail.com', '107201', '2025-08-20 15:59:22', '2025-08-20 10:19:22'),
(90, 'mathsbio@gmail.com', '188504', '2025-08-20 16:18:51', '2025-08-20 10:38:51'),
(91, 'tunisulu26@gmail.com', '313103', '2025-08-20 19:53:21', '2025-08-20 14:13:21'),
(92, 'vaib9483@gmail.com', '128635', '2025-08-20 21:58:42', '2025-08-20 16:18:42'),
(93, 'shridharpatil723@gmail.com', '201307', '2025-08-20 23:13:14', '2025-08-20 17:33:14'),
(94, 'shridharp921@gmail.com', '564391', '2025-08-20 23:18:49', '2025-08-20 17:38:49'),
(95, 'parthugarifranklin@gmail.com', '754929', '2025-08-21 06:04:10', '2025-08-21 00:24:10'),
(96, 'parthugarifranklin@gmail.com', '957684', '2025-08-21 06:06:55', '2025-08-21 00:26:55'),
(97, 'olympiadexaminationcouncil@gmail.com', '294740', '2025-08-21 07:35:08', '2025-08-21 01:55:08'),
(98, 'vaibhavatiwadkat7338@gmail.com', '655728', '2025-08-21 10:23:14', '2025-08-21 04:43:14'),
(99, 'heranot581@gmail.com', '436125', '2025-08-21 15:01:23', '2025-08-21 09:21:23'),
(100, 'virgiespi12@gmail.com', '498849', '2025-08-22 05:08:06', '2025-08-21 23:28:06'),
(101, 'salazarmaksaini@gmail.com', '901592', '2025-08-22 07:53:21', '2025-08-22 02:13:21'),
(102, 'deitkentx1989@gmail.com', '780266', '2025-08-22 15:51:10', '2025-08-22 10:11:10'),
(103, 'afomufivik35@gmail.com', '544503', '2025-08-23 13:06:48', '2025-08-23 07:26:48');

-- --------------------------------------------------------

--
-- Table structure for table `indian_schools`
--

CREATE TABLE `indian_schools` (
  `id` int(11) NOT NULL,
  `school_id` varchar(20) NOT NULL,
  `udise_code` varchar(20) NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `state` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `taluka` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) DEFAULT NULL,
  `school_type` varchar(50) NOT NULL,
  `school_level` varchar(50) NOT NULL,
  `affiliation` varchar(50) NOT NULL,
  `area` varchar(20) DEFAULT NULL,
  `grade_from` int(11) NOT NULL,
  `grade_to` int(11) NOT NULL,
  `total_students` int(11) NOT NULL,
  `total_teachers` int(11) NOT NULL,
  `principal_name` varchar(255) NOT NULL,
  `principal_mobile` varchar(20) NOT NULL,
  `teacher_incharge_name` varchar(255) DEFAULT NULL,
  `teacher_incharge_mobile` varchar(20) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `indian_schools`
--

INSERT INTO `indian_schools` (`id`, `school_id`, `udise_code`, `school_name`, `address`, `state`, `district`, `taluka`, `city`, `contact_number`, `email`, `website`, `school_type`, `school_level`, `affiliation`, `area`, `grade_from`, `grade_to`, `total_students`, `total_teachers`, `principal_name`, `principal_mobile`, `teacher_incharge_name`, `teacher_incharge_mobile`, `password_hash`, `created_at`) VALUES
(1, 'OEC20250001', '29010304212', 'Marathi Vidyaniketan Higher Primay Belgaum ', 'Jyoti college compound, camp Belgaum', 'Karnataka', 'Belgaum', 'Belgaum', 'Belgaum', '8050388604', 'neeluapte512@gmail.com', '-', 'Government', 'Primary', 'State Board', 'Urban', 1, 7, 774, 7, 'B.J. Patil ', '8792134363', 'Nila Apte', '9405924227', '$2y$10$YWCi6ebAeAfDTySA/D9m/up56bJBbyIv77/d2KebA3WId0OMNWUWa', '2025-08-21 09:44:29'),
(3, 'OEC20250003', '29010305938', 'Marathi Vidyaniketan Highschool Belgaum ', 'Jyoti College Compound,  camp belgaum', 'Karnataka', 'Belgaum', 'Belgaum', 'Belgaum', '8050388604', 'marathividyaniketan@gmail.com', '-', 'Private', 'High School', 'State Board', 'Urban', 8, 10, 306, 2147483647, 'Narayan udakekar ', '7353972033', 'Anjali babugavade', '8792948285', '$2y$10$x6wHYxnqAjtO70hbGZ2MReiSbXz6rpiALCZBc8X.KhscypG3DGyo.', '2025-08-21 10:04:19'),
(4, 'OEC20250004', '27340956903', 'Kumar Bhavan Pushpanagar ', 'Pushpanagar ', 'Maharashtra', 'Kolhapur', 'Bhudargad', 'Pushpanagar ', '9423272969', 'kumarbhavanpushpanagar5@gmail.com', '-', 'Semi Government', 'High School', 'State Board', 'Rural', 5, 10, 370, 13, 'N J Chavan ', '9422624770', 'Desai D B', '9423272969', '$2y$10$NqhPcE8D/.i7PUuXsa5x/eRVsT1eKL/PdooPVdtA8c96vcwB8SvPi', '2025-08-22 03:43:07'),
(5, 'OEC20250005', '27341109502', 'Jagruti prathmik vidyamandir gadhinglj', 'Bhadgaon road gadhinglj', 'Maharashtra', 'Kolhapur', 'Gadhinglj', 'Gadhinglj', '8007656838', 'ajarimala1668@gmail.com', '-', 'Private', 'Primary', 'State Board', 'Rural', 0, 0, 273, 4, 'Mala Satish Ajari', '8007656838', 'Sarika bhart bnsode', '8888704222', '$2y$10$BnuPPxziSmWcpAQUum9jaenjwNwRyA1hf.Ue2k90m45yL0N1mSgqy', '2025-08-22 10:00:06');

-- --------------------------------------------------------

--
-- Table structure for table `international_schools`
--

CREATE TABLE `international_schools` (
  `id` int(11) UNSIGNED NOT NULL,
  `school_id` varchar(20) NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `country` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `zip` varchar(20) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) DEFAULT NULL,
  `school_type` varchar(50) DEFAULT NULL,
  `school_level` varchar(50) DEFAULT NULL,
  `accreditation` varchar(255) DEFAULT NULL,
  `grade_from` int(11) DEFAULT NULL,
  `grade_to` int(11) DEFAULT NULL,
  `total_students` int(11) DEFAULT NULL,
  `total_teachers` int(11) DEFAULT NULL,
  `principal_name` varchar(255) DEFAULT NULL,
  `principal_mobile` varchar(20) DEFAULT NULL,
  `principal_email` varchar(255) DEFAULT NULL,
  `teacher_name` varchar(255) DEFAULT NULL,
  `teacher_mobile` varchar(20) DEFAULT NULL,
  `teacher_email` varchar(255) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `link` varchar(500) DEFAULT NULL,
  `posted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `title`, `message`, `link`, `posted_at`) VALUES
(5, '🌟 Exciting Update Released!', 'Message: We’re thrilled to announce the release of an exciting new update packed with powerful features and improvements designed just for you! From a cleaner interface to enhanced performance and brand-new tools, this update is all about making your experience faster, smoother, and more enjoyable. Don’t miss out—explore what’s new and see how it can help you achieve more today.', 'https://example.com/whats-new', '2025-07-04 05:22:14');

-- --------------------------------------------------------

--
-- Table structure for table `olympiad_registration`
--

CREATE TABLE `olympiad_registration` (
  `Student_ID` varchar(20) NOT NULL,
  `Stud_name` varchar(100) NOT NULL,
  `Parent_name` varchar(100) NOT NULL,
  `Stud_dob` date NOT NULL,
  `Gender` enum('Male','Female','Other') NOT NULL,
  `Home_addr` text NOT NULL,
  `MobileNo` varchar(15) NOT NULL,
  `WhatsAppNo` varchar(15) DEFAULT NULL,
  `Country` varchar(100) NOT NULL,
  `Email_ID` varchar(150) NOT NULL,
  `S_Cname` varchar(150) NOT NULL,
  `S_Caddr` text DEFAULT NULL,
  `Grade` tinyint(4) NOT NULL,
  `C_Branch` varchar(50) DEFAULT NULL,
  `Exam_Lg` enum('English','Spanish','French') NOT NULL,
  `S_Pass` varchar(255) NOT NULL,
  `Registered_At` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `olympiad_registrations`
--

CREATE TABLE `olympiad_registrations` (
  `RegID` int(11) NOT NULL,
  `RegNo` int(11) DEFAULT NULL,
  `Stud_name` varchar(255) NOT NULL,
  `Parent_name` varchar(255) NOT NULL,
  `Stud_dob` date NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Home_addr` text NOT NULL,
  `Country` varchar(50) NOT NULL,
  `S_State` varchar(50) NOT NULL,
  `District` varchar(50) NOT NULL,
  `MobileNo` varchar(15) NOT NULL,
  `WhatsAppNo` varchar(15) NOT NULL,
  `Email_ID` varchar(100) NOT NULL,
  `S_Cname` varchar(255) NOT NULL,
  `S_Caddr` text NOT NULL,
  `S_Cat` varchar(50) NOT NULL,
  `Grade` varchar(10) NOT NULL,
  `C_Branch` varchar(50) NOT NULL,
  `Exam_Lg` varchar(50) NOT NULL,
  `S_Pass` varchar(255) NOT NULL,
  `AccountStatus` enum('Active','Inactive') DEFAULT 'Inactive',
  `Exam` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_transactions`
--

CREATE TABLE `payment_transactions` (
  `TransactionID` int(11) NOT NULL,
  `RegID` int(11) NOT NULL,
  `Exam` varchar(255) NOT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `PaymentID` varchar(100) DEFAULT NULL,
  `PaymentStatus` enum('Pending','Success','Failed') DEFAULT 'Pending',
  `PaymentDate` datetime DEFAULT current_timestamp(),
  `PaymentMode` enum('Online','Offline') DEFAULT 'Online',
  `AccountStatus` enum('Active','Inactive') DEFAULT 'Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `class` int(11) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `language` varchar(50) DEFAULT NULL,
  `section` varchar(50) DEFAULT NULL,
  `question` text DEFAULT NULL,
  `option_a` text DEFAULT NULL,
  `option_b` text DEFAULT NULL,
  `option_c` text DEFAULT NULL,
  `option_d` text DEFAULT NULL,
  `correct_answer` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `full_name`, `email`, `phone`, `position`, `department`, `username`, `password`, `created_at`) VALUES
(1, 'Vishal Patil', 'vishal@gmail.com', '9730185971', 'Staff', 'Back office', 'vishal@gmail.com', '$2y$10$QsG0e7NzZjdLzEMTnsDnxOk5ES5ksqMmODWAzlO8KDBgTbSJlWkzC', '2025-08-22 02:07:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `downloads`
--
ALTER TABLE `downloads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_otps`
--
ALTER TABLE `email_otps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `indian_schools`
--
ALTER TABLE `indian_schools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `udise_code` (`udise_code`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `school_id` (`school_id`);

--
-- Indexes for table `international_schools`
--
ALTER TABLE `international_schools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `school_id` (`school_id`);

--
-- Indexes for table `olympiad_registrations`
--
ALTER TABLE `olympiad_registrations`
  ADD PRIMARY KEY (`RegID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `email_otps`
--
ALTER TABLE `email_otps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `indian_schools`
--
ALTER TABLE `indian_schools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `international_schools`
--
ALTER TABLE `international_schools`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `olympiad_registrations`
--
ALTER TABLE `olympiad_registrations`
  MODIFY `RegID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
