<?php
$email = 'student@example.com'; // <-- Change to your student's email
$newPassword = 'yournewpassword'; // <-- Set your new password

$hash = password_hash($newPassword, PASSWORD_DEFAULT);

$conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$stmt = $conn->prepare("UPDATE olympiad_registration SET S_Pass=? WHERE Email_ID=?");
$stmt->bind_param("ss", $hash, $email);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo "Password updated!";
} else {
    echo "No user found or password not updated.";
}

$stmt->close();
$conn->close();
?>