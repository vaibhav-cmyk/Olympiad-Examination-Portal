<?php
session_start();
require_once 'config.php';
require_once 'db_connect.php';

// Check if user is logged in
if (!isset($_SESSION['IS_LOGIN']) || !isset($_SESSION['RegID'])) {
    header("Location: index.php");
    exit();
}

// Get the error details from Razorpay
$error_code = $_GET['error_code'] ?? '';
$error_description = $_GET['error_description'] ?? '';
$error_source = $_GET['error_source'] ?? '';
$error_step = $_GET['error_step'] ?? '';
$error_reason = $_GET['error_reason'] ?? '';

// Get session data
$selectedExams = $_SESSION['selected_exams'] ?? [];
$totalAmount = $_SESSION['total_amount'] ?? 0;
$orderId = $_SESSION['razorpay_order_id'] ?? '';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Payment Failed</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .failed-container {
            background: white;
            padding: 3rem;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
            width: 90%;
            max-width: 600px;
            text-align: center;
        }
        .failed-icon {
            font-size: 4rem;
            color: #e74c3c;
            margin-bottom: 1rem;
        }
        .failed-heading {
            color: #2c3e50;
            font-size: 2.5rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
        }
        .error-details {
            background: #f8f9fa;
            padding: 2rem;
            border-radius: 15px;
            margin: 2rem 0;
            text-align: left;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin: 0.5rem 0;
            padding: 0.5rem 0;
            border-bottom: 1px solid #e9ecef;
        }
        .detail-label {
            font-weight: 600;
            color: #495057;
        }
        .detail-value {
            color: #6c757d;
        }
        .exam-list {
            list-style: none;
            padding: 0;
            margin: 1rem 0;
        }
        .exam-item {
            background: #fff;
            padding: 0.75rem 1rem;
            margin: 0.5rem 0;
            border-radius: 8px;
            border-left: 4px solid #e74c3c;
            color: #2c3e50;
        }
        .button-group {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
            flex-wrap: wrap;
        }
        .retry-button {
            background: linear-gradient(135deg, #3498db, #2ecc71);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 25px;
            font-size: 1.1rem;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: transform 0.2s;
        }
        .retry-button:hover {
            transform: translateY(-2px);
        }
        .dashboard-button {
            background: linear-gradient(135deg, #95a5a6, #7f8c8d);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 25px;
            font-size: 1.1rem;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: transform 0.2s;
        }
        .dashboard-button:hover {
            transform: translateY(-2px);
        }
        .error-message {
            background: #fdf2f2;
            border: 1px solid #fecaca;
            color: #dc2626;
            padding: 1rem;
            border-radius: 8px;
            margin: 1rem 0;
        }
    </style>
</head>
<body>
    <div class="failed-container">
        <div class="failed-icon">❌</div>
        <h2 class="failed-heading">Payment Failed</h2>
        
        <div class="error-details">
            <?php if (!empty($error_description)): ?>
                <div class="error-message">
                    <strong>Error:</strong> <?php echo htmlspecialchars($error_description); ?>
                </div>
            <?php endif; ?>
            
            <div class="detail-row">
                <span class="detail-label">Order ID:</span>
                <span class="detail-value"><?php echo htmlspecialchars($orderId); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Amount:</span>
                <span class="detail-value">$<?php echo htmlspecialchars($totalAmount); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Date:</span>
                <span class="detail-value"><?php echo date('d M Y, h:i A'); ?></span>
            </div>
            
            <?php if (!empty($selectedExams)): ?>
                <h4 style="color: #2c3e50; margin: 1.5rem 0 1rem 0;">Selected Exams:</h4>
                <ul class="exam-list">
                    <?php foreach ($selectedExams as $exam): ?>
                        <li class="exam-item"><?php echo htmlspecialchars($exam); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
        
        <p style="color: #6c757d; margin: 2rem 0;">
            Your payment was not completed. No charges have been made to your account.
        </p>
        
        <div class="button-group">
            <a href="payment_process.php" class="retry-button">Try Again</a>
            <a href="student_dash.php" class="dashboard-button">Return to Dashboard</a>
        </div>
    </div>
</body>
</html>

<?php
// Clear session data after showing the failure page
unset($_SESSION['selected_exams']);
unset($_SESSION['total_amount']);
unset($_SESSION['payment_amount']);
unset($_SESSION['razorpay_order_id']);
?> 