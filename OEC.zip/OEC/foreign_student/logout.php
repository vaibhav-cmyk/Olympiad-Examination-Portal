<?php
session_start();

// Unset all session variables
$_SESSION = [];

// Explicitly unset only relevant variables if needed
unset($_SESSION['RegID']);
unset($_SESSION['Stud_name']);
unset($_SESSION['Email_ID']);
unset($_SESSION['Grade']);
unset($_SESSION['C_Branch']);
unset($_SESSION['Country']);

// Destroy the session
session_destroy();

// Redirect to login page
header('Location: index.php');
exit;
?>
