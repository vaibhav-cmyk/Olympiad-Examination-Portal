<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('db_connect.php'); // This gives you $pdo (PDO object)

// Ensure user is logged in
if (!isset($_SESSION['student_id'])) {
    echo "<div style='color:red;'>You must be logged in to change your password.</div>";
    exit;
}

$regID = $_SESSION['student_id'];
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $currentpass = trim($_POST['currentpass'] ?? '');
    $newpass = trim($_POST['pass'] ?? '');
    $confirmpass = trim($_POST['cpass'] ?? '');

    // Basic validations
    if (strlen($newpass) < 6 || strlen($newpass) > 15) {
        $error = "New password must be 6 to 15 characters.";
    } elseif ($newpass !== $confirmpass) {
        $error = "New password and confirm password do not match.";
    } else {
        // Fetch current hashed password using PDO
        $stmt = $pdo->prepare("SELECT S_Pass FROM olympiad_registration WHERE Student_ID = ?");
        $stmt->execute([$regID]);
        $storedHash = $stmt->fetchColumn();

        if ($storedHash) {
            if (password_verify($currentpass, $storedHash)) {
                // Update new password
                $newHash = password_hash($newpass, PASSWORD_DEFAULT);
                $update = $pdo->prepare("UPDATE olympiad_registration SET S_Pass = ? WHERE Student_ID = ?");
                if ($update->execute([$newHash, $regID])) {
                    $success = "Password updated successfully.";
                } else {
                    $error = "Failed to update password. Please try again.";
                }
            } else {
                $error = "Current password is incorrect.";
            }
        } else {
            $error = "User not found.";
        }
    }
}
?>
<!-- ...existing HTML form and CSS... -->

<!-- HTML Form -->
<div class="card" style="max-width:500px;margin:auto;margin-top:80px;">
    <div class="card-body">
        <h4 class="text-center mb-6">Change Password</h4>
        <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
        <?php elseif ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="form-group mb-3">
                <input type="password" name="currentpass" class="form-control" placeholder="Enter Current Password"
                    required>
            </div>
            <div class="form-group mb-3">
                <input type="password" name="pass" class="form-control" placeholder="Enter New Password" required>
            </div>
            <div class="form-group mb-4">
                <input type="password" name="cpass" class="form-control" placeholder="Enter Confirm Password" required>
            </div>
            <button type="submit" class="btn btn-danger btn-block w-100">UPDATE</button>
        </form>
    </div>
</div>

<!-- CSS -->
<style>
body {
    background-color: #f2f2f2;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
}

.card {
    background: #ffffff;
    border-radius: 10px;
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
    padding: 40px 30px;
}

.card-body h4 {
    font-weight: bold;
    color: #222;
    text-align: center;
    margin-bottom: 30px;
}

.form-control {
    height: 45px;
    font-size: 16px;
    border-radius: 5px;
    border: 1px solid #ccc;
}

.btn-danger {
    background-color: #e53935;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    padding: 10px;
    transition: background-color 0.3s ease;
}

.btn-danger:hover {
    background-color: #d32f2f;
    cursor: pointer;
}

.alert {
    padding: 10px 15px;
    border-radius: 5px;
    font-size: 15px;
    margin-bottom: 15px;
}

.alert-danger {
    background-color: #f8d7da;
    color: #721c24;
}

.alert-success {
    background-color: #d4edda;
    color: #155724;
}
</style>
<script>
// Disable Right-Click
document.addEventListener("contextmenu", function(e) {
    e.preventDefault();
    alert(
        "⚠️🚫 Right-click is disabled!\n\n🔒 This is an official website of Olympiad Examination Council.\n🛑 Any malicious activity is strictly prohibited.\n👮‍♂️ Legal action will be taken against offenders.");
});

// Disable DevTools, View Source, etc.
document.addEventListener("keydown", function(e) {
    if (
        e.keyCode === 123 || // F12
        (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I/J
        (e.ctrlKey && e.keyCode === 85) // Ctrl+U
    ) {
        e.preventDefault();
        alert(
            "🚫⚠️ This action is disabled for security reasons.\n\n🔐 Unauthorized inspection or tampering is forbidden.\n👮‍♂️ Violators may face strict legal consequences.");
    }
});
</script>