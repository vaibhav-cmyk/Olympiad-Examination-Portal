CREATE TABLE `olympiad_registration` (
  `Student_ID` varchar(20) NOT NULL,
  `Stud_name` varchar(100) NOT NULL,
  `Parent_name` varchar(100) NOT NULL,
  `Stud_dob` date NOT NULL,
  `Gender` tinyint(4) NOT NULL,
  `Home_addr` text NOT NULL,
  `MobileNo` varchar(15) NOT NULL,
  `WhatsAppNo` varchar(15) DEFAULT NULL,
  `Country` varchar(100) NOT NULL,
  `Email_ID` varchar(150) NOT NULL,
  `S_Cname` varchar(150) NOT NULL,
  `S_Caddr` text DEFAULT NULL,
  `Grade` tinyint(4) NOT NULL,
  `C_Branch` varchar(50) DEFAULT NULL,
  `Exam_Lg` tinyint(4) NOT NULL,
  `S_Pass` varchar(255) NOT NULL,
  `Registered_At` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;