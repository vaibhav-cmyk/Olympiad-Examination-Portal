<?php
class RazorpayAPI {
    private $key_id;
    private $key_secret;
    private $base_url = 'https://api.razorpay.com/v1/';

    public function __construct($key_id, $key_secret) {
        $this->key_id = $key_id;
        $this->key_secret = $key_secret;
    }

    public function createOrder($data) {
        $url = $this->base_url . 'orders';
        
        $postData = json_encode($data);
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Basic ' . base64_encode($this->key_id . ':' . $this->key_secret)
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            return json_decode($response, true);
        } else {
            throw new Exception('Failed to create order: ' . $response);
        }
    }

    public function verifyPaymentSignature($attributes) {
        $razorpay_order_id = $attributes['razorpay_order_id'];
        $razorpay_payment_id = $attributes['razorpay_payment_id'];
        $razorpay_signature = $attributes['razorpay_signature'];
        
        $expected_signature = hash_hmac('sha256', $razorpay_order_id . "|" . $razorpay_payment_id, $this->key_secret);
        
        return hash_equals($expected_signature, $razorpay_signature);
    }
}
?> 