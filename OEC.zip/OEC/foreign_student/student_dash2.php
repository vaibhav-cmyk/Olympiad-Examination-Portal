<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['IS_LOGIN'])) {
    header("Location: index.php");
    exit();
}



// $conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");
$conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$stmt = $conn->prepare("SELECT * FROM olympiad_registration WHERE Student_ID = ?");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("s", $_SESSION['student_id']);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $student = $result->fetch_assoc();
    // Update session with latest info
    $_SESSION['grade'] = $student['Grade'] ?? null;
    $_SESSION['C_Branch'] = $student['C_Branch'] ?? null;
    $_SESSION['country'] = $student['Country'] ?? null;
} else {
    // Fallback for testing
    $student = ['Stud_name' => 'Test Student'];
    // echo "Student data not found.";
    // exit();
}

$stmt->close();
$conn->close();

$page = $_GET['page'] ?? 'dashboard';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Student Dashboard - OEC</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --gradient-start: #8e44ad;
            --gradient-end: #d81b60;
            --accent-color: #ffc107;
            --text-light: #ffffff;
            --text-dark: #333;
            --bg-light: #f4f7f6;
            --sidebar-accent-hover: rgba(0, 0, 0, 0.2);
            --classy-gradient: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
        }

        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-dark);
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background: var(--classy-gradient);
            position: fixed;
            color: var(--text-light);
            transition: left 0.3s ease-in-out;
            left: 0;
            z-index: 1050;
            display: flex;
            flex-direction: column;
        }

        .sidebar.collapsed {
            left: -250px;
        }

        .sidebar .profile {
            padding: 20px;
            background: rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        .sidebar .profile h5 {
            margin: 10px 0 0;
            font-weight: 600;
            letter-spacing: 0.5px;
            color: var(--accent-color); /* Updated Color */
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
            flex-grow: 1;
            margin-top: 1rem;
        }

        .sidebar ul a {
            display: block;
            padding: 15px 25px;
            color: var(--text-light);
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .sidebar ul a:hover,
        .sidebar ul a.active {
            background: var(--sidebar-accent-hover);
            border-left: 4px solid var(--accent-color);
            color: #fff;
        }

        .sidebar ul li i {
            margin-right: 15px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            margin-left: 250px;
            padding: 2rem;
            background: var(--bg-light);
            min-height: 100vh;
            transition: margin-left 0.3s ease-in-out;
        }

        .main-content.expanded {
            margin-left: 0;
        }

        .header {
            background: #fff;
            color: var(--text-dark);
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 6px 25px rgba(0, 0, 0, 0.07);
            margin-bottom: 2rem;
            text-align: center;
            margin-top: 50px;
        }

        .header h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 700;
            letter-spacing: 0.5px;
            color: transparent;
            background: var(--classy-gradient);
            -webkit-background-clip: text;
            background-clip: text;
        }

        .header .welcome-subtext {
            font-size: 18px;
            font-weight: 400;
            opacity: 0.9;
            margin-top: 0.5rem;
        }

        .card-custom {
            background: linear-gradient(145deg, #ffffff, #f9f9ff);
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card-custom:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
        }

        .card-custom h5 {
            font-weight: 600;
            color: var(--text-dark);
        }

        .profile .img-fluid {
            width: 90px;
            height: 90px;
            margin-bottom: 12px;
            border: 3px solid var(--accent-color);
            padding: 4px;
        }

        .topbar-btn {
            position: fixed;
            top: 20px;
            background: #fff;
            border-radius: 50%;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            z-index: 1200;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: none;
            outline: none;
            transition: all 0.3s ease;
        }

        .topbar-btn:hover {
            transform: scale(1.1);
            background-color: #f1f3f5;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }

        .toggle-btn {
            left: 20px;
            color: var(--gradient-start);
        }

        .logout-btn {
            right: 20px;
            color: var(--gradient-end);
            font-size: 16px;
            text-decoration: none;
        }

        .logout-btn:hover {
            background: var(--gradient-end);
            color: #fff;
        }

        .btn-custom-primary {
            background: var(--classy-gradient);
            color: #fff;
            border-radius: 50px;
            padding: 12px 35px;
            font-weight: 600;
            border: none;
            font-size: 16px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .btn-custom-primary:hover {
            color: #fff;
            transform: translateY(-3px);
            box-shadow: 0 7px 20px rgba(142, 68, 173, 0.3);
        }

        .btn-outline-secondary {
            font-weight: 600;
            transition: all 0.3s ease;
            border-radius: 50px;
            padding: 12px 35px;
        }

        .btn-outline-secondary:hover {
            background-color: var(--accent-color);
            border-color: var(--accent-color);
            color: var(--text-dark);
        }

        @media (max-width: 991.98px) {
            .sidebar {
                left: -250px;
            }

            .sidebar.show {
                left: 0;
                box-shadow: 0 0 50px rgba(0, 0, 0, 0.3);
            }

            .main-content {
                margin-left: 0;
                padding: 1rem;
            }

            .main-content.expanded {
                 margin-left: 0;
            }

            .header {
                margin-top: 80px;
            }
        }

        @media (max-width: 575.98px) {
            .main-content {
                padding: 1rem 0.5rem;
            }

            .header {
                font-size: 20px;
                padding: 1.2rem;
            }
        }
    </style>
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="profile">
            <img src="https://placehold.co/90x90/ffffff/8e44ad?text=OEC" class="img-fluid rounded-circle" alt="Logo" onerror="this.onerror=null;this.src='https://placehold.co/90x90?text=Logo';">
            <h5><?php echo htmlspecialchars($student['Stud_name']); ?></h5>
        </div>
        <ul>
            <li>
                <a href="student_dash.php?page=dashboard" class="<?php echo (!isset($_GET['page']) || $_GET['page'] == 'dashboard') ? 'active' : ''; ?>">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="student_dash.php?page=profile" class="<?php echo (isset($_GET['page']) && $_GET['page'] == 'profile') ? 'active' : ''; ?>">
                    <i class="fas fa-id-card"></i> My Profile
                </a>
            </li>
            <li>
                <a href="student_dash.php?page=exams" class="<?php echo (isset($_GET['page']) && $_GET['page'] == 'exams') ? 'active' : ''; ?>">
                    <i class="fas fa-book"></i> Exams
                </a>
            </li>
            <li>
                <a href="student_dash.php?page=changepass" class="<?php echo (isset($_GET['page']) && $_GET['page'] == 'changepass') ? 'active' : ''; ?>">
                    <i class="fas fa-key"></i> Change Password
                </a>
            </li>
            <li>
                <a href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <button id="toggleSidebar" class="topbar-btn toggle-btn d-lg-none" aria-label="Open sidebar"><i
            class="fas fa-bars"></i></button>
    <a href="logout.php" class="topbar-btn logout-btn" aria-label="Logout" title="Logout"><i
            class="fas fa-sign-out-alt"></i></a>
    <div class="main-content" id="mainContent">

        <?php
        switch ($page) {
            case 'profile':
                include 'dash_myprofile.php';
                break;
            case 'exams':
                include 'dash_exam.php';
                break;
            case 'changepass':
                include 'changepassword.php';
                break;
            case 'dashboard':
            default:
                echo '<div class="header">
                        <h1>Olympiad Examination Council</h1>
                        <p class="welcome-subtext">Welcome, <strong>' . htmlspecialchars($student['Stud_name']) . '</strong>!</p>
                      </div>
                      <div class="card-custom">
                          <h5>Ready to take on the challenge?</h5>
                          <p class="text-muted">You are eligible to participate in the Olympiads for your grade.</p>
                          <a href="student_dash.php?page=exams" class="btn btn-custom-primary mt-3">Go to Exams</a>
                      </div>
                      <div class="card-custom">
                          <h5>Need to update your password?</h5>
                          <p class="text-muted">It\'s a good practice to keep your account secure.</p>
                          <a href="student_dash.php?page=changepass" class="btn btn-outline-secondary mt-3"><i class="fas fa-key"></i> Change Password</a>
                      </div>';
                break;
        }
        ?>
    </div>

    <script>
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.getElementById('mainContent');
    const toggleSidebar = document.getElementById('toggleSidebar');
    toggleSidebar.addEventListener('click', function() {
        sidebar.classList.toggle('show');
        // No need to toggle 'expanded' on main content for this mobile-first design
    });
    // Hide sidebar on click outside (mobile)
    document.addEventListener('click', function(e) {
        if (window.innerWidth < 992 && sidebar.classList.contains('show')) {
            if (!sidebar.contains(e.target) && !toggleSidebar.contains(e.target)) {
                sidebar.classList.remove('show');
            }
        }
    });


    // Disable Right-Click
    document.addEventListener("contextmenu", function(e) {
        e.preventDefault();
        alert(
            "⚠️🚫 Right-click is disabled!\n\n🔒 This is an official website of Olympiad Examination Council.\n🛑 Any malicious activity is strictly prohibited.\n👮‍♂️ Legal action will be taken against offenders.");
    });

    // Disable DevTools, View Source, etc.
    document.addEventListener("keydown", function(e) {
        if (
            e.keyCode === 123 || // F12
            (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I/J
            (e.ctrlKey && e.keyCode === 85) // Ctrl+U
        ) {
            e.preventDefault();
            alert(
                "🚫⚠️ This action is disabled for security reasons.\n\n🔐 Unauthorized inspection or tampering is forbidden.\n👮‍♂️ Violators may face strict legal consequences.");
        }
    });
    </script>

</body>

</html>
