<?php
$servername = "localhost";
$username = "olympiad_user_system";  // default XAMPP username
$password = "riteshweb";      // default XAMPP password is empty
$dbname = "olympiad_user_system"; // <-- CHANGE THIS

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>
