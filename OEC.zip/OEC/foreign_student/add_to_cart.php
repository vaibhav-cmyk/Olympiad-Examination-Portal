<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['exams'])) {
    $_SESSION['exam_cart'] = $_POST['exams'];

    // Calculate total amount
    // Fetch grade and branch
    $grade = isset($_SESSION['grade']) ? intval($_SESSION['grade']) : 0;
    if (isset($_SESSION['C_Branch'])) {
        $branch = $_SESSION['C_Branch'];
    } else {
        // Fetch from DB if not in session
        $regID = $_SESSION['RegID'];
        $branch = null;
        $conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");
        if (!$conn->connect_error) {
            $stmt = $conn->prepare("SELECT C_Branch FROM olympiad_registrations WHERE RegID = ?");
            $stmt->bind_param("i", $regID);
            $stmt->execute();
            $stmt->bind_result($branch);
            $stmt->fetch();
            $stmt->close();
            $conn->close();
            $_SESSION['C_Branch'] = $branch;
        }
    }
    $exam_config = [
        '1-4' => [
            'International Mathematics Olympiad' => 2,
            'International English Olympiad' => 2,
        ],
        '5-10' => [
            'International Mathematics Olympiad' => 2,
            'International English Olympiad' => 2,
            'International Science Olympiad' => 2,
            'International Space Olympiad' => 2,
        ]
        // 11-12 handled below
    ];
    function getExamFeesByGradeAndBranch($grade, $branch, $config) {
        if ($grade >= 1 && $grade <= 4) return $config['1-4'];
        if ($grade >= 5 && $grade <= 10) return $config['5-10'];
        if ($grade == 11 || $grade == 12) {
            $branch = strtolower(trim($branch));
            if ($branch === 'science') {
                return [
                    'International Physics Olympiad' => 2,
                    'International Chemistry Olympiad' => 2,
                    'International Mathematics Olympiad' => 2,
                    'International Biology Olympiad' => 2,
                ];
            } elseif ($branch === 'commerce') {
                return [
                    'International English Olympiad' => 2,
                    'International Commerce Olympiad' => 2,
                ];
            } elseif ($branch === 'arts') {
                return [
                    'International English Olympiad' => 2,
                    'International Geography Olympiad' => 2,
                    'International Economics Olympiad' => 2,
                ];
            } else {
                return [];
            }
        }
        return [];
    }
    $examFees = getExamFeesByGradeAndBranch($grade, $branch, $exam_config);
    $total = 0;
    foreach ($_POST['exams'] as $exam) {
        $total += $examFees[$exam] ?? 0;
    }
    $_SESSION['total_amount'] = $total;

    header("Location: payment_process.php");
    exit();
} else {
    // No exams selected
    header("Location: student_dash.php?page=exams");
    exit();
}
