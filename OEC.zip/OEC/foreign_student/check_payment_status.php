<?php
require_once 'config.php';
require_once 'db_connect.php';
require_once 'razorpay_api.php';

class PaymentStatusChecker {
    private $api;
    
    public function __construct() {
        $this->api = new RazorpayAPI(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET);
    }
    
    /**
     * Verify payment status using Razorpay API
     */
    public function verifyPaymentStatus($paymentId) {
        try {
            $url = 'https://api.razorpay.com/v1/payments/' . $paymentId;
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Basic ' . base64_encode(RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET)
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode === 200) {
                $paymentData = json_decode($response, true);
                return [
                    'status' => $paymentData['status'],
                    'amount' => $paymentData['amount'],
                    'currency' => $paymentData['currency'],
                    'order_id' => $paymentData['order_id'],
                    'method' => $paymentData['method'],
                    'captured' => $paymentData['captured'],
                    'description' => $paymentData['description'] ?? '',
                    'email' => $paymentData['email'] ?? '',
                    'contact' => $paymentData['contact'] ?? '',
                    'created_at' => $paymentData['created_at']
                ];
            } else {
                throw new Exception('Failed to fetch payment status: ' . $response);
            }
        } catch (Exception $e) {
            error_log("Payment status check failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Check if payment exists in database
     */
    public function checkPaymentInDatabase($paymentId) {
        try {
            global $pdo;
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM payment_transactions WHERE PaymentID = ? AND PaymentStatus = 'Success'");
            $stmt->execute([$paymentId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['count'] > 0;
        } catch (Exception $e) {
            error_log("Database check failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Comprehensive payment verification
     */
    public function verifyPayment($paymentId, $orderId, $signature) {
        // First verify signature
        $attributes = [
            'razorpay_order_id' => $orderId,
            'razorpay_payment_id' => $paymentId,
            'razorpay_signature' => $signature
        ];
        
        $signatureValid = $this->api->verifyPaymentSignature($attributes);
        
        if (!$signatureValid) {
            return ['valid' => false, 'reason' => 'Invalid signature'];
        }
        
        // Check payment status with Razorpay
        $paymentStatus = $this->verifyPaymentStatus($paymentId);
        
        if (!$paymentStatus) {
            return ['valid' => false, 'reason' => 'Unable to verify payment status'];
        }
        
        // Check if payment is captured and successful
        if ($paymentStatus['status'] !== 'captured' || !$paymentStatus['captured']) {
            return ['valid' => false, 'reason' => 'Payment not captured'];
        }
        
        // Check if payment already exists in database
        if ($this->checkPaymentInDatabase($paymentId)) {
            return ['valid' => false, 'reason' => 'Payment already processed'];
        }
        
        return [
            'valid' => true,
            'payment_data' => $paymentStatus
        ];
    }
}

// Usage example (can be called from other files)
if (isset($_GET['payment_id'])) {
    $checker = new PaymentStatusChecker();
    $paymentId = $_GET['payment_id'];
    $orderId = $_GET['order_id'] ?? '';
    $signature = $_GET['signature'] ?? '';
    
    if (!empty($orderId) && !empty($signature)) {
        $result = $checker->verifyPayment($paymentId, $orderId, $signature);
        header('Content-Type: application/json');
        echo json_encode($result);
    } else {
        $status = $checker->verifyPaymentStatus($paymentId);
        header('Content-Type: application/json');
        echo json_encode($status);
    }
}
?> 