<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include currency conversion functions
// require_once 'config.php'; // Assuming you have this file

// DEBUGGING — Optional (Remove after testing)
if (!isset($_SESSION['grade'])) {
    // Fallback for testing if session is not set
    $_SESSION['grade'] = 11;
    $_SESSION['C_Branch'] = 'Science';
    $_SESSION['RegID'] = 'TEST_STUDENT_123';
}

$grade = intval($_SESSION['grade'] ?? 0);

// Fetch branch from session or DB
if (isset($_SESSION['C_Branch'])) {
    $branch = $_SESSION['C_Branch'];
} else {
    // Fetch from DB if not in session
    $regID = $_SESSION['RegID'];
    $branch = null;
    // Database connection details should be in a secure config file
    $conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");
    if (!$conn->connect_error) {
        $stmt = $conn->prepare("SELECT C_Branch FROM olympiad_registration WHERE Student_ID = ?");
        $stmt->bind_param("s", $regID);
        $stmt->execute();
        $stmt->bind_result($branch);
        $stmt->fetch();
        $stmt->close();
        $conn->close();
        $_SESSION['C_Branch'] = $branch;
    }
}

// Fetch paid exams for this student
$regID = $_SESSION['RegID'];
$paidExams = [];
$conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");
if (!$conn->connect_error) {
    $stmt = $conn->prepare("SELECT Exam FROM foreign_payment_transactions WHERE Student_ID = ? AND PaymentStatus = 'Success' AND AccountStatus = 'Active'");
    $stmt->bind_param("s", $regID);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $paidExams[] = $row['Exam'];
    }
    $stmt->close();
    $conn->close();
}

$exam_config = [
    '1-4' => [
        ['name' => 'International Mathematics Olympiad', 'link' => 'quizimo_s.php', 'fee_usd' => 15],
        ['name' => 'International English Olympiad', 'link' => 'quiz-international-English-olympiad.php', 'fee_usd' => 15],
    ],
    '5-10' => [
        ['name' => 'International Mathematics Olympiad', 'link' => 'quizimo_s.php', 'fee_usd' => 15],
        ['name' => 'International English Olympiad', 'link' => 'quiz-international-English-olympiad.php', 'fee_usd' => 15],
        ['name' => 'International Science Olympiad', 'link' => 'quiziscio_s.php', 'fee_usd' => 15],
        ['name' => 'International Space Olympiad', 'link' => 'quiz-international-space-olympiad.php', 'fee_usd' => 15]
    ],
];

function getExamsByGradeAndBranch($grade, $branch, $config) {
    if ($grade >= 1 && $grade <= 4) return $config['1-4'];
    if ($grade >= 5 && $grade <= 10) return $config['5-10'];
    if ($grade == 11 || $grade == 12) {
        $branch = strtolower(trim($branch ?? ''));
        if ($branch === 'science') {
            return [
                ['name' => 'International Physics Olympiad', 'link' => 'quiz-international-physics-olympiad.php', 'fee_usd' => 15],
                ['name' => 'International Chemistry Olympiad', 'link' => 'quiz-international-chemistry-olympiad.php', 'fee_usd' => 15],
                ['name' => 'International Mathematics Olympiad', 'link' => 'quizimo_s.php', 'fee_usd' => 15],
                ['name' => 'International Biology Olympiad', 'link' => 'quiz-international-biology-olympiad.php', 'fee_usd' => 15],
            ];
        } elseif ($branch === 'commerce') {
            return [
                ['name' => 'International English Olympiad', 'link' => 'quiz-international-English-olympiad.php', 'fee_usd' => 15],
                ['name' => 'International Commerce Olympiad', 'link' => 'quiz-international-commerce-olympiad.php', 'fee_usd' => 15],
            ];
        } elseif ($branch === 'arts') {
            return [
                ['name' => 'International English Olympiad', 'link' => 'quiz-international-English-olympiad.php', 'fee_usd' => 15],
                ['name' => 'International Geography Olympiad', 'link' => 'quiz-international-geography-olympiad.php', 'fee_usd' => 15],
                ['name' => 'International Economics Olympiad', 'link' => 'quiz-international-Economics-olympiad.php', 'fee_usd' => 15],
            ];
        } else {
            return []; // No branch match
        }
    }
    return [];
}

$exams = getExamsByGradeAndBranch($grade, $branch, $exam_config);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>My Exams Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        :root {
            --gradient-start: #8e44ad;
            --gradient-end: #d81b60;
            --accent-color: #ffc107;
            --text-light: #ffffff;
            --text-dark: #333;
            --bg-light: #f4f7f6;
            --success-color: #2ecc71;
            --danger-color: #e74c3c;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        body {
            background-color: var(--bg-light);
            font-family: 'Poppins', sans-serif;
            color: var(--text-dark);
        }

        .main-title {
            animation: fadeIn 0.8s ease-out;
            font-weight: 700;
            color: transparent;
            background: linear-gradient(45deg, var(--gradient-start), var(--gradient-end));
            -webkit-background-clip: text;
            background-clip: text;
            letter-spacing: 1px;
        }

        .exam-container {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            margin-top: 30px;
            justify-content: center;
            max-height: 65vh;
            overflow-y: auto;
            padding: 20px;
        }

        .exam-container::-webkit-scrollbar {
            width: 8px;
        }

        .exam-container::-webkit-scrollbar-track {
            background: #e0e0e0;
            border-radius: 10px;
        }

        .exam-container::-webkit-scrollbar-thumb {
            background: linear-gradient(var(--gradient-start), var(--gradient-end));
            border-radius: 10px;
        }

        .exam-card {
            background: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
            color: var(--text-light);
            padding: 30px;
            border-radius: 15px;
            width: 300px;
            position: relative;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            min-height: 220px;
            animation: fadeIn 0.5s ease-out forwards;
            opacity: 0;
        }
        
        <?php foreach ($exams as $index => $exam): ?>
        .exam-card:nth-child(<?= $index + 1 ?>) {
            animation-delay: <?= $index * 0.1 ?>s;
        }
        <?php endforeach; ?>

        .exam-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 35px rgba(0, 0, 0, 0.2);
        }

        .fee-badge {
            position: absolute;
            top: -10px;
            right: -10px;
            background: var(--accent-color);
            color: var(--text-dark);
            padding: 5px 15px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 14px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .exam-title {
            font-size: 20px;
            font-weight: 600;
            line-height: 1.3;
            margin-bottom: 20px;
        }
        
        .exam-card .btn-group {
            margin-top: auto;
        }
        
        .exam-card .btn {
            border-radius: 50px;
            font-weight: 600;
            padding: 10px 20px;
            transition: all 0.3s ease;
            border: none;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 14px;
        }
        
        .exam-card .btn-light {
            background-color: rgba(255, 255, 255, 0.9);
            color: var(--gradient-start);
        }
        .exam-card .btn-light:hover {
             background-color: #fff;
             transform: scale(1.05);
        }
        .exam-card .btn-success {
            background-color: var(--success-color);
            color: #fff;
        }
        .exam-card .btn-success:hover{
            background-color: #27ae60;
            transform: scale(1.05);
        }
        .exam-card .btn-warning {
             background-color: rgba(255, 255, 255, 0.2);
             color: #fff;
             border: 2px solid #fff;
        }
        .exam-card .btn-warning:hover {
             background-color: rgba(255, 255, 255, 1);
             color: var(--gradient-start);
             transform: scale(1.05);
        }
        .exam-card .btn-danger {
            background-color: var(--danger-color);
            color: #fff;
        }
        .exam-card .btn-danger:hover {
            background-color: #c0392b;
            transform: scale(1.05);
        }


        .cart-box {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
        }

        .cart-fab {
            background: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
            color: var(--text-light);
            border-radius: 50px;
            padding: 15px 25px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 18px;
            transition: all 0.3s ease;
        }

        .cart-fab:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 25px rgba(0, 0, 0, 0.3);
        }

        .cart-details {
            display: none;
            position: absolute;
            bottom: 80px;
            right: 0;
            background-color: #fff;
            color: var(--text-dark);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.2);
            width: 320px;
            animation: fadeIn 0.3s ease;
        }

        .cart-items-list {
            list-style: none;
            padding: 0;
            margin: 0 0 15px 0;
            max-height: 150px;
            overflow-y: auto;
        }

        .cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }

        .remove-item {
            cursor: pointer;
            color: var(--danger-color);
            font-weight: bold;
            font-size: 20px;
            transition: color 0.2s ease;
        }
        .remove-item:hover {
            color: #c0392b;
        }

        .cart-total {
            font-weight: bold;
            font-size: 18px;
            text-align: right;
            margin-bottom: 15px;
        }
        
        .cart-details .btn-success {
            background: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
            border: none;
            border-radius: 50px;
            transition: all 0.3s ease;
        }
        .cart-details .btn-success:hover {
            transform: scale(1.02);
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }


        @media (max-width: 767.98px) {
            .exam-container {
                flex-direction: column;
                align-items: center;
                gap: 25px;
                max-height: calc(100vh - 200px);
                padding: 15px;
            }

            .exam-card {
                width: 95vw;
                min-height: auto;
            }
        }
    </style>
</head>

<body>

    <div class="container my-5">
        <h1 class="text-center main-title">Available Exams</h1>
        <div class="exam-container">
            <?php if (empty($exams)): ?>
                <div class="text-center p-5">
                    <h4>No exams available for your grade or branch at this time.</h4>
                    <p class="text-muted">Please check back later or contact support if you believe this is an error.</p>
                </div>
            <?php else: ?>
                <?php foreach ($exams as $exam): ?>
                <?php
                $isPaid = in_array($exam['name'], $paidExams);
                ?>
                <div class="exam-card">
                    <div class="fee-badge">$<?= htmlspecialchars($exam['fee_usd']) ?></div>
                    <div>
                        <div class="exam-title">
                            <?= htmlspecialchars($exam['name']) ?>
                        </div>
                    </div>
                    <div class="btn-group d-flex gap-2">
                         <button class="btn flex-grow-1 <?= $isPaid ? 'btn-success' : 'btn-light' ?> start-exam-btn"
                            data-link="<?= htmlspecialchars($exam['link']) ?>" data-paid="<?= $isPaid ? '1' : '0' ?>">
                            <?= $isPaid ? 'VIEW STATUS' : 'INFO' ?>
                        </button>
                        <?php if (!$isPaid): ?>
                        <button class="btn btn-warning flex-grow-1 select-exam" data-name="<?= htmlspecialchars($exam['name']) ?>"
                            data-fee="<?= htmlspecialchars($exam['fee_usd']) ?>">Select</button>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="cart-box" style="display: none;">
        <div class="cart-details" id="cartDetails">
            <h4>Your Cart</h4>
            <ul class="cart-items-list" id="cartItemsList"></ul>
            <div class="cart-total" id="cartTotal"></div>
            <form method="post" action="payment_process.php" id="paymentForm">
                <div id="selectedInputs"></div>
                <input type="hidden" name="total_amount" id="total_amount_hidden">
                <button type="submit" class="btn btn-success w-100 py-2">Proceed to Pay</button>
            </form>
        </div>
        <div class="cart-fab" id="cartFab">
            <span>🛒</span>
            <span id="cartItemCount" class="fw-bold">0</span>
            <span>|</span>
            <span id="cartTotalPrice" class="fw-bold">$0</span>
        </div>
    </div>

    <script>
    $(document).ready(function() {
        const selectedExams = new Map();

        function updateCartDisplay() {
            const cartItemsList = $('#cartItemsList');
            const selectedInputs = $('#selectedInputs');
            cartItemsList.empty();
            selectedInputs.empty();
            let total = 0;

            selectedExams.forEach((fee, name) => {
                cartItemsList.append(
                    `<li class="cart-item"><span>${name}</span><span class="remove-item" data-name="${name}">&times;</span></li>`
                );
                selectedInputs.append(`<input type="hidden" name="selected_exams[]" value="${name}">`);
                total += fee;
            });

            $('#cartItemCount').text(selectedExams.size);
            $('#cartTotalPrice').text(`$${total.toFixed(2)}`);
            $('#cartTotal').text(`Total: $${total.toFixed(2)}`);
            $('#total_amount_hidden').val(total.toFixed(2));

            if (selectedExams.size > 0) {
                $('.cart-box').fadeIn();
            } else {
                $('.cart-box').fadeOut();
                $('#cartDetails').fadeOut();
            }
        }

        $('#cartFab').on('click', function() {
            $('#cartDetails').fadeToggle();
        });

        $(document).on('click', '.select-exam', function() {
            const name = $(this).data('name');
            const fee = parseFloat($(this).data('fee'));
            if (!selectedExams.has(name)) {
                selectedExams.set(name, fee);
                $(this).text('Remove').removeClass('btn-warning').addClass('btn-danger');
            } else {
                selectedExams.delete(name);
                $(this).text('Select').removeClass('btn-danger').addClass('btn-warning');
            }
            updateCartDisplay();
        });

        $(document).on('click', '.remove-item', function() {
            const name = $(this).data('name');
            selectedExams.delete(name);
            // Use a more robust selector for names that might contain special characters
            $(".select-exam").filter(function() {
                return $(this).data("name") === name;
            }).text('Select').removeClass('btn-danger').addClass('btn-warning');
            updateCartDisplay();
        });

        $(document).on('click', '.start-exam-btn', function() {
            var paid = $(this).data('paid');
            var link = $(this).data('link');
            if (paid == '1') {
                // This is a much better user experience than a native alert
                showCustomAlert("🎉 Payment Successful!", "Exams will be held after a few days by the Olympiad Examination Council. Stay tuned!");
            } else {
                showCustomAlert("ℹ️ Information", "This exam has a fee. Please select it and proceed to payment to enroll.");
            }
        });

        // Disable security features via alert, as requested
        document.addEventListener("contextmenu", function(e) {
            e.preventDefault();
            alert("⚠️🚫 Right-click is disabled!\n\n🔒 This is an official website of Olympiad Examination Council.\n🛑 Any malicious activity is strictly prohibited.\n👮‍♂️ Legal action will be taken against offenders.");
        });

        document.addEventListener("keydown", function(e) {
            if (e.keyCode === 123 || (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || (e.ctrlKey && e.keyCode === 85)) {
                e.preventDefault();
                alert("🚫⚠️ This action is disabled for security reasons.\n\n🔐 Unauthorized inspection or tampering is forbidden.\n👮‍♂️ Violators may face strict legal consequences.");
            }
        });

        // A better, non-blocking alert function
        function showCustomAlert(title, message) {
            // Remove existing alert if any
            $('.custom-alert-backdrop').remove();
            
            // Create alert elements
            const backdrop = $('<div class="custom-alert-backdrop"></div>');
            const alertBox = $(`<div class="custom-alert-box">
                <h4>${title}</h4>
                <p>${message}</p>
                <button class="btn-ok">OK</button>
            </div>`);

            // Style them
            backdrop.css({
                position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
                backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 2000,
                display: 'flex', alignItems: 'center', justifyContent: 'center'
            });
            alertBox.css({
                background: '#fff', padding: '25px', borderRadius: '15px',
                textAlign: 'center', boxShadow: '0 5px 15px rgba(0,0,0,0.3)',
                maxWidth: '90%', width: '400px',
                animation: 'fadeIn 0.3s ease'
            });
            alertBox.find('h4').css({ marginTop: 0, fontWeight: 600 });
             alertBox.find('.btn-ok').css({
                background: 'linear-gradient(135deg, var(--gradient-start), var(--gradient-end))',
                color: '#fff', border: 'none', borderRadius: '50px',
                padding: '10px 30px', cursor: 'pointer', fontWeight: 600,
                marginTop: '15px'
            });

            // Append and show
            backdrop.append(alertBox).appendTo('body');
            
            // Handle close
            backdrop.on('click', function(e) {
                if (e.target === this || $(e.target).hasClass('btn-ok')) {
                    backdrop.fadeOut(300, function() { $(this).remove(); });
                }
            });
        }
    });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
