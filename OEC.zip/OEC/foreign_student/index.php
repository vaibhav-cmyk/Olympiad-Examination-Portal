<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
date_default_timezone_set("Asia/Kolkata");

// Redirect if already logged in
if (isset($_SESSION['IS_LOGIN'])) {
    header('Location: student_dash.php');
    exit();
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['int_email']);
    $password = trim($_POST['int_pass']);

    $conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("SELECT * FROM olympiad_registration WHERE Email_ID = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['S_Pass'])) {
            $_SESSION['IS_LOGIN'] = true;
            $_SESSION['student_name'] = $row['Stud_name'];
            $_SESSION['student_id'] = $row['Student_ID'];
            $_SESSION['RegID'] = $row['Student_ID']; 
            $_SESSION['email'] = $row['Email_ID'];
            $_SESSION['school_name'] = $row['S_Cname'];
            $_SESSION['country'] = $row['Country'];
            header('Location: student_dash.php');
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "Student not found.";
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>International Student Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- important for responsiveness -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(45deg, #7b2ff7, #f107a3);
            min-height: 100vh;
            margin: 0;
        }

        .demo-container {
            min-height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            margin-top: 80px;
        }

        .login-box {
            background: #fff;
            border-radius: 20px;
            padding: 80px 30px 30px;
            position: relative;
            box-shadow: 0px 6px 25px rgba(0, 0, 0, 0.15);
            max-width: 480px;
            width: 100%;
            margin: auto;
            text-align: center;
        }

        .brand_logo_container {
            position: absolute;
            top: -60px;
            left: 50%;
            transform: translateX(-50%);
            background: #400080;
            height: 110px;
            width: 110px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
        }

        .brand_logo {
            height: 95px;
            width: 95px;
            border-radius: 50%;
            border: 4px solid white;
        }

        h2 {
            font-size: 22px;
            font-weight: 600;
            margin-top: 10px;
        }

        .toggle-btn-group {
            display: inline-flex;
            border-radius: 25px;
            overflow: hidden;
        }

        .toggle-btn-group .btn {
            padding: 10px 25px;
            font-weight: bold;
            font-size: 15px;
            border-radius: 0;
        }

        .toggle-btn-group .btn:first-child {
            background: #ff1493;
            color: white;
        }

        .toggle-btn-group .btn:last-child {
            background: #ff8c00;
            color: white;
        }

        .form-control-lg {
            font-size: 15px;
            padding: 14px 18px;
            border-radius: 20px;
        }

        .input-group-text {
            border-radius: 20px 0 0 20px;
            background: #f8f9fa;
        }

        #forget a {
            font-size: 14px;
            color: #ff4d4d;
            font-weight: 500;
            text-decoration: none;
        }

        #forget a:hover {
            color: #28a745;
        }

        .btn-signin {
            background: #007bff;
            color: white;
            border-radius: 30px;
        padding: 12px 25px;
            font-weight: bold;
            font-size: 15px;
        }

        .btn-signin:hover {
            background: #0056b3;
        }

        .btn-home {
            background: #28a745;
            color: white;
            font-weight: bold;
            border-radius: 30px;
        }

        .btn-register {
            background: #ffc107;
            color: black;
            font-weight: bold;
            border-radius: 30px;
        }

        /* Responsive */
        @media (max-width: 575.98px) {
            .login-box {
                padding: 60px 20px 25px;
            }

            .brand_logo_container {
                height: 80px;
                width: 80px;
                top: -40px;
            }

            .brand_logo {
                height: 65px;
                width: 65px;
            }

            .btn-signin {
                width: 100%;
                
            }

            .btn-home,
            .btn-register {
                width: 100%;
                margin-bottom: 10px;
            }
        }
    </style>
</head>

<body>
    <div class="demo-container">
        <div class="login-box">
            <div class="brand_logo_container">
                <img src="img/oecfavicon.png" class="brand_logo" alt="Logo">
            </div>
            <h2>🌐 International Student Login</h2>
            <hr>

            <!-- Indian / International Toggle -->
            <div class="text-center mb-4">
                <div class="toggle-btn-group">
                    <button type="button" class="btn" onclick="window.location.href='../student/index.php'">
                        <i class="fas fa-flag"></i> Indian
                    </button>
                    <button type="button" class="btn" onclick="window.location.href='#'">
                        <i class="fas fa-globe"></i> International
                    </button>
                </div>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger text-center"><?php echo $error; ?></div>
            <?php endif; ?>

            <form method="post" id="loginForm">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                    </div>
                    <input type="email" name="int_email" class="form-control form-control-lg"
                        placeholder="Enter Email" autocomplete="username" required>
                </div>

                <div class="input-group mb-2">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    </div>
                    <input type="password" name="int_pass" class="form-control form-control-lg"
                        placeholder="Enter Password" autocomplete="current-password" required>
                </div>

                <p id="forget"><a href="#"><i class="fas fa-key"></i> Forgot password?</a></p>

                <div class="text-center mb-3">
                    <button type="submit" class="btn btn-signin shadow">
                        <i class="fas fa-sign-in-alt"></i> SIGN IN
                    </button>
                </div>
            </form>

            <div class="text-center d-flex justify-content-around flex-wrap">
                <button onclick="window.location.href='../../index.html'" class="btn btn-home mb-2">
                    <i class="fas fa-home"></i> HOME
                </button>
                <button onclick="window.location.href='../foreign_student_registration/email_verification/'"
                    class="btn btn-register mb-2">
                    <i class="fas fa-user-plus"></i> Registration
                </button>
            </div>
        </div>
    </div>
</body>

</html>
