<?php
session_start();

echo "<h2>Session Debug Information</h2>";
echo "<div style='background: #f0f0f0; padding: 15px; border: 1px solid #ccc; margin: 10px;'>";

echo "<h3>Current Session Data:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo "<h3>Session Status:</h3>";
echo "<ul>";
echo "<li>Session ID: " . session_id() . "</li>";
echo "<li>Session Name: " . session_name() . "</li>";
echo "<li>Session Status: " . (session_status() == PHP_SESSION_ACTIVE ? 'Active' : 'Active') . "</li>";
echo "</ul>";

echo "<h3>Required Session Variables Check:</h3>";
$required_vars = ['IS_LOGIN', 'RegID', 'username', 'userid', 'country', 'grade'];
$missing_vars = [];

foreach ($required_vars as $var) {
    if (isset($_SESSION[$var])) {
        echo "<p style='color: green;'>✓ {$var}: " . htmlspecialchars($_SESSION[$var]) . "</p>";
    } else {
        echo "<p style='color: red;'>✗ {$var}: NOT SET</p>";
        $missing_vars[] = $var;
    }
}

if (empty($missing_vars)) {
    echo "<p style='color: green; font-weight: bold;'>✓ All required session variables are set!</p>";
} else {
    echo "<p style='color: red; font-weight: bold;'>✗ Missing session variables: " . implode(', ', $missing_vars) . "</p>";
}

echo "<h3>Payment Session Variables (set during payment):</h3>";
$payment_vars = ['selected_exams', 'total_amount', 'payment_amount', 'razorpay_order_id'];
$payment_missing = [];

foreach ($payment_vars as $var) {
    if (isset($_SESSION[$var])) {
        echo "<p style='color: green;'>✓ {$var}: " . htmlspecialchars(print_r($_SESSION[$var], true)) . "</p>";
    } else {
        echo "<p style='color: orange;'>⚠ {$var}: NOT SET (this is normal if not in payment flow)</p>";
        $payment_missing[] = $var;
    }
}

echo "</div>";

echo "<h3>Actions:</h3>";
echo "<ul>";
echo "<li><a href='index.php'>Go to Login</a></li>";
echo "<li><a href='student_dash.php'>Go to Dashboard</a></li>";
echo "<li><a href='logout.php'>Logout</a></li>";
echo "</ul>";

echo "<h3>Session Configuration:</h3>";
echo "<ul>";
echo "<li>Session Save Path: " . session_save_path() . "</li>";
echo "<li>Session Cookie Params: ";
print_r(session_get_cookie_params());
echo "</li>";
echo "</ul>";
?> 