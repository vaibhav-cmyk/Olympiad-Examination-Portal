<?php
// Currency configuration
define('INR_TO_USD_RATE', 0.012); // 1 INR = 0.012 USD (approximate rate)
define('DEFAULT_CURRENCY', 'USD');

function convertInrToUsd($amountInInr) {
    return round($amountInInr * INR_TO_USD_RATE, 2);
}

function formatCurrency($amount, $currency = DEFAULT_CURRENCY) {
    switch ($currency) {
        case 'USD':
            return '$' . number_format($amount, 2);
        case 'INR':
            return '₹' . number_format($amount, 2);
        default:
            return number_format($amount, 2);
    }
}
define('RAZORPAY_KEY_ID', 'rzp_test_Qy1Rq1U9esFBge');
define('RAZORPAY_KEY_SECRET', 'glCPl6uUbKP8w1uacd3h0N2I');
?>
