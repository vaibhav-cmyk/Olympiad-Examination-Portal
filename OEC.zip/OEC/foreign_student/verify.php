<?php
session_start();
require('config.php');
require('razorpay/Razorpay.php');

use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$api = new Api($razorpay_config['api_key'], $razorpay_config['api_secret']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $razorpay_payment_id = $_POST['razorpay_payment_id'] ?? '';
    $razorpay_order_id = $_POST['razorpay_order_id'] ?? '';
    $razorpay_signature = $_POST['razorpay_signature'] ?? '';

    $regID = $_SESSION['RegID'] ?? null;
    $selectedExams = $_SESSION['selected_exams'] ?? [];
    $totalAmount = $_SESSION['total_amount'] ?? 0;

    if (!$razorpay_payment_id || !$razorpay_order_id || !$razorpay_signature || !$regID || empty($selectedExams)) {
        die("Invalid payment data.");
    }

    $attributes = [
        'razorpay_order_id' => $razorpay_order_id,
        'razorpay_payment_id' => $razorpay_payment_id,
        'razorpay_signature' => $razorpay_signature
    ];

    try {
        $api->utility->verifyPaymentSignature($attributes);

        // DB connection
        $conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");
        // $conn = new mysqli("localhost", "root", "", "test2");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        echo "<h2 style='color: green; text-align:center;'>Payment Successful!</h2>";
        echo "<p style='text-align:center;'>Payment ID: <strong>$razorpay_payment_id</strong></p>";
        echo "<h4 style='text-align:center;'>You have successfully paid for the following exams:</h4>";

        echo "<div style='max-width: 600px; margin: auto;'>";
        echo "<table border='1' cellspacing='0' cellpadding='10' style='width:100%; text-align:center; border-collapse:collapse;'>";
        echo "<tr style='background:#f0f0f0;'><th>Exam Name</th><th>Amount (₹)</th></tr>";

        foreach ($selectedExams as $exam) {
            // Update DB
            $stmt = $conn->prepare("UPDATE payment_transactions SET PaymentID = ?, PaymentStatus = 'Success', PaymentDate = NOW() WHERE RegID = ? AND Exam = ? AND PaymentStatus = 'Pending'");
            $stmt->bind_param("sis", $razorpay_payment_id, $regID, $exam);
            $stmt->execute();
            $stmt->close();

            // Fetch amount for the display
            $stmt2 = $conn->prepare("SELECT Amount FROM payment_transactions WHERE RegID = ? AND Exam = ?");
            $stmt2->bind_param("is", $regID, $exam);
            $stmt2->execute();
            $stmt2->bind_result($amount);
            $stmt2->fetch();
            $stmt2->close();

            echo "<tr><td>$exam</td><td>₹" . number_format($amount, 2) . "</td></tr>";
        }

        echo "<tr style='font-weight:bold;'><td>Total</td><td>₹" . number_format($totalAmount, 2) . "</td></tr>";
        echo "</table></div>";

        // Clear session data
        unset($_SESSION['selected_exams'], $_SESSION['total_amount'], $_SESSION['razorpay_order_id']);

    } catch (SignatureVerificationError $e) {
        echo "<h2 style='color: red; text-align:center;'>Payment Verification Failed</h2>";
        echo "<p style='text-align:center;'>Reason: " . $e->getMessage() . "</p>";

        $conn = new mysqli("localhost", "olympiad_user_system", "riteshweb", "olympiad_user_system");
        // $conn = new mysqli("localhost", "root", "", "test2");
        foreach ($selectedExams as $exam) {
            $stmt = $conn->prepare("UPDATE payment_transactions SET PaymentStatus = 'Failed', PaymentDate = NOW() WHERE RegID = ? AND Exam = ? AND PaymentStatus = 'Pending'");
            $stmt->bind_param("is", $regID, $exam);
            $stmt->execute();
            $stmt->close();
        }
    }
} else {
    echo "<h3 style='color:red;text-align:center;'>Invalid Access</h3>";
}
?>
