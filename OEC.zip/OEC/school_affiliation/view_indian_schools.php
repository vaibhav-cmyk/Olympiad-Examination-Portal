<?php
// Include the database connection file.
include '../../db.php';

// Check for connection errors.
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// ----------------------------------------------------------------------------------
// Pagination Logic
// ----------------------------------------------------------------------------------

// Number of records to display per page.
// The default is now 10, but the options start from 2, 4, etc.
$records_per_page = isset($_GET['per_page']) ? intval($_GET['per_page']) : 10;
// Validate the input to be one of the specified options.
$allowed_per_page = [2, 4, 10, 25, 50, 100];
if (!in_array($records_per_page, $allowed_per_page)) {
    $records_per_page = 10; // Default to 10 if an invalid value is provided.
}

// Get the current page number from the URL, or default to 1.
$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
if ($current_page <= 0) {
    $current_page = 1;
}

// Calculate the offset for the SQL query.
$offset = ($current_page - 1) * $records_per_page;

// Count the total number of records.
$total_records_query = "SELECT COUNT(*) AS total FROM indian_schools";
$total_records_result = $conn->query($total_records_query);
$total_records = $total_records_result->fetch_assoc()['total'];

// Calculate the total number of pages.
$total_pages = ceil($total_records / $records_per_page);

// Select records for the current page.
$sql = "SELECT * FROM indian_schools ORDER BY id ASC LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $records_per_page, $offset);
$stmt->execute();
$result = $stmt->get_result();

// Check if the query itself failed.
if (!$result) {
    die("Query failed: " . $conn->error);
}

// A safe function to display HTML and handle null/empty values.
function safe($val) {
    return htmlspecialchars($val ?? 'N/A');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Indian Schools</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #dbe9f4, #f0f4f8);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}
.navbar {
    background: linear-gradient(90deg, #004080, #0073e6);
}
.navbar-brand {
    font-weight: 600;
    font-size: 1.5rem;
    color: #fff !important;
}
.logo {
    height: 40px;
    margin-right: 10px;
}
.container {
    flex: 1;
}
h2 {
    color: #004080;
    font-weight: 600;
}
.table-responsive {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-radius: 12px;
    overflow: auto;
}
.table th {
    background: linear-gradient(90deg, #004080, #0073e6);
    color: #fff;
    white-space: nowrap;
}
.table td, .table th {
    vertical-align: middle;
    font-size: 0.85rem;
}
footer {
    background: linear-gradient(90deg, #004080, #0073e6);
    color: #fff;
    text-align: center;
    padding: 1rem 0;
    margin-top: auto;
    font-size: 0.95rem;
    position: relative;
    overflow: hidden;
}
footer::after {
    content: "";
    position: absolute;
    top: 0;
    left: -150%;
    height: 100%;
    width: 50%;
    background: linear-gradient(120deg, transparent, rgba(255,255,255,0.4), transparent);
    animation: shine 3s infinite;
}
@keyframes shine {
    0% { left: -150%; }
    50% { left: 150%; }
    100% { left: 150%; }
}
.back-btn {
    background: #fff;
    color: #004080;
    font-weight: 500;
    border-radius: 20px;
    padding: 0.3rem 1rem;
    transition: all 0.3s ease;
    font-size: 0.9rem;
}
.back-btn:hover {
    background: #e6f0ff;
    color: #00264d;
    transform: scale(1.05);
}
.pagination-controls {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 1rem;
}
@media (max-width: 576px) {
    .navbar-brand {
        font-size: 1.2rem;
    }
    .back-btn {
        font-size: 0.8rem;
        padding: 0.2rem 0.7rem;
    }
    footer {
        font-size: 0.8rem;
    }
    .pagination-controls {
        flex-direction: column;
        align-items: flex-start;
    }
}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="#">
            <img src="../../images/logo.png" alt="Logo" class="logo">
            <span>OEC</span>
        </a>
        <div class="ms-auto me-2">
            <a href="view_school_registration.php" class="back-btn text-decoration-none">
                <i class="bi bi-arrow-left-circle"></i> Back
            </a>
        </div>
    </div>
</nav>

<div class="container my-4">
    <h2 class="mb-4 text-center">All Indian School Records</h2>
    
    <div class="pagination-controls">
        <form method="get" class="d-flex align-items-center">
            <label for="per_page" class="form-label me-2 mb-0">Records per page:</label>
            <select name="per_page" id="per_page" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="2" <?= $records_per_page == 2 ? 'selected' : '' ?>>2</option>
                <option value="4" <?= $records_per_page == 4 ? 'selected' : '' ?>>4</option>
                <option value="10" <?= $records_per_page == 10 ? 'selected' : '' ?>>10</option>
                <option value="25" <?= $records_per_page == 25 ? 'selected' : '' ?>>25</option>
                <option value="50" <?= $records_per_page == 50 ? 'selected' : '' ?>>50</option>
                <option value="100" <?= $records_per_page == 100 ? 'selected' : '' ?>>100</option>
            </select>
            <input type="hidden" name="page" value="<?= $current_page ?>">
        </form>
        <nav aria-label="Page navigation">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= $current_page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page - 1 ?>&per_page=<?= $records_per_page ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= $i == $current_page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&per_page=<?= $records_per_page ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $current_page >= $total_pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page + 1 ?>&per_page=<?= $records_per_page ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>

    <div class="table-responsive mt-3">
        <table class="table table-bordered table-striped align-middle text-center mb-0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>School ID</th>
                    <th>UDISE Code</th>
                    <th>School Name</th>
                    <th>Address</th>
                    <th>State</th>
                    <th>District</th>
                    <th>Taluka</th>
                    <th>City</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Website</th>
                    <th>School Type</th>
                    <th>School Level</th>
                    <th>Affiliation</th>
                    <th>Area</th>
                    <th>Grade/Class From</th>
                    <th>Grade/Class To</th>
                    <th>Total Students</th>
                    <th>Total Teachers</th>
                    <th>Principal</th>
                    <th>Teacher In-Charge</th>
                    <th>Registered At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= safe($row['id']) ?></td>
                            <td><?= safe($row['school_id']) ?></td>
                            <td><?= safe($row['udise_code']) ?></td>
                            <td><?= safe($row['school_name']) ?></td>
                            <td><?= safe($row['address']) ?></td>
                            <td><?= safe($row['state']) ?></td>
                            <td><?= safe($row['district']) ?></td>
                            <td><?= safe($row['taluka']) ?></td>
                            <td><?= safe($row['city']) ?></td>
                            <td><?= safe($row['contact_number']) ?></td>
                            <td><?= safe($row['email']) ?></td>
                            <td><?= safe($row['website']) ?></td>
                            <td><?= safe($row['school_type']) ?></td>
                            <td><?= safe($row['school_level']) ?></td>
                            <td><?= safe($row['affiliation']) ?></td>
                            <td><?= safe($row['area']) ?></td>
                            <td><?= safe($row['grade_from']) ?></td>
                            <td><?= safe($row['grade_to']) ?></td>
                            <td><?= safe($row['total_students']) ?></td>
                            <td><?= safe($row['total_teachers']) ?></td>
                            <td><?= safe($row['principal_name']) ?><br><?= safe($row['principal_mobile']) ?></td>
                            <td><?= safe($row['teacher_incharge_name']) ?><br><?= safe($row['teacher_incharge_mobile']) ?></td>
                            <td><?= safe($row['created_at']) ?></td>
                            <td class="text-nowrap">
                                <a href="edit_indian_school.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning" aria-label="Edit">
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <a href="delete_indian_school.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" aria-label="Delete" onclick="return confirm('Are you sure you want to delete this record?')">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="24">No records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="pagination-controls mt-3">
        <div>Showing <?= $offset + 1 ?> to <?= min($offset + $records_per_page, $total_records) ?> of <?= $total_records ?> entries</div>
        <nav aria-label="Page navigation">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= $current_page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page - 1 ?>&per_page=<?= $records_per_page ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= $i == $current_page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&per_page=<?= $records_per_page ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $current_page >= $total_pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page + 1 ?>&per_page=<?= $records_per_page ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>

<footer class="footer">
    &copy; 2024 Olympiad Examination Council. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php 
// Close the database connection
$stmt->close();
$conn->close();
?>