-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 21, 2025 at 05:56 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oec_school`
--

-- --------------------------------------------------------

--
-- Table structure for table `international_schools`
--

CREATE TABLE `international_schools` (
  `id` int(11) NOT NULL,
  `school_id` varchar(20) NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `country` varchar(100) NOT NULL,
  `address` text DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `school_type` varchar(50) DEFAULT NULL,
  `school_level` varchar(50) DEFAULT NULL,
  `accreditation` varchar(100) DEFAULT NULL,
  `timezone` varchar(50) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `grade` varchar(50) DEFAULT NULL,
  `total_students` int(11) DEFAULT NULL,
  `total_teachers` int(11) DEFAULT NULL,
  `principal_name` varchar(100) DEFAULT NULL,
  `principal_mobile` varchar(20) DEFAULT NULL,
  `principal_email` varchar(100) DEFAULT NULL,
  `teacher_name` varchar(100) DEFAULT NULL,
  `teacher_mobile` varchar(20) DEFAULT NULL,
  `teacher_email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `registered_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `international_schools`
--

INSERT INTO `international_schools` (`id`, `school_id`, `school_name`, `country`, `address`, `state`, `city`, `zip`, `contact_number`, `email`, `website`, `school_type`, `school_level`, `accreditation`, `timezone`, `currency`, `grade`, `total_students`, `total_teachers`, `principal_name`, `principal_mobile`, `principal_email`, `teacher_name`, `teacher_mobile`, `teacher_email`, `password`, `registered_at`) VALUES
(1, 'OECIN250001', 'kle tech', 'India', 'Belgaum\r\nBelgaum', 'Karnataka', 'belgaum', '590001', '07338538070', 'info@gvischool.edu', 'file:///C:/Users/imirf/Downloads/school%20registration.html', 'Private', 'Secondary', 'fdvb', '12', 'inr', '12', 11, 1, 'vvvvv', '07338538070', 'info@gvischool.edu', 'Vaibhav M Atiwadkar', '07338538070', 'info@gvischool.edu', '$2y$10$KZyaWGPJ4S7T.DX6vQ5uWOlZBUzo0vmH6/lY0AibThYMMB0CspN/6', '2025-07-21 14:33:32'),
(3, 'OECIN250002', 'kle tech', 'India', 'Belgaum\r\nBelgaum', 'Maharashtra', '', '590001', '1111111111', 'info@gvischool.edu', 'file:///C:/Users/imirf/Downloads/school%20registration.html', 'Private', 'Primary', 'fdvb', 'UTC+00:00 (London)', 'USD', '2', 11, 11, 'vvvvv', '1111111111', 'info@gvischool.edu', 'wawaaw', '1111111111', 'info@gvischool.edu', '$2y$10$O1FHk.VvCjyL/4oZ8Zm0Au00ddrcNnTVyVNHcfhHtrxACaz1UhmeW', '2025-07-21 15:55:05'),
(4, 'OECIN250003', 'kle tech', 'India', 'Belgaum\r\nBelgaum', 'Maharashtra', 'Mumbai', '590001', '1111111111', 'info@gvischool.edu', 'file:///C:/Users/imirf/Downloads/school%20registration.html', 'Private', 'Primary', 'fdvb', 'UTC+00:00 (London)', 'USD', '2', 11, 11, 'vvvvv', '1111111111', 'info@gvischool.edu', 'wawaaw', '1111111111', 'info@gvischool.edu', '$2y$10$eIMVIuwJ3Mcgq09k4puld.W.Crx71gQ7.gnSsC2IK7IsnTTbhhyxO', '2025-07-21 15:55:19');

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `indian_schools` (
  `id` int(11) NOT NULL,
  `school_id` varchar(20) NOT NULL,
  `udise_code` varchar(50) DEFAULT NULL,
  `school_name` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `taluka` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `school_type` varchar(50) DEFAULT NULL,
  `school_level` varchar(50) DEFAULT NULL,
  `affiliation` varchar(100) DEFAULT NULL,
  `area` varchar(100) DEFAULT NULL,
  `grade` varchar(20) DEFAULT NULL,
  `total_students` int(11) DEFAULT NULL,
  `total_teachers` int(11) DEFAULT NULL,
  `principal_name` varchar(100) DEFAULT NULL,
  `principal_mobile` varchar(20) DEFAULT NULL,
  `teacher_incharge_name` varchar(100) DEFAULT NULL,
  `teacher_incharge_mobile` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `registered_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`id`, `school_id`, `udise_code`, `school_name`, `address`, `state`, `district`, `taluka`, `city`, `contact_number`, `email`, `website`, `school_type`, `school_level`, `affiliation`, `area`, `grade`, `total_students`, `total_teachers`, `principal_name`, `principal_mobile`, `teacher_incharge_name`, `teacher_incharge_mobile`, `password`, `registered_at`) VALUES
(2, 'OEC20250001', '58293416724', 'kle tech', 'Belgaum\r\nBelgaum', 'Karnataka', 'Bangalore Rural', 'belgaum', 'belgaum', '7338538070', 'info@gvischool.edu', 'file:///C:/Users/imirf/Downloads/school%20registration.html', 'Aided', 'Primary', 'aa', 'ss', '10', 11, 32, '0', '7338538070', 'shbubham', '7338538070', '$2y$10$BfMHsiEWrJ9pb2erK47Ha.XlO82DzN2CB5z1x2gij23Z0U5rj33w2', '2025-07-21 14:10:24'),
(3, 'OEC20250002', '58293416724', 'kle tech', 'Belgaum\r\nBelgaum', 'Karnataka', 'Bangalore Rural', 'belgaum', 'belgaum', '7338538070', 'info@gvischool.edu', 'file:///C:/Users/imirf/Downloads/school%20registration.html', 'Aided', 'Primary', 'aa', 'ss', '10', 11, 32, 'vvvvv', '7338538070', 'shbubham', '7338538070', '$2y$10$gry9BFP6KePOwdVkycoyN.h8ON9JfdtRDCIz1LwsIW8x9kMZsQJSO', '2025-07-21 14:13:04'),
(4, 'OEC20250003', '58293416724', 'kle tech', 'Belgaum\r\nBelgaum', 'Karnataka', 'Bangalore Rural', 'belgaum', 'belgaum', '7338538070', 'info@gvischool.edu', 'file:///C:/Users/imirf/Downloads/school%20registration.html', 'Aided', 'Primary', 'aa', 'ss', '10', 11, 32, 'vvvvv', '7338538070', 'shbubham', '7338538070', '$2y$10$63yYBflpDozCtxCfrb8yoOua0vQ8gvjIzx6BDa85EVfFC/OIz/96q', '2025-07-21 14:13:21'),
(5, 'OEC20250004', '58293416722', 'bvb', 'Belgaum\r\nBelgaum', 'Kerala', 'Thiruvananthapuram', 'belgaum', 'belgaum', '7894561230', 'info@gvischool.edu', 'file:///C:/Users/imirf/Downloads/school%20registration.html', 'Private', 'Primary', 'aa', 'ss', '3', 11, 32, 'vvvvv', '7894561230', 'shbubham', '7894561230', '$2y$10$iWKSj0D3Qvs0Ak65wFz2nuBcWAoLIqX291VQtN2H4arWIwabe/CWy', '2025-07-21 14:14:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `international_schools`
--
ALTER TABLE `international_schools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `school_id` (`school_id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `school_id` (`school_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `international_schools`
--
ALTER TABLE `international_schools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
