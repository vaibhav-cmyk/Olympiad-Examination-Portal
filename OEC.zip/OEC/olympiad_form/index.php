<?php
session_start();

// Initialize error messages
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['country_name'] = $_POST['country_name'] ?? '';
    $_SESSION['country_code'] = $_POST['country_code'] ?? '';

    $host = "localhost";
    $db = "olympiad_user_system";
    $user = "olympiad_user_system";
    $pass = "riteshweb";
    $conn = new mysqli($host, $user, $pass, $db);
    if ($conn->connect_error) {
        die("Critical Error: Could not connect to the registration database.");
    }

    if (isset($_POST['country_code']) && $_POST['country_code'] === '+91') {
        $mobile = $_POST['mobile'] ?? '';
        // Check for duplicate mobile
        $stmt = $conn->prepare("SELECT RegID FROM olympiad_registrations WHERE MobileNo = ?");
        $stmt->bind_param("s", $mobile);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $error_message = 'This mobile number is already registered.';
        } else {
            $_SESSION['mobile'] = $mobile;
            $stmt->close();
            $conn->close();
            header("Location: register.php");
            exit;
        }
        $stmt->close();
    } else {
        $email = $_POST['email'] ?? '';
        // Check for duplicate email
        $stmt = $conn->prepare("SELECT Student_ID FROM olympiad_registration WHERE Email_ID = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $error_message = 'This email address is already registered.';
        } else {
            $_SESSION['email'] = $email;
            $stmt->close();
            $conn->close();
            header("Location: ../../foreign_student_registration/email_verification/send_otp.php");
            exit;
        }
        $stmt->close();
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Olympiad Examination Council - Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .form-container { background:rgb(230, 232, 255); padding: 2.5rem; border-radius: 1rem; box-shadow: 0 0.5rem 1.5rem rgba(0, 0, 0, 0.1); }
        .error-message { color: #dc3545; font-size: 0.95em; margin-bottom: 1rem; text-align: center; font-weight: bold;}
    </style>
</head>
<body>
    <div class="container">
        <div class="row min-vh-100 justify-content-center align-items-center">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <div class="text-center mb-5">
                    <img src="../images/logo.png" alt="OEC Logo" style="width: 64px; height: 64px;" class="mx-auto mb-4">
                    <h1 class="h3 fw-bold">Olympiad Examination Council</h1>
                    <p class="text-muted">Recognized by Government of India</p>
                </div>
                <div class="form-container">
                    <div class="text-center mb-4">
                        <h2 class="h4 fw-semibold">Create Your Account</h2>
                        <p class="text-muted small">Enter your details to get started.</p>
                    </div>
                    <?php if (!empty($error_message)): ?>
                        <div class="error-message"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    <form id="verificationForm" method="post" action="">
                        <input type="hidden" id="country_name" name="country_name" value="<?php echo htmlspecialchars($_POST['country_name'] ?? ''); ?>">
                        <div class="mb-3">
                            <label for="country_code" class="form-label">Country</label>
                            <input type="text" id="countrySearch" placeholder="Search for a country..." class="form-control mb-2">
                            <select name="country_code" id="country_code" required class="form-select" onchange="updateFormForCountry()">
                                
                                <option value="+91" <?php if (($_POST['country_code'] ?? '') === '+91') echo 'selected'; ?>>+91 (India)</option>
                                
                            </select>
                        </div>
                        <div class="mb-3" id="mobile_div" style="display: none;">
                            <label for="mobile" class="form-label">Mobile Number</label>
                            <input type="tel" name="mobile" id="mobile" placeholder="Enter 10-digit number" class="form-control" pattern="[0-9]{10}" title="Please enter a valid 10-digit mobile number." value="<?php echo htmlspecialchars($_POST['mobile'] ?? ''); ?>">
                        </div>
                        <div class="mb-3" id="email_div">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" name="email" id="email" required placeholder="you@example.com" class="form-control" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                        </div>
                        <div class="d-grid">
                            <button type="submit" id="submit_button" class="btn btn-primary btn-lg">
                                Proceed to Verification
                            </button>
                        </div>
                    </form>
                    <div class="text-center mt-4">
                        <p class="text-muted small">
                            Already have an account?
                            <a href="/student/">Login</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function updateFormForCountry() {
            var countrySelect = document.getElementById('country_code');
            var mobileDiv = document.getElementById('mobile_div');
            var emailDiv = document.getElementById('email_div');
            var mobileInput = document.getElementById('mobile');
            var emailInput = document.getElementById('email');
            
            // Set the hidden country_name input field
            var selectedOption = countrySelect.options[countrySelect.selectedIndex];
            if (selectedOption) {
                // Extract country name from text like "+91 (India)"
                var countryName = selectedOption.text.split('(')[1];
                if(countryName) {
                    document.getElementById('country_name').value = countryName.replace(')', '').trim();
                } else {
                     document.getElementById('country_name').value = selectedOption.text.trim();
                }
            }

            if (countrySelect.value === '+91') {
                mobileDiv.style.display = 'block';
                emailDiv.style.display = 'none';
                mobileInput.required = true;
                emailInput.required = false;
            } else {
                mobileDiv.style.display = 'none';
                emailDiv.style.display = 'block';
                mobileInput.required = false;
                emailInput.required = true;
            }
        }
        document.addEventListener('DOMContentLoaded', function() {
            updateFormForCountry();

            // --- JavaScript for country search ---
            const countrySearchInput = document.getElementById('countrySearch');
            const countrySelect = document.getElementById('country_code');
            const options = countrySelect.getElementsByTagName('option');

            countrySearchInput.addEventListener('keyup', function() {
                const filter = this.value.toLowerCase();
                
                for (let i = 0; i < options.length; i++) {
                    const option = options[i];
                    const text = option.textContent || option.innerText;
                    
                    // Always show the "-- Select Your Country --" option
                    if (option.value === "" || text.toLowerCase().indexOf(filter) > -1) {
                        option.style.display = "";
                    } else {
                        option.style.display = "none";
                    }
                }
            });
        });
    </script>
</body>
</html>