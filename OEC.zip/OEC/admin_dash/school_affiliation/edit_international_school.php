<?php
// Include the database connection file
// Make sure `db.php` contains your database connection logic ($conn)
include '../../db.php';

// Check if an 'id' parameter is set in the URL and is a valid number.
// If not, redirect the user back to the list page.
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: view_international_schools.php");
    exit;
}

$id = intval($_GET['id']);

// Prepare a SQL statement to fetch all school data for the given ID.
// This query retrieves all necessary columns from the `international_schools` table.
$stmt = $conn->prepare("SELECT id, school_id, school_name, country, address, state, city, zip, contact_number, email, website, school_type, school_level, accreditation, grade_from, grade_to, total_students, total_teachers, principal_name, principal_mobile, principal_email, teacher_name, teacher_mobile, teacher_email, reg_date FROM international_schools WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();
$stmt->close();

// If no data is found for the given ID, display an error message and exit.
if (!$data) {
    $conn->close();
    die("School not found.");
}

// Check if the form has been submitted via POST request.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and collect data from the form.
    $school_name = trim($_POST['school_name'] ?? '');
    
    // Handle 'Other' option for Country.
    $country = trim($_POST['country'] ?? '');
    if ($country === 'Other' && !empty($_POST['country_other'])) {
        $country = trim($_POST['country_other']);
    }

    $address = trim($_POST['address'] ?? '');
    
    // State and City are now simple text inputs.
    $state = trim($_POST['state'] ?? '');
    $city = trim($_POST['city'] ?? '');
    

    $zip = trim($_POST['zip'] ?? '');
    $contact_number = trim($_POST['contact_number'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $website = trim($_POST['website'] ?? '');
    $school_type = trim($_POST['school_type'] ?? '');
    $school_level = trim($_POST['school_level'] ?? '');
    $accreditation = trim($_POST['accreditation'] ?? '');
    
    // Grades: Directly use the separate 'grade_from' and 'grade_to' fields.
    $grade_from = intval($_POST['grade_from'] ?? 0);
    $grade_to = intval($_POST['grade_to'] ?? 0);

    $total_students = intval($_POST['total_students'] ?? 0);
    $total_teachers = intval($_POST['total_teachers'] ?? 0);
    $principal_name = trim($_POST['principal_name'] ?? '');
    $principal_mobile = trim($_POST['principal_mobile'] ?? '');
    $principal_email = trim($_POST['principal_email'] ?? '');
    $teacher_name = trim($_POST['teacher_name'] ?? '');
    $teacher_mobile = trim($_POST['teacher_mobile'] ?? '');
    $teacher_email = trim($_POST['teacher_email'] ?? '');

    // Start building the SQL UPDATE query and parameters.
    $sql = "UPDATE international_schools SET 
        school_name=?, country=?, address=?, state=?, city=?, zip=?, 
        contact_number=?, email=?, website=?, school_type=?, school_level=?, 
        accreditation=?, grade_from=?, grade_to=?, 
        total_students=?, total_teachers=?, principal_name=?, principal_mobile=?, 
        principal_email=?, teacher_name=?, teacher_mobile=?, teacher_email=? WHERE id=?";
    
    // Define the data types for binding parameters.
    $param_types = "ssssssssssssiiiissssssi";
    $stmt = $conn->prepare($sql);
    
    // The previous code caused a warning because bind_param needs arguments
    // passed by reference. This revised code passes each variable directly,
    // which is the most reliable way to prevent that error.
    $stmt->bind_param(
        $param_types,
        $school_name,
        $country,
        $address,
        $state,
        $city,
        $zip,
        $contact_number,
        $email,
        $website,
        $school_type,
        $school_level,
        $accreditation,
        $grade_from,
        $grade_to,
        $total_students,
        $total_teachers,
        $principal_name,
        $principal_mobile,
        $principal_email,
        $teacher_name,
        $teacher_mobile,
        $teacher_email,
        $id
    );

    if ($stmt->execute()) {
        // If the update is successful, redirect to the list page.
        header("Location: view_international_schools.php?status=success_edit");
        exit;
    } else {
        // If an error occurs, print it for debugging.
        echo "Error updating record: " . $stmt->error;
    }
    
    $stmt->close();
    $conn->close();
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit International School</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<style>
/* Reusing styles from the registration form for a consistent look */
body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #dbe9f4, #f0f4f8);
    min-height: 100vh;
    margin: 0;
    overflow-x: hidden;
}

.navbar {
    background: linear-gradient(90deg, #004080, #0073e6);
}

.navbar-brand {
    font-weight: 600;
    color: #fff !important;
}

.footer {
    background: linear-gradient(90deg, #004080, #0073e6);
    color: #fff;
    text-align: center;
    padding: 1rem 0;
    margin-top: auto;
    font-size: 0.95rem;
}

.footer::after {
    content: "";
    position: absolute;
    top: 0;
    left: -150%;
    height: 100%;
    width: 50%;
    background: linear-gradient(120deg, transparent, rgba(255,255,255,0.4), transparent);
    animation: shine 3s infinite;
}

@keyframes shine {
    0% { left: -150%; }
    50% { left: 150%; }
    100% { left: 150%; }
}

.card {
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
}

.hidden-input {
    display: none;
    margin-top: 5px;
}

@media (max-width: 576px) {
    .navbar-brand span {
        font-size: 1.1rem;
    }
}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand d-flex align-items-center gap-2" href="#">
            <img src="../../images/logo.png" alt="Logo" style="height: 30px; width: auto;">
            <span>OEC School Registration Edit</span>
        </a>
        <button
            class="btn register-btn btn-sm ms-auto"
            onclick="window.location.href='view_international_schools.php'"
            style="font-size: 0.9rem;">
            ← Back to List
        </button>
    </div>
</nav>

<div class="container px-2 px-md-5">
    <div class="card">
        <h4 class="text-center mb-4">Edit International School: <?= htmlspecialchars($data['school_name']) ?> (ID: <?= htmlspecialchars($data['school_id']) ?>)</h4>
        <form method="POST" onsubmit="return validateForm()">
            <div class="row g-3">
                
                <div class="col-md-6">
                    <label class="form-label">School Name</label>
                    <input type="text" class="form-control" name="school_name" value="<?= htmlspecialchars($data['school_name']) ?>" required>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Country</label>
                    <select class="form-select" name="country" id="country" onchange="showOtherInput('country')" required>
                        <option selected disabled value="">Select Country</option>
                        <?php
                        // List of countries to populate the dropdown.
                        $allCountries = [
                            "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia", "Australia", "Austria",
                            "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bhutan", "Bolivia",
                            "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cabo Verde", "Cambodia",
                            "Cameroon", "Canada", "Central African Republic", "Chad", "Chile", "China", "Colombia", "Comoros", "Congo (Brazzaville)",
                            "Congo (Kinshasa)", "Costa Rica", "Côte d'Ivoire", "Croatia", "Cuba", "Cyprus", "Czechia", "Denmark", "Djibouti", "Dominica",
                            "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Eswatini", "Ethiopia", "Fiji",
                            "Finland", "France", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece", "Grenada", "Guatemala", "Guinea", "Guinea-Bissau",
                            "Guyana", "Haiti", "Honduras", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica",
                            "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia",
                            "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta",
                            "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia (Federated States of)", "Moldova", "Monaco", "Mongolia",
                            "Montenegro", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "New Zealand", "Nicaragua", "Niger",
                            "Nigeria", "North Korea", "North Macedonia", "Norway", "Oman", "Pakistan", "Palau", "Palestine, State of", "Panama",
                            "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", "Romania", "Russian Federation", "Rwanda",
                            "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe",
                            "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands",
                            "Somalia", "South Africa", "South Korea", "South Sudan", "Spain", "Sri Lanka", "Sudan", "Suriname", "Sweden", "Switzerland",
                            "Syrian Arab Republic", "Taiwan", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Timor-Leste", "Togo", "Tonga",
                            "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates",
                            "United Kingdom", "United States", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Viet Nam", "Yemen", "Zambia", "Zimbabwe"
                        ];
                        sort($allCountries);
                        $country_found = false;
                        foreach ($allCountries as $opt) {
                            $selected = ($opt == $data['country']) ? 'selected' : '';
                            if ($selected) $country_found = true;
                            echo "<option value=\"".htmlspecialchars($opt)."\" {$selected}>".htmlspecialchars($opt)."</option>";
                        }
                        $other_selected = (!$country_found && !empty($data['country'])) ? 'selected' : '';
                        echo "<option value=\"Other\" {$other_selected}>Other</option>";
                        ?>
                    </select>
                    <input type="text" id="country_other" name="country_other" class="form-control hidden-input" placeholder="Enter country" 
                            value="<?= (!$country_found && !empty($data['country'])) ? htmlspecialchars($data['country']) : '' ?>">
                </div>

                <div class="col-12">
                    <label class="form-label">Address</label>
                    <textarea class="form-control" name="address" rows="2" placeholder="Enter full address" required><?= htmlspecialchars($data['address']) ?></textarea>
                </div>

                <div class="col-md-6">
                    <label class="form-label">State</label>
                    <input type="text" class="form-control" name="state" value="<?= htmlspecialchars($data['state']) ?>" placeholder="Enter state" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">City</label>
                    <input type="text" class="form-control" name="city" value="<?= htmlspecialchars($data['city']) ?>" placeholder="Enter city" required>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Zip</label>
                    <input type="text" class="form-control" name="zip" value="<?= htmlspecialchars($data['zip']) ?>" placeholder="Enter zip code" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Contact Number</label>
                    <input type="text" class="form-control" name="contact_number" value="<?= htmlspecialchars($data['contact_number']) ?>" placeholder="e.g., 9876543210" required readonly>
                </div>
               <div class="col-md-6">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($data['email']) ?>" placeholder="e.g., school@example.com" required readonly>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Website</label>
                    <input type="text" class="form-control" name="website" value="<?= htmlspecialchars($data['website']) ?>" placeholder="e.g., www.schoolwebsite.com">
                </div>

                <div class="col-md-6">
                    <label class="form-label">School Type</label>
                    <select class="form-select" name="school_type" required>
                        <option disabled value="">Select Type</option>
                        <?php
                        $school_types = ["Government", "Semi-Government", "Private"];
                        foreach ($school_types as $type) {
                            $selected = ($type == $data['school_type']) ? 'selected' : '';
                            echo "<option value=\"".htmlspecialchars($type)."\" {$selected}>".htmlspecialchars($type)."</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">School Level</label>
                    <select class="form-select" name="school_level" required>
                        <option disabled value="">Select Level</option>
                        <?php
                        $school_levels = ["Primary School", "Elementary School", "Middle School", "Junior High School", "Secondary School", "Senior Secondary School", "High School"];
                        foreach ($school_levels as $level) {
                            $selected = ($level == $data['school_level']) ? 'selected' : '';
                            echo "<option value=\"".htmlspecialchars($level)."\" {$selected}>".htmlspecialchars($level)."</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Accreditation</label>
                    <input type="text" class="form-control" name="accreditation" value="<?= htmlspecialchars($data['accreditation']) ?>" placeholder="e.g., CBSE, IGCSE">
                </div>

                <div class="col-md-4">
                    <label class="form-label">Grades From</label>
                    <input type="number" class="form-control" id="grade_from" name="grade_from" min="1" max="12" value="<?= htmlspecialchars($data['grade_from']) ?>" placeholder="e.g., 1" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Grades To</label>
                    <input type="number" class="form-control" id="grade_to" name="grade_to" min="1" max="12" value="<?= htmlspecialchars($data['grade_to']) ?>" placeholder="e.g., 12" required>
                </div>
                <div class="col-md-4">
                    <small id="gradeError" class="text-danger d-none">❌ Invalid range! "To" must be ≥ "From".</small>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Total Students</label>
                    <input type="number" class="form-control" name="total_students" value="<?= htmlspecialchars($data['total_students']) ?>" placeholder="e.g., 1500" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Total Teachers</label>
                    <input type="number" class="form-control" name="total_teachers" value="<?= htmlspecialchars($data['total_teachers']) ?>" placeholder="e.g., 150" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Principal Name</label>
                    <input type="text" class="form-control" name="principal_name" value="<?= htmlspecialchars($data['principal_name']) ?>" placeholder="e.g., John Doe" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Principal Mobile</label>
                    <input type="text" class="form-control" name="principal_mobile" value="<?= htmlspecialchars($data['principal_mobile']) ?>" placeholder="e.g., 9876543210" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Principal Email</label>
                    <input type="email" class="form-control" name="principal_email" value="<?= htmlspecialchars($data['principal_email']) ?>" placeholder="e.g., principal@example.com" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Teacher Name</label>
                    <input type="text" class="form-control" name="teacher_name" value="<?= htmlspecialchars($data['teacher_name']) ?>" placeholder="e.g., Jane Smith" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Teacher Mobile</label>
                    <input type="text" class="form-control" name="teacher_mobile" value="<?= htmlspecialchars($data['teacher_mobile']) ?>" placeholder="e.g., 9876543210" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Teacher Email</label>
                    <input type="email" class="form-control" name="teacher_email" value="<?= htmlspecialchars($data['teacher_email']) ?>" placeholder="e.g., teacher@example.com" required>
                </div>
            </div>
            <div class="text-center mt-4">
                <button type="submit" class="btn btn-success px-4">Save Changes</button>
                <a href="view_international_schools.php" class="btn btn-secondary px-4">Cancel</a>
            </div>
        </form>
    </div>
</div>
<footer class="footer">
    &copy; <?= date('Y') ?> Olympiad Examination Council. All rights reserved.
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    window.onload = () => {
        // Initialize the 'Other' input visibility for country based on current data.
        showOtherInput('country');
        
        // Add event listener for the 'Other' input field.
        document.getElementById("country").addEventListener('change', () => {
            showOtherInput('country');
        });
        
        // Add event listeners for real-time grade range validation.
        document.getElementById('grade_from').addEventListener('input', validateGradeRange);
        document.getElementById('grade_to').addEventListener('input', validateGradeRange);
        validateGradeRange(); // Validate on load as well.
    };
    
    // Show text field if "Other" is selected in a dropdown.
    function showOtherInput(type) {
        const dropdown = document.getElementById(type);
        const inputBox = document.getElementById(type + "_other");
        if (dropdown.value === "Other") {
            inputBox.style.display = "block";
            inputBox.required = true;
        } else {
            inputBox.style.display = "none";
            inputBox.required = false;
        }
    }
    
    // Validate all form fields before submission.
    function validateForm() {
        if (!validateMobile()) {
            return false;
        }
        if (!validateGradeRange()) {
            return false;
        }
        return true;
    }
    
    // Validate Mobile Numbers (must be 10 digits).
    function validateMobile() {
        const ids = ["contact_number", "principal_mobile", "teacher_mobile"];
        for (const id of ids) {
            const val = document.querySelector(`[name="${id}"]`)?.value.trim() || "";
            if (!/^\d{10}$/.test(val)) {
                alert(`${id.replace('_', ' ')} must be exactly 10 digits.`);
                return false;
            }
        }
        return true;
    }
    
    // Validate Grades From and To (From grade must be less than or equal to To grade).
    function validateGradeRange() {
        const from = parseInt(document.getElementById('grade_from').value) || 0;
        const to = parseInt(document.getElementById('grade_to').value) || 0;
        const errorMsg = document.getElementById('gradeError');

        if (from > to) {
            errorMsg.classList.remove('d-none');
            return false;
        } else {
            errorMsg.classList.add('d-none');
            return true;
        }
    }
</script>
