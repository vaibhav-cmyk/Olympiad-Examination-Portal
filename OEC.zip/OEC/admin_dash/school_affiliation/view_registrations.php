<?php
include '../../db.php';

// ✅ Handle Delete Request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']); // prevent SQL injection

    $delete_sql = "DELETE FROM olympiad_registrations WHERE RegID = $delete_id";
    if (mysqli_query($conn, $delete_sql)) {
        // redirect back with success message
        header("Location: view_registrations.php?msg=deleted");
        exit();
    } else {
        echo "<script>alert('❌ Error deleting record.');</script>";
    }
}

// ✅ Fetch All Students
$sql = "SELECT * FROM olympiad_registrations ORDER BY RegID ASC";
$result = mysqli_query($conn, $sql);
$count = 1;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Registered Students</title>

<!-- Bootstrap & Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
body {
    background-color: #f2f5f8;
    font-family: 'Poppins', sans-serif;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}

main {
    flex: 1;
}

.navbar-brand {
    font-weight: 600;
    font-size: 1.4rem;
    letter-spacing: .5px;
}

footer {
    background-color: #004080;
    color: #ccc;
    text-align: center;
    padding: 1rem 0;
    font-size: 0.85rem;
    margin-top: auto;
}

footer a {
    color: #ccc;
    text-decoration: none;
}

footer a:hover {
    text-decoration: underline;
    color: #fff;
}

.table-container {
    background: white;
    padding: 20px;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    animation: fadeIn 0.8s ease;
}

.table th {
    background-color: #003366;
    color: white;
    font-size: 13px;
    font-weight: 500;
}

.table td {
    font-size: 13px;
    vertical-align: middle;
}

.table tbody tr {
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.table tbody tr:hover {
    background-color: #f1f5fb;
    transform: scale(1.01);
}

.action-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    font-size: 0.9rem;
    padding: 0;
    margin-right: 6px;
    border-radius: 4px;
    transition: all 0.2s ease-in-out;
}

.action-btn:last-child {
    margin-right: 0;
}

.action-btn:hover {
    transform: translateY(-2px) scale(1.1);
}

.action-icon {
    pointer-events: none;
}

@keyframes fadeIn {
  from {opacity: 0; transform: translateY(20px);}
  to {opacity: 1; transform: translateY(0);}
}
</style>
</head>
<body>

<!-- Header/Navbar -->
<nav class="navbar navbar-expand-lg" style="background-color: #004080;">
<div class="container-fluid px-4 d-flex justify-content-between align-items-center">
  <a class="navbar-brand d-flex align-items-center gap-2 text-white" href="#">
    <img src="../../images/logo.png" alt="Logo" style="height: 40px; width: auto;">
    <span>OEC Portal</span>
  </a>
  <a href="masterdashboard.php" class="btn btn-light btn-sm">
    <i class="bi bi-arrow-left-circle me-1"></i> Back to Dashboard
  </a>
</div>
</nav>

<main>
<div class="container py-4">

<!-- Alert Messages -->
<?php if (isset($_GET['msg'])): ?>
<div class="alert alert-success alert-dismissible fade show animate__animated animate__fadeInDown" role="alert" id="statusAlert">
<?php
if ($_GET['msg'] === 'updated') {
    echo "✅ Student record updated successfully.";
} elseif ($_GET['msg'] === 'deleted') {
    echo "🗑️ Student record deleted successfully.";
}
?>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<h2 class="text-center mb-4 fw-bold text-primary">Registered Students</h2>

<div class="table-container table-responsive">
<table class="table table-bordered table-striped table-hover align-middle">
<thead class="text-center">
<tr>
<th>#</th>
<th>Reg No</th>
<th>Student Name</th>
<th>Parent Name</th>
<th>DOB</th>
<th>Gender</th>
<th>Mobile</th>
<th>WhatsApp</th>
<th>Email</th>
<th>Home Address</th>
<th>Country</th>
<th>State</th>
<th>District</th>
<th>School Name</th>
<th>School Address</th>
<th>School Category</th>
<th>Grade</th>
<th>Branch Code</th>
<th>Exam Language</th>
<th style="width: 110px;">Actions</th>
</tr>
</thead>
<tbody>
<?php
include '../db.php';
$sql = "SELECT * FROM olympiad_registrations ORDER BY RegID ASC";
$result = mysqli_query($conn, $sql);
$count = 1;

while ($row = mysqli_fetch_assoc($result)) {
echo "<tr class='text-center'>";
echo "<td>" . $count++ . "</td>";
echo "<td>" . htmlspecialchars($row['RegNo']) . "</td>";
echo "<td>" . htmlspecialchars($row['Stud_name']) . "</td>";
echo "<td>" . htmlspecialchars($row['Parent_name']) . "</td>";
echo "<td>" . htmlspecialchars($row['Stud_dob']) . "</td>";
echo "<td>" . ($row['Gender'] == '1' ? 'Male' : ($row['Gender'] == '2' ? 'Female' : 'Other')) . "</td>";
echo "<td>" . htmlspecialchars($row['MobileNo']) . "</td>";
echo "<td>" . htmlspecialchars($row['WhatsAppNo']) . "</td>";
echo "<td>" . htmlspecialchars($row['Email_ID']) . "</td>";
echo "<td>" . nl2br(htmlspecialchars($row['Home_addr'])) . "</td>";
echo "<td>" . htmlspecialchars($row['Country']) . "</td>";
echo "<td>" . htmlspecialchars($row['S_State']) . "</td>";
echo "<td>" . htmlspecialchars($row['District']) . "</td>";
echo "<td>" . htmlspecialchars($row['S_Cname']) . "</td>";
echo "<td>" . nl2br(htmlspecialchars($row['S_Caddr'])) . "</td>";
echo "<td>" . htmlspecialchars($row['S_Cat']) . "</td>";
echo "<td>" . htmlspecialchars($row['Grade']) . "</td>";
echo "<td>" . htmlspecialchars($row['C_Branch']) . "</td>";
echo "<td>" . htmlspecialchars($row['Exam_Lg']) . "</td>";
echo "<td>
<div class='d-flex justify-content-center gap-2'>
<a href='edit_student.php?id=" . $row['RegID'] . "' class='btn btn-outline-primary btn-sm action-btn' title='Edit'>
<i class='bi bi-pencil-square action-icon'></i>
</a>
<a href='view_registrations.php?delete_id=" . $row['RegID'] . "' class='btn btn-outline-danger btn-sm action-btn' title='Delete' onclick=\"return confirm('Are you sure you want to delete this student?');\">
<i class='bi bi-trash-fill action-icon'></i>
</a>
</div>
</td>";
}

mysqli_close($conn);
?>
</tbody>
</table>
</div>
</div>
</main>

<!-- Footer -->
<footer>
<div class="container">
<p class="mb-0">&copy; <?= date('Y') ?> Olympiad System | All rights reserved.</p>
<p class="small">✨ Designed with ❤️ using <a href="https://getbootstrap.com/" target="_blank">Bootstrap</a></p>
</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Auto-hide Alert -->
<script>
setTimeout(function () {
const alertBox = document.getElementById("statusAlert");
if (alertBox) {
const bsAlert = bootstrap.Alert.getOrCreateInstance(alertBox);
bsAlert.close();
}
}, 3000);
</script>
</body>
</html>
