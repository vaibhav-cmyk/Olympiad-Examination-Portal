<?php
// Include the database connection file
include '../../db.php';

// Check if the connection was successful
if (!isset($conn) || $conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Redirect if no ID is provided or if it's not numeric
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: view_indian_schools.php");
    exit;
}

$id = intval($_GET['id']); // Sanitize ID to integer

// Handle form submission for updating data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Define expected fields from the form
    $fields = [
        'school_name', 'udise_code', 'address', 'state', 'district', 'taluka', 'city',
        'contact_number', 'email', 'website', 'school_type', 'school_level', 'affiliation',
        'area', 'total_students', 'total_teachers', 'principal_name',
        'principal_mobile', 'teacher_incharge_name', 'teacher_incharge_mobile'
    ];

    $params = [];
    foreach ($fields as $field) {
        // Collect and trim input, defaulting to empty string if not set
        $params[$field] = trim($_POST[$field] ?? '');
    }

    // Handle the new grade fields separately
    $grade_from_val = trim($_POST['grade_from'] ?? '');
    $grade_to_val = trim($_POST['grade_to'] ?? '');

    // Prepare the SQL UPDATE statement
    $sql = "UPDATE indian_schools SET
        school_name=?, udise_code=?, address=?, state=?, district=?, taluka=?, city=?,
        contact_number=?, email=?, website=?, school_type=?, school_level=?, affiliation=?,
        area=?, grade_from=?, grade_to=?, total_students=?, total_teachers=?, principal_name=?,
        principal_mobile=?, teacher_incharge_name=?, teacher_incharge_mobile=?
        WHERE id=?";

    $stmt = $conn->prepare($sql);

    // Check if statement preparation was successful
    if (!$stmt) {
        error_log("Failed to prepare update statement: " . $conn->error);
        header("Location: view_indian_schools.php?error=stmt_prepare");
        exit;
    }

    // Bind parameters to the prepared statement
    $stmt->bind_param(
        "sssssssssssssiississssi",
        $params['school_name'], $params['udise_code'], $params['address'], $params['state'], $params['district'],
        $params['taluka'], $params['city'], $params['contact_number'], $params['email'], $params['website'],
        $params['school_type'], $params['school_level'], $params['affiliation'], $params['area'],
        $grade_from_val, $grade_to_val, $params['total_students'], $params['total_teachers'], $params['principal_name'],
        $params['principal_mobile'], $params['teacher_incharge_name'], $params['teacher_incharge_mobile'], $id
    );

    // Execute the statement
    if ($stmt->execute()) {
        header("Location: view_indian_schools.php?status=success");
        exit;
    } else {
        error_log("Error executing update statement: " . $stmt->error);
        header("Location: view_indian_schools.php?error=update_failed");
        exit;
    }
    
    $stmt->close();
}

// --- Fetch data for the form (GET request) ---
$stmt = $conn->prepare("SELECT * FROM indian_schools WHERE id=?");
if (!$stmt) {
    error_log("Failed to prepare select statement: " . $conn->error);
    die("Error fetching data.");
}
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();
$stmt->close();

// If no data found for the given ID, redirect
if (!$data) {
    header("Location: view_indian_schools.php");
    exit;
}

// Helper function to set 'selected' attribute for dropdowns
function selected($val, $option) {
    return ($val === $option) ? 'selected' : '';
}

// Close connection after all operations are done
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Indian School</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #dbe9f4, #f0f4f8);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}
.container {
    flex: 1;
    padding: 20px;
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    margin-top: 20px;
    margin-bottom: 20px;
}
h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #004080;
    font-weight: 600;
}
.btn-success {
    background: linear-gradient(90deg, #0073e6, #004080);
    border: none;
    font-weight: 500;
    transition: all 0.3s ease;
}
.btn-success:hover {
    background: linear-gradient(90deg, #005bb5, #003060);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}
.btn-secondary {
    background: #6c757d;
    border: none;
    font-weight: 500;
    transition: all 0.3s ease;
}
.btn-secondary:hover {
    background: #5a6268;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}
input.form-control,
textarea.form-control,
select.form-select {
    transition: all 0.3s ease;
    border-radius: 8px;
}
input.form-control:focus,
textarea.form-control:focus,
select.form-select:focus {
    border-color: #0073e6;
    box-shadow: 0 0 0 3px rgba(0,115,230,0.1);
}
.form-label {
    font-weight: 600;
    color: #333;
}
.text-danger {
    font-size: 0.85rem;
}
</style>
</head>
<body>

<div class="container my-5">
    <h2>Edit Indian School: <?= htmlspecialchars($data['school_id']) ?></h2>
    <form method="post" class="row g-3">
        <?php
        // The array now also defines if the field is readonly
        $fields = [
            ['School Name', 'school_name', 'text', true, false],
            ['UDISE Code', 'udise_code', 'text', true, false],
            ['Address', 'address', 'textarea', true, false],
            ['State', 'state', 'text', true, false],
            ['District', 'district', 'text', true, false],
            ['Taluka', 'taluka', 'text', true, false],
            ['City', 'city', 'text', true, false],
            ['Contact Number', 'contact_number', 'tel', true, true],
            ['Email', 'email', 'email', true, true],
            ['Website', 'website', 'url', false, false]
        ];

        foreach ($fields as [$label, $name, $type, $required, $readonly]) {
            echo '<div class="col-md-6">';
            echo "<label class=\"form-label\">$label</label>";
            $required_attr = $required ? 'required' : '';
            $readonly_attr = $readonly ? 'readonly' : '';
            if ($type === 'textarea') {
                echo "<textarea name=\"$name\" class=\"form-control\" rows=\"2\" $required_attr $readonly_attr>".htmlspecialchars($data[$name] ?? '')."</textarea>";
            } else {
                echo "<input type=\"$type\" name=\"$name\" class=\"form-control\" value=\"".htmlspecialchars($data[$name] ?? '')."\" $required_attr $readonly_attr>";
            }
            echo '</div>';
        }
        ?>

        <div class="col-md-6">
            <label class="form-label">School Type</label>
            <select name="school_type" class="form-select" required>
                <option value="">Select School Type</option>
                <option value="Government" <?= selected($data['school_type'], 'Government') ?>>Government</option>
                <option value="Semi Government" <?= selected($data['school_type'], 'Semi Government') ?>>Semi-Government</option>
                <option value="Private" <?= selected($data['school_type'], 'Private') ?>>Private</option>
            </select>
        </div>

        <div class="col-md-6">
            <label class="form-label">School Level</label>
            <select name="school_level" class="form-select" required>
                <option value="">Select School Level</option>
                <option value="Primary" <?= selected($data['school_level'], 'Primary') ?>>Primary</option>
                <option value="Secondary" <?= selected($data['school_level'], 'Secondary') ?>>Secondary</option>
                <option value="Higher Secondary" <?= selected($data['school_level'], 'Higher Secondary') ?>>Higher Secondary</option>
            </select>
        </div>

        <div class="col-md-6">
            <label class="form-label">Affiliation</label>
            <input type="text" name="affiliation" class="form-control" value="<?= htmlspecialchars($data['affiliation'] ?? '') ?>" readonly>
        </div>

        <div class="col-md-6">
            <label class="form-label">Area</label>
            <select name="area" class="form-select" required>
                <option value="">Select Area</option>
                <option value="Urban" <?= selected($data['area'], 'Urban') ?>>Urban</option>
                <option value="Rural" <?= selected($data['area'], 'Rural') ?>>Rural</option>
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label">Grade/Class</label>
            <div class="d-flex gap-2">
                <input type="number" class="form-control" id="grade_from" name="grade_from" min="0" max="12" placeholder="From" value="<?= htmlspecialchars($data['grade_from'] ?? '') ?>" required>
                <input type="number" class="form-control" id="grade_to" name="grade_to" min="0" max="12" placeholder="To" value="<?= htmlspecialchars($data['grade_to'] ?? '') ?>" required>
            </div>
            <small id="gradeError" class="text-danger d-none">❌ Invalid range! "To" must be ≥ "From".</small>
        </div>

        <div class="col-md-4">
            <label class="form-label">Total Students</label>
            <input type="number" name="total_students" class="form-control" value="<?= htmlspecialchars($data['total_students'] ?? '') ?>" required>
        </div>

        <div class="col-md-4">
            <label class="form-label">Total Teachers</label>
            <input type="number" name="total_teachers" class="form-control" value="<?= htmlspecialchars($data['total_teachers'] ?? '') ?>" required>
        </div>

        <div class="col-md-6">
            <label class="form-label">Principal Name</label>
            <input type="text" name="principal_name" class="form-control" value="<?= htmlspecialchars($data['principal_name'] ?? '') ?>" required>
        </div>

        <div class="col-md-6">
            <label class="form-label">Principal Mobile</label>
            <input type="tel" name="principal_mobile" class="form-control" value="<?= htmlspecialchars($data['principal_mobile'] ?? '') ?>" required pattern="[0-9]{10}" title="Enter a 10-digit phone number">
        </div>

        <div class="col-md-6">
            <label class="form-label">Teacher In-Charge Name</label>
            <input type="text" name="teacher_incharge_name" class="form-control" value="<?= htmlspecialchars($data['teacher_incharge_name'] ?? '') ?>">
        </div>

        <div class="col-md-6">
            <label class="form-label">Teacher In-Charge Mobile</label>
            <input type="tel" name="teacher_incharge_mobile" class="form-control" value="<?= htmlspecialchars($data['teacher_incharge_mobile'] ?? '') ?>" pattern="[0-9]{10}" title="Enter a 10-digit phone number">
        </div>

        <div class="col-12 text-center mt-4">
            <button type="submit" class="btn btn-success me-2">Save</button>
            <a href="view_indian_schools.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<script>
    // JavaScript for Grade Range validation
    const gradeFromInput = document.getElementById('grade_from');
    const gradeToInput = document.getElementById('grade_to');
    const gradeErrorMsg = document.getElementById('gradeError');
    const form = document.querySelector('form');

    function validateGradeRange() {
        const from = parseInt(gradeFromInput.value) || 0;
        const to = parseInt(gradeToInput.value) || 0;

        if (from > to && to !== 0) {
            gradeErrorMsg.classList.remove('d-none');
            return false;
        } else {
            gradeErrorMsg.classList.add('d-none');
            return true;
        }
    }

    // Add real-time validation listeners
    gradeFromInput.addEventListener('input', validateGradeRange);
    gradeToInput.addEventListener('input', validateGradeRange);

    // Prevent form submission if invalid range
    form.addEventListener('submit', function(event) {
        if (!validateGradeRange()) {
            event.preventDefault(); // Stop form submission if validation fails
        }
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>