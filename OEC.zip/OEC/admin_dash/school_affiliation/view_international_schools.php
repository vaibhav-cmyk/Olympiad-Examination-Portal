<?php
session_start();
// Include the database connection file.
include '../../db.php';

// Check for connection errors.
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// ----------------------------------------------------------------------------------
// Download Logic (POST requests only)
// ----------------------------------------------------------------------------------

// Download all records
if (isset($_POST['download']) && $_POST['download'] === 'all') {
    $sql_all_download = "SELECT * FROM international_schools";
    $stmt_all = $conn->prepare($sql_all_download);
    $stmt_all->execute();
    $result_all = $stmt_all->get_result();

    if ($result_all->num_rows > 0) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="all_international_schools_' . date('Y-m-d') . '.csv"');

        $output = fopen('php://output', 'w');
        
        // Fetch and write the header row
        $header = [];
        $fields = $result_all->fetch_fields();
        foreach ($fields as $field) {
            $header[] = $field->name;
        }
        fputcsv($output, $header);

        // Fetch and write all data rows
        while ($row = $result_all->fetch_assoc()) {
            fputcsv($output, $row);
        }

        fclose($output);
    } else {
        echo "<script>alert('No records found to download.'); window.location.href='view_international_schools.php';</script>";
    }

    $stmt_all->close();
    $conn->close();
    exit;
}

// Download school-wise data
if (isset($_POST['action']) && $_POST['action'] === 'download' && isset($_POST['school_name'])) {
    $school_name_query = trim($_POST['school_name']);

    if (empty($school_name_query)) {
        echo "<script>alert('School name not provided for download.'); window.location.href='view_international_schools.php';</script>";
        exit;
    }

    // Now, prepare the main download query using the user's input.
    $sql_download = "SELECT * FROM international_schools WHERE school_name = ?";
    $stmt_download = $conn->prepare($sql_download);
    $stmt_download->bind_param('s', $school_name_query);
    $stmt_download->execute();
    $result_download = $stmt_download->get_result();

    if ($result_download->num_rows > 0) {
        // Since we are using the exact school name from the dropdown, we can use it directly for the filename.
        $sanitized_name = preg_replace('/[^a-zA-Z0-9\s_]/', '', $school_name_query);
        $sanitized_name = str_replace(' ', '_', trim($sanitized_name));
        $filename = 'data_' . $sanitized_name . '_' . date('Y-m-d') . '.csv';

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        $output = fopen('php://output', 'w');

        $header = [];
        $fields = $result_download->fetch_fields();
        foreach ($fields as $field) {
            $header[] = $field->name;
        }
        fputcsv($output, $header);

        while ($row = $result_download->fetch_assoc()) {
            fputcsv($output, $row);
        }

        fclose($output);
    } else {
        echo "<script>alert('No records found for that school.'); window.location.href='view_international_schools.php';</script>";
    }

    $stmt_download->close();
    $conn->close();
    exit;
}

// ----------------------------------------------------------------------------------
// Fetch unique school names for the dropdown
// ----------------------------------------------------------------------------------
$school_names = [];
$sql_schools = "SELECT DISTINCT school_name FROM international_schools ORDER BY school_name ASC";
$stmt_schools = $conn->prepare($sql_schools);
$stmt_schools->execute();
$result_schools = $stmt_schools->get_result();

while ($row = $result_schools->fetch_assoc()) {
    $school_names[] = $row['school_name'];
}
$stmt_schools->close();

// ----------------------------------------------------------------------------------
// Pagination & Search Logic
// ----------------------------------------------------------------------------------

$records_per_page = isset($_GET['per_page']) ? intval($_GET['per_page']) : 10;
$allowed_per_page = [2, 4, 10, 25, 50, 100];
if (!in_array($records_per_page, $allowed_per_page)) {
    $records_per_page = 10;
}

$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
if ($current_page <= 0) {
    $current_page = 1;
}

$search_term = isset($_GET['search']) ? $_GET['search'] : '';

$sql_where = '';
$params = [];
$param_types = '';

if (!empty($search_term)) {
    $sql_where = " WHERE school_name LIKE ?";
    $params[] = '%' . $search_term . '%';
    $param_types .= 's';
}

$total_records_query = "SELECT COUNT(*) AS total FROM international_schools" . $sql_where;
$stmt_count = $conn->prepare($total_records_query);

if (!empty($params)) {
    $stmt_count->bind_param($param_types, ...$params);
}

$stmt_count->execute();
$total_records_result = $stmt_count->get_result();
$total_records = $total_records_result->fetch_assoc()['total'];
$stmt_count->close();

$total_pages = ceil($total_records / $records_per_page);

if ($current_page > $total_pages && $total_pages > 0) {
    $current_page = $total_pages;
} elseif ($total_pages == 0) {
    $current_page = 1;
}

$offset = ($current_page - 1) * $records_per_page;
if ($offset < 0) {
    $offset = 0;
}

$order_by = '';
if (!empty($search_term)) {
    $order_by = " ORDER BY CASE WHEN school_name LIKE ? THEN 0 ELSE 1 END, school_name ASC, id ASC";
    array_unshift($params, '%' . $search_term . '%');
    $param_types = 's' . $param_types;
} else {
    $order_by = " ORDER BY id ASC";
}

$sql = "SELECT * FROM international_schools" . $sql_where . $order_by . " LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);

$params[] = $records_per_page;
$params[] = $offset;
$param_types .= 'ii';

$stmt->bind_param($param_types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    die("Query failed: " . $conn->error);
}

function safe($val) {
    return htmlspecialchars($val ?? 'N/A');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View International Schools</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #dbe9f4, #f0f4f8);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}
.navbar {
    background: linear-gradient(90deg, #004080, #0073e6);
}
.navbar-brand {
    font-weight: 600;
    font-size: 1.5rem;
    color: #fff !important;
}
.logo {
    height: 40px;
    margin-right: 10px;
}
.container {
    flex: 1;
}
h2 {
    color: #004080;
    font-weight: 600;
}
.table-responsive {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-radius: 12px;
    overflow-x: auto;
}
.table th {
    background: linear-gradient(90deg, #004080, #0073e6);
    color: #fff;
    white-space: nowrap;
}
.table td, .table th {
    vertical-align: middle;
    font-size: 0.85rem;
}
footer {
    background: linear-gradient(90deg, #004080, #0073e6);
    color: #fff;
    text-align: center;
    padding: 1rem 0;
    margin-top: auto;
    font-size: 0.95rem;
    position: relative;
    overflow: hidden;
}
footer::after {
    content: "";
    position: absolute;
    top: 0;
    left: -150%;
    height: 100%;
    width: 50%;
    background: linear-gradient(120deg, transparent, rgba(255,255,255,0.4), transparent);
    animation: shine 3s infinite;
}
@keyframes shine {
    0% { left: -150%; }
    50% { left: 150%; }
    100% { left: 150%; }
}
.back-btn {
    background: #fff;
    color: #004080;
    font-weight: 500;
    border-radius: 20px;
    padding: 0.3rem 1rem;
    transition: all 0.3s ease;
    font-size: 0.9rem;
}
.back-btn:hover {
    background: #e6f0ff;
    color: #00264d;
    transform: scale(1.05);
}
.pagination-controls {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 1rem;
}
@media (max-width: 576px) {
    .navbar-brand {
        font-size: 1.2rem;
    }
    .back-btn {
        font-size: 0.8rem;
        padding: 0.2rem 0.7rem;
    }
    .search-form {
        flex-direction: column;
        align-items: stretch;
    }
    .search-form .form-control,
    .search-form .btn {
        margin-right: 0 !important;
        margin-bottom: 0.5rem;
    }
    .pagination-controls {
        flex-direction: column;
        align-items: flex-start;
    }
}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="#">
            <img src="../../images/logo.png" alt="Logo" class="logo">
            <span>OEC</span>
        </a>
        <div class="ms-auto me-2">
            <a href="view_school_registration.php" class="back-btn text-decoration-none">
                <i class="bi bi-arrow-left-circle"></i> Back
            </a>
        </div>
    </div>
</nav>

<div class="container my-4">
    <h2 class="mb-4 text-center">All International School Records</h2>
    
    <div class="d-flex flex-column flex-md-row justify-content-between mb-4">
        <form method="get" class="d-flex flex-grow-1 me-md-2 mb-2 mb-md-0 search-form">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Search by school name..." value="<?= safe($search_term) ?>">
                <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i></button>
                <a href="view_international_schools.php" class="btn btn-secondary"><i class="bi bi-x-circle"></i> Clear</a>
            </div>
            <input type="hidden" name="per_page" value="<?= $records_per_page ?>">
        </form>
        
        <div class="dropdown">
            <button class="btn btn-success dropdown-toggle w-100" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-download"></i> Download
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li>
                    <form action="view_international_schools.php" method="POST" style="display:inline;">
                        <input type="hidden" name="download" value="all">
                        <button type="submit" class="dropdown-item">All Records</button>
                    </form>
                </li>
                <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#schoolWiseModal">School-wise</a></li>
            </ul>
        </div>
    </div>

    <div class="pagination-controls">
        <form method="get" class="d-flex align-items-center mb-2 mb-md-0">
            <label for="per_page" class="form-label me-2 mb-0">Records per page:</label>
            <select name="per_page" id="per_page" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="2" <?= $records_per_page == 2 ? 'selected' : '' ?>>2</option>
                <option value="4" <?= $records_per_page == 4 ? 'selected' : '' ?>>4</option>
                <option value="10" <?= $records_per_page == 10 ? 'selected' : '' ?>>10</option>
                <option value="25" <?= $records_per_page == 25 ? 'selected' : '' ?>>25</option>
                <option value="50" <?= $records_per_page == 50 ? 'selected' : '' ?>>50</option>
                <option value="100" <?= $records_per_page == 100 ? 'selected' : '' ?>>100</option>
            </select>
            <input type="hidden" name="page" value="<?= $current_page ?>">
            <input type="hidden" name="search" value="<?= safe($search_term) ?>">
        </form>
        <nav aria-label="Page navigation">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= $current_page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page - 1 ?>&per_page=<?= $records_per_page ?>&search=<?= safe($search_term) ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= $i == $current_page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&per_page=<?= $records_per_page ?>&search=<?= safe($search_term) ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $current_page >= $total_pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page + 1 ?>&per_page=<?= $records_per_page ?>&search=<?= safe($search_term) ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>

    <div class="table-responsive mt-3">
        <table class="table table-bordered table-striped align-middle text-center mb-0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>School ID</th>
                    <th>School Name</th>
                    <th>Country</th>
                    <th>Address</th>
                    <th>State</th>
                    <th>City</th>
                    <th>ZIP</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Website</th>
                    <th>School Type</th>
                    <th>School Level</th>
                    <th>Accreditation</th>
                    <th>Grades From</th>
                    <th>Grades To</th>
                    <th>Total Students</th>
                    <th>Total Teachers</th>
                    <th>Principal</th>
                    <th>Teacher</th>
                    <th>Registered At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= safe($row['id']) ?></td>
                            <td><?= safe($row['school_id']) ?></td>
                            <td><?= safe($row['school_name']) ?></td>
                            <td><?= safe($row['country']) ?></td>
                            <td><?= safe($row['address']) ?></td>
                            <td><?= safe($row['state']) ?></td>
                            <td><?= safe($row['city']) ?></td>
                            <td><?= safe($row['zip']) ?></td>
                            <td><?= safe($row['contact_number']) ?></td>
                            <td><?= safe($row['email']) ?></td>
                            <td><?= safe($row['website']) ?></td>
                            <td><?= safe($row['school_type']) ?></td>
                            <td><?= safe($row['school_level']) ?></td>
                            <td><?= safe($row['accreditation']) ?></td>
                            <td><?= safe($row['grade_from']) ?></td>
                            <td><?= safe($row['grade_to']) ?></td>
                            <td><?= safe($row['total_students']) ?></td>
                            <td><?= safe($row['total_teachers']) ?></td>
                            <td>
                                <?= safe($row['principal_name']) ?><br>
                                <?= safe($row['principal_mobile']) ?><br>
                                <?= safe($row['principal_email']) ?>
                            </td>
                            <td>
                                <?= safe($row['teacher_name']) ?><br>
                                <?= safe($row['teacher_mobile']) ?><br>
                                <?= safe($row['teacher_email']) ?>
                            </td>
                            <td><?= safe($row['reg_date']) ?></td>
                            <td class="text-nowrap">
                                <a href="edit_international_school.php?id=<?= safe($row['id']) ?>" class="btn btn-sm btn-warning" aria-label="Edit">
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <a href="delete_interschool.php?id=<?= safe($row['id']) ?>" class="btn btn-sm btn-danger" aria-label="Delete" onclick="return confirm('Are you sure you want to delete this record?')">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="22">No records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="pagination-controls mt-3">
        <div>Showing <?= $offset + 1 ?> to <?= min($offset + $records_per_page, $total_records) ?> of <?= $total_records ?> entries</div>
        <nav aria-label="Page navigation">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= $current_page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page - 1 ?>&per_page=<?= $records_per_page ?>&search=<?= safe($search_term) ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= $i == $current_page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&per_page=<?= $records_per_page ?>&search=<?= safe($search_term) ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $current_page >= $total_pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page + 1 ?>&per_page=<?= $records_per_page ?>&search=<?= safe($search_term) ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>

<footer class="footer">
    &copy; <?= date('Y') ?> Olympiad Examination Council. All rights reserved.
</footer>

<div class="modal fade" id="schoolWiseModal" tabindex="-1" aria-labelledby="schoolWiseModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="schoolWiseModalLabel">School Data Options</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="view_international_schools.php" method="POST" id="school-data-form">
        <div class="modal-body">
            <p>Select the school to download its data.</p>
            <div class="mb-3">
                <label for="school_name_input" class="form-label">School Name</label>
                <!-- Dropdown populated with school names -->
                <select class="form-select" id="school_name_input" name="school_name" required>
                    <option value="">Select a school...</option>
                    <?php foreach ($school_names as $school): ?>
                        <option value="<?= safe($school) ?>"><?= safe($school) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success" id="download-data-btn">
            <i class="bi bi-download"></i> Download
          </button>
          <input type="hidden" name="action" id="form-action" value="download">
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// The original JavaScript logic is still valid as it listens for the click event and sets the form action
document.getElementById('download-data-btn')?.addEventListener('click', function(e) {
    document.getElementById('form-action').value = 'download';
    document.getElementById('school-data-form').setAttribute('action', 'view_international_schools.php');
});

document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const searchTerm = urlParams.get('search');
    if (searchTerm) {
        // You can add logic here to highlight the search term if needed
    }
});
</script>
</body>
</html>
<?php 
// Close the database connection
if (isset($stmt)) {
    $stmt->close();
}
if (isset($conn)) {
    $conn->close();
}
?>
