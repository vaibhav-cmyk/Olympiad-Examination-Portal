<?php
// include 'auth_master.php'; // This line is commented out as it was in the original code
include '../db.php';

// ----------------------------------------------------------------------------------
// Download Logic - Placed at the very top to avoid header conflicts
// ----------------------------------------------------------------------------------
if (isset($_GET['download']) && $_GET['download'] == 1) {
    // Determine if the download should be filtered or all records
    $search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
    $sql_where = '';
    $params = [];
    $param_types = '';
    $filename = 'registrations_' . date('Y-m-d') . '.csv';

    if (!empty($search_term)) {
        $sql_where = " WHERE S_Cname LIKE ?";
        $params[] = '%' . $search_term . '%';
        $param_types .= 's';
        $filename = 'filtered_registrations_' . date('Y-m-d') . '.csv';
    }

    $sql = "SELECT * FROM olympiad_registrations" . $sql_where . " ORDER BY RegID ASC";
    $stmt = mysqli_prepare($conn, $sql);

    // Bind parameters if they exist
    if (!empty($params)) {
        mysqli_stmt_bind_param($stmt, $param_types, ...$params);
    }
    
    // Execute the query
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Set the CSV headers
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

    // Open a file handle for writing to the output buffer
    $output = fopen('php://output', 'w');

    if (mysqli_num_rows($result) > 0) {
        // Get column headers from the first row
        $header_row = [];
        $fields = mysqli_fetch_fields($result);
        foreach ($fields as $field) {
            $header_row[] = $field->name;
        }
        fputcsv($output, $header_row);

        // Write all data rows to the CSV
        while ($row = mysqli_fetch_assoc($result)) {
            fputcsv($output, $row);
        }
    } else {
        // No records found, provide an empty CSV or handle differently
        fputcsv($output, ["No records found."]);
    }

    // Close resources and exit
    fclose($output);
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    exit;
}

// ----------------------------------------------------------------------------------
// Fetch unique school names for the dropdown filter
// ----------------------------------------------------------------------------------
$schools_sql = "SELECT DISTINCT S_Cname FROM olympiad_registrations WHERE S_Cname IS NOT NULL AND S_Cname != '' ORDER BY S_Cname ASC";
$schools_result = mysqli_query($conn, $schools_sql);
$school_names = [];
if ($schools_result) {
    while ($row = mysqli_fetch_assoc($schools_result)) {
        $school_names[] = $row['S_Cname'];
    }
}
// ----------------------------------------------------------------------------------
// Pagination & Search Logic (Original code)
// ----------------------------------------------------------------------------------
$records_per_page = isset($_GET['per_page']) ? intval($_GET['per_page']) : 25;
$allowed_per_page = [10, 25, 50, 100, 200, 500];
if (!in_array($records_per_page, $allowed_per_page)) {
    $records_per_page = 25; 
}

$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
if ($current_page <= 0) {
    $current_page = 1;
}

$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
$sql_where = '';
$params = [];
$param_types = '';

if (!empty($search_term)) {
    $sql_where = " WHERE S_Cname LIKE ?";
    $params[] = '%' . $search_term . '%';
    $param_types .= 's';
}

$total_records_query = "SELECT COUNT(*) AS total FROM olympiad_registrations" . $sql_where;
$stmt_count = mysqli_prepare($conn, $total_records_query);

if (!empty($search_term)) {
    mysqli_stmt_bind_param($stmt_count, $param_types, ...$params);
}

mysqli_stmt_execute($stmt_count);
$total_records_result = mysqli_stmt_get_result($stmt_count);
$total_records = mysqli_fetch_assoc($total_records_result)['total'];
mysqli_stmt_close($stmt_count);

$total_pages = ceil($total_records / $records_per_page);

if ($current_page > $total_pages && $total_pages > 0) {
    $current_page = $total_pages;
} elseif ($total_pages == 0) {
    $current_page = 1;
}

$offset = ($current_page - 1) * $records_per_page;
if ($offset < 0) {
    $offset = 0;
}

if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']); 

    $delete_sql = "DELETE FROM olympiad_registrations WHERE RegID = ?";
    $stmt_del = mysqli_prepare($conn, $delete_sql);
    mysqli_stmt_bind_param($stmt_del, "i", $delete_id);

    if (mysqli_stmt_execute($stmt_del)) {
        header("Location: view_registrations.php?msg=deleted&page={$current_page}&per_page={$records_per_page}&search=" . urlencode($search_term));
        exit();
    } else {
        // Using a message box instead of alert()
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                const modal = new bootstrap.Modal(document.getElementById('messageModal'));
                const modalBody = document.getElementById('messageModalBody');
                modalBody.innerText = '❌ Error deleting record.';
                modal.show();
            });
            </script>";
    }
    mysqli_stmt_close($stmt_del);
}

$sql = "SELECT * FROM olympiad_registrations" . $sql_where . " ORDER BY RegID ASC LIMIT ? OFFSET ?";
$stmt = mysqli_prepare($conn, $sql);

if (!empty($search_term)) {
    mysqli_stmt_bind_param($stmt, "sii", $params[0], $records_per_page, $offset);
} else {
    mysqli_stmt_bind_param($stmt, "ii", $records_per_page, $offset);
}

mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$count = $offset + 1;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registered Students</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { background-color: #f2f5f8; font-family: 'Poppins', sans-serif; display: flex; flex-direction: column; min-height: 100vh; }
        main { flex: 1; }
        .navbar-brand { font-weight: 600; font-size: 1.4rem; letter-spacing: .5px; }
        footer { background-color: #004080; color: #ccc; text-align: center; padding: 1rem 0; font-size: 0.85rem; margin-top: auto; }
        footer a { color: #ccc; text-decoration: none; }
        footer a:hover { text-decoration: underline; color: #fff; }
        .table-container { background: white; padding: 20px; border-radius: 16px; box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1); animation: fadeIn 0.8s ease; }
        .table th { background-color: #003366; color: white; font-size: 13px; font-weight: 500; }
        .table td { font-size: 13px; vertical-align: middle; }
        .table tbody tr { transition: background-color 0.3s ease, transform 0.2s ease; }
        .table tbody tr:hover { background-color: #f1f5fb; transform: scale(1.01); }
        .action-btn { display: inline-flex; align-items: center; justify-content: center; width: 30px; height: 30px; font-size: 0.9rem; padding: 0; margin-right: 6px; border-radius: 4px; transition: all 0.2s ease-in-out; }
        .action-btn:last-child { margin-right: 0; }
        .action-btn:hover { transform: translateY(-2px) scale(1.1); }
        .action-icon { pointer-events: none; }
        @keyframes fadeIn { from {opacity: 0; transform: translateY(20px);} to {opacity: 1; transform: translateY(0);} }
        .pagination-controls { display: flex; justify-content: space-between; align-items: center; }
        @media (max-width: 768px) {
            .pagination-controls { flex-direction: column; align-items: flex-start; }
            .pagination-controls > div:first-child { margin-bottom: 1rem; }
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg" style="background-color: #004080;">
    <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
        <a class="navbar-brand d-flex align-items-center gap-2 text-white" href="#">
            <img src="../images/logo.png" alt="Logo" style="height: 40px; width: auto;">
            <span>OEC Portal</span>
        </a>
        <a href="admin_home.php" class="btn btn-light btn-sm">
            <i class="bi bi-arrow-left-circle me-1"></i> Back to Dashboard
        </a>
    </div>
</nav>

<main>
    <div class="container py-4">

        <?php if (isset($_GET['msg'])): ?>
            <div class="alert alert-success alert-dismissible fade show animate__animated animate__fadeInDown" role="alert" id="statusAlert">
                <?php
                if ($_GET['msg'] === 'updated') {
                    echo "✅ Student record updated successfully.";
                } elseif ($_GET['msg'] === 'deleted') {
                    echo "🗑️ Student record deleted successfully.";
                }
                ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <h2 class="text-center mb-4 fw-bold text-primary">Registered Students</h2>
        
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-3">
            <form method="get" class="d-flex flex-grow-1 me-md-2 mb-2 mb-md-0 search-form">
                <div class="input-group">
                    <input type="text" name="search" class="form-control" placeholder="Search by school name..." value="<?= htmlspecialchars($search_term) ?>">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i></button>
                    <a href="view_registrations.php" class="btn btn-secondary"><i class="bi bi-x-circle"></i> Clear</a>
                </div>
                <input type="hidden" name="per_page" value="<?= $records_per_page ?>">
            </form>
            <div class="dropdown">
                <button class="btn btn-success dropdown-toggle w-100" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-download"></i> Download
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                        <a class="dropdown-item" href="?download=1">All Records</a>
                    </li>
                    <li>
                        <!-- This link now triggers a modal to select the school -->
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#downloadFilteredModal">Filtered Records</a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="pagination-controls mb-3">
            <div class="d-flex align-items-center me-3">
                <label for="per_page" class="form-label me-2 mb-0">Records per page:</label>
                <select name="per_page" id="per_page" class="form-select form-select-sm" onchange="window.location.href = `?page=1&per_page=${this.value}&search=<?= urlencode($search_term) ?>`">
                    <?php foreach ($allowed_per_page as $value): ?>
                        <option value="<?= $value ?>" <?= $records_per_page == $value ? 'selected' : '' ?>><?= $value ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <nav aria-label="Page navigation">
                <ul class="pagination pagination-sm mb-0">
                    <li class="page-item <?= $current_page <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="?page=<?= $current_page - 1 ?>&per_page=<?= $records_per_page ?>&search=<?= urlencode($search_term) ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= $i == $current_page ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>&per_page=<?= $records_per_page ?>&search=<?= urlencode($search_term) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= $current_page >= $total_pages ? 'disabled' : '' ?>">
                        <a class="page-link" href="?page=<?= $current_page + 1 ?>&per_page=<?= $records_per_page ?>&search=<?= urlencode($search_term) ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>

        <div class="table-container table-responsive">
            <table class="table table-bordered table-striped table-hover align-middle">
                <thead class="text-center">
                    <tr>
                        <th>#</th>
                        <th>Reg ID</th>
                        <th>Reg No</th>
                        <th>Student Name</th>
                        <th>Parent Name</th>
                        <th>DOB</th>
                        <th>Gender</th>
                        <th>Mobile</th>
                        <th>WhatsApp</th>
                        <th>Email</th>
                        <th>Home Address</th>
                        <th>Country</th>
                        <th>State</th>
                        <th>District</th>
                        <th>School Name</th>
                        <th>School Address</th>
                        <th>School Category</th>
                        <th>Grade</th>
                        <th>Branch Code</th>
                        <th>Exam Language</th>
                        <th style="width: 110px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr class='text-center'>";
                            echo "<td>" . $count++ . "</td>";
                            echo "<td>" . htmlspecialchars($row['RegID']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['RegNo']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Stud_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Parent_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Stud_dob']) . "</td>";
                            echo "<td>";
                            if ($row['Gender'] == 1) { echo "Male"; } elseif ($row['Gender'] == 2) { echo "Female"; } else { echo htmlspecialchars($row['Gender']); }
                            echo "</td>";
                            echo "<td>" . htmlspecialchars($row['MobileNo']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['WhatsAppNo']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Email_ID']) . "</td>";
                            echo "<td>" . nl2br(htmlspecialchars($row['Home_addr'])) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Country']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['S_State']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['District']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['S_Cname']) . "</td>";
                            echo "<td>" . nl2br(htmlspecialchars($row['S_Caddr'])) . "</td>";
                            echo "<td>" . htmlspecialchars($row['S_Cat']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Grade']) . "</td>";
                            if (is_numeric($row['Grade']) && $row['Grade'] >= 1 && $row['Grade'] <= 10) { echo "<td>Not Applicable</td>"; } else { echo "<td>" . htmlspecialchars($row['C_Branch']) . "</td>"; }
                            echo "<td>" . htmlspecialchars($row['Exam_Lg']) . "</td>";
                            echo "<td>
                                <div class='d-flex justify-content-center gap-2'>
                                    <a href='edit_student.php?id=" . $row['RegID'] . "' class='btn btn-outline-primary btn-sm action-btn' title='Edit'>
                                        <i class='bi bi-pencil-square action-icon'></i>
                                    </a>
                                    <!-- This button now triggers the Bootstrap modal -->
                                    <button type='button' class='btn btn-outline-danger btn-sm action-btn' title='Delete' data-bs-toggle='modal' data-bs-target='#deleteConfirmModal' data-id='" . $row['RegID'] . "'>
                                        <i class='bi bi-trash-fill action-icon'></i>
                                    </button>
                                </div>
                            </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='21' class='text-center'>No student records found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
        <div class="pagination-controls mt-3">
            <div>Showing <?= $offset + 1 ?> to <?= min($offset + $records_per_page, $total_records) ?> of <?= $total_records ?> entries</div>
            <nav aria-label="Page navigation">
                <ul class="pagination pagination-sm mb-0">
                    <li class="page-item <?= $current_page <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="?page=<?= $current_page - 1 ?>&per_page=<?= $records_per_page ?>&search=<?= urlencode($search_term) ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= $i == $current_page ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>&per_page=<?= $records_per_page ?>&search=<?= urlencode($search_term) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= $current_page >= $total_pages ? 'disabled' : '' ?>">
                        <a class="page-link" href="?page=<?= $current_page + 1 ?>&per_page=<?= $records_per_page ?>&search=<?= urlencode($search_term) ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</main>

<footer>
    <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Olympiad System | All rights reserved.</p>
        <p class="small">✨ Designed with ❤️ using <a href="https://getbootstrap.com/" target="_blank">Bootstrap</a></p>
    </div>
</footer>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteConfirmModal" tabindex="-1" aria-labelledby="deleteConfirmModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteConfirmModalLabel">Confirm Deletion</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this student record?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <a id="confirmDeleteLink" href="#" class="btn btn-danger">Yes, Delete</a>
            </div>
        </div>
    </div>
</div>

<!-- Filtered Download Modal -->
<div class="modal fade" id="downloadFilteredModal" tabindex="-1" aria-labelledby="downloadFilteredModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="downloadForm" method="get" action="view_registrations.php">
                <div class="modal-header">
                    <h5 class="modal-title" id="downloadFilteredModalLabel">Download Filtered Records</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Select a school to download records for:</p>
                    <div class="form-group">
                        <select class="form-select" id="schoolSelect" name="search" required>
                            <option value="">-- Select School --</option>
                            <?php foreach ($school_names as $school): ?>
                                <option value="<?= htmlspecialchars($school) ?>"><?= htmlspecialchars($school) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="download" value="1">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Download CSV</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Generic Message Modal for errors/messages -->
<div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="messageModalLabel">Message</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="messageModalBody">
        <!-- Message will be inserted here by JavaScript -->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Automatically close the status alert after 3 seconds
    setTimeout(function () {
        const alertBox = document.getElementById("statusAlert");
        if (alertBox) {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alertBox);
            bsAlert.close();
        }
    }, 3000);

    // JavaScript to handle the delete confirmation modal
    const deleteConfirmModal = document.getElementById('deleteConfirmModal');
    deleteConfirmModal.addEventListener('show.bs.modal', function (event) {
        // Button that triggered the modal
        const button = event.relatedTarget;
        // Extract info from data-id attribute
        const regId = button.getAttribute('data-id');
        // Get the link in the modal footer
        const confirmDeleteLink = deleteConfirmModal.querySelector('#confirmDeleteLink');
        
        // Construct the delete URL with the current page parameters
        const currentPage = <?= $current_page ?>;
        const perPage = <?= $records_per_page ?>;
        const searchTerm = "<?= htmlspecialchars($search_term) ?>";
        confirmDeleteLink.href = `view_registrations.php?delete_id=${regId}&page=${currentPage}&per_page=${perPage}&search=${encodeURIComponent(searchTerm)}`;
    });
</script>
</body>
</html>
<?php
if (isset($stmt)) {
    mysqli_stmt_close($stmt);
}
if (isset($conn)) {
    mysqli_close($conn);
}
?>
