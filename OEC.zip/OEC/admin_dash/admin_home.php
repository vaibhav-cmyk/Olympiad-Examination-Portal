<?php
session_start();

// Set cache control headers to prevent caching of this sensitive page
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
header("Pragma: no-cache"); // HTTP 1.0
header("Expires: 0"); // Proxies

if (!isset($_SESSION['staff'])) {
    header("Location: login.php"); // or your login page
    exit();
}

// Optional: Update last_activity for session timeout
$_SESSION['last_activity'] = time();

// ... rest of your admin_home.php code
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>OEC Portal</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<style>
/* Your existing CSS here */
html, body {
  height: 100%;
  font-family: 'Inter', sans-serif;
  overflow-x: hidden;
}

body {
  display: flex;
  flex-direction: column;
  background-color: rgb(204, 219, 233);
}

main {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 1rem;
}

.navbar {
  background-color: #004080;
}

footer {
  background-color: #004080;
  color: white;
  text-align: center;
  padding: 1rem 0;
  margin-top: auto;
  font-size: 0.9rem;
  word-wrap: break-word;
  line-height: 1.2;
}

.offcanvas {
  background-color: #fdfdfd;
  color: #333;
  width: 260px;
  max-width: 100%;
  box-shadow: 2px 0 8px rgba(0,0,0,0.1);
}

.offcanvas-header {
  background-color: #004080;
  color: #fff;
}

.accordion-item {
  border: none;
  margin-bottom: 4px;
  overflow: hidden;
}

.accordion-button {
  background-color: #f1f5f9;
  font-weight: 500;
  color: #004080;
  font-size: 0.95rem;
  border-radius: 0 !important;
  box-shadow: none !important;
  transition: background-color 0.2s ease;
}

.accordion-button:hover {
  background-color: #e6edf5;
}

.accordion-button:focus {
  box-shadow: none;
}

.accordion-button:not(.collapsed) {
  color: #fff;
  background-color: #004080;
}

.accordion-body {
  background-color: #f9fbfd;
  padding: 0.5rem 0.75rem;
  overflow-x: hidden;
}

.accordion-body .nav-link {
  color: #495057;
  font-size: 0.9rem;
  margin-bottom: 0.3rem;
  display: flex;
  align-items: center;
  gap: 4px;
  text-decoration: none;
  transition: all 0.2s ease-in-out;
  word-wrap: break-word;
  white-space: normal;
  padding: 0.4rem 0.75rem;
}

.accordion-body .nav-link:hover {
  color: #004080;
  background-color: #e9f1fb;
}

.offcanvas-body {
  overflow-y: auto;
  max-height: calc(100vh - 56px);
  max-width: 100%;
}

.navbar .container-fluid {
  flex-wrap: wrap;
  overflow-x: hidden;
}

/* custom-card styles */
.custom-card {
  border: 1px solid #ddd;
  border-radius: 8px;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.custom-card:hover {
  transform: translateY(-3px) scale(1.02);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.custom-card .card-title {
  color: #004080;
}

.custom-card .btn-primary {
  background-color: #004080;
  border: none;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.custom-card .btn-primary:hover {
  background-color: #003060;
  transform: scale(1.05);
  box-shadow: 0 0 10px rgba(0,64,128,0.4);
}

/* Responsive */
@media (max-width: 768px) {
  .navbar-brand {
    font-size: 1.2rem;
  }

  footer {
    font-size: 0.8rem;
    padding: 0.5rem;
  }

  .accordion-button {
    font-size: 0.85rem;
  }

  .custom-card {
    margin-bottom: 1rem;
  }
}

@media (max-width: 576px) {
  .navbar-brand {
    font-size: 1rem;
  }

  .accordion-body .nav-link {
    font-size: 0.8rem;
  }

  footer {
    font-size: 0.7rem;
    padding: 0.25rem;
  }
}

@media (max-width: 400px) {
  .navbar-brand {
    font-size: 0.85rem;
  }

  .navbar img {
    height: 30px;
  }
}

@media (max-width: 350px) {
  .offcanvas {
    width: 100%;
  }

  .navbar .navbar-brand {
    font-size: 0.75rem;
  }

  .navbar img {
    height: 28px;
  }
}

</style>

</head>

<body>

<nav class="navbar" style="background: linear-gradient(90deg, #004080, #0073e6);">
    <div class="container-fluid justify-content-between align-items-center flex-wrap">
        <div class="d-flex align-items-center">
            <button class="navbar-toggler me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu">
                <span class="navbar-toggler-icon"></span>
            </button>

            <img src="../images/logo.png" alt="Logo" style="height: 40px; width: auto;" class="me-2">

            <a class="navbar-brand mb-0 h1 text-white" href="#">
                <b>Olympiad Examination Council</b>
            </a>
        </div>

        <div class="mt-2 mt-sm-0">
            <a href="logout.php" class="btn btn-light btn-sm px-3">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>
</nav>

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">


<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasMenu">
    <div class="offcanvas-header border-bottom">
        <h5 class="offcanvas-title fw-bold">Navigation Menu</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body p-2">
        <div class="accordion" id="menuAccordion">

            <div class="accordion-item mb-2">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseStudents">
                        <i class="bi bi-people-fill me-2"></i> Students
                    </button>
                </h2>
                <div id="collapseStudents" class="accordion-collapse collapse">
                    <div class="accordion-body">
                        <a href="indian_index.php" class="nav-link ps-4">
                            <i class="bi bi-person me-1"></i> Indian Form
                        </a>
                        <a href="foreign_index.php" class="nav-link ps-4">
                            <i class="bi bi-globe me-1"></i> Foreign Form
                        </a>
                    </div>
                </div>
            </div>

            <div class="accordion-item mb-2">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExam">
                        <i class="bi bi-people-fill me-2"></i> Exam
                    </button>
                </h2>
                <div id="collapseExam" class="accordion-collapse collapse">
                    <div class="accordion-body">
                        <a href="activeInactiveExam.php" class="nav-link ps-4">
                            <i class="bi bi-eye-fill me-1"></i> View Indian Students
                        </a>
                        <a href="foreign_students.php" class="nav-link ps-4">
                            <i class="bi bi-eye-fill me-1"></i> View International Students
                        </a>
                    </div>
                </div>
            </div>

            <div class="accordion-item mb-2">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                        <i class="bi bi-house-door-fill me-2"></i> School Registration
                    </button>
                </h2>
                <div id="collapseOne" class="accordion-collapse collapse">
                    <div class="accordion-body">
                        <a href="school_affiliation/country.html" class="nav-link ps-4">
                            <i class="bi bi-plus-circle me-1"></i> Register School
                        </a>
                        <a href="school_affiliation/view_school_registration.php" class="nav-link ps-4">
                            <i class="bi bi-plus-circle me-1"></i> View Registered School
                        </a>
                    </div>
                </div>
            </div>

            <div class="accordion-item mb-2">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAddQuestions">
                        <i class="bi bi-question-circle-fill me-2"></i> Add Questions
                    </button>
                </h2>
                <div id="collapseAddQuestions" class="accordion-collapse collapse">
                    <div class="accordion-body">
                        <a href="s4/index.php" class="nav-link ps-4">
                            <i class="bi bi-plus-circle me-1"></i> Add / Manage Questions
                        </a>
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseLogout">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </button>
                </h2>
                <div id="collapseLogout" class="accordion-collapse collapse">
                    <div class="accordion-body">
                        <a href="logout.php" class="nav-link ps-4">
                            <i class="bi bi-box-arrow-right me-1"></i> Logout
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<main class="d-flex justify-content-center align-items-center p-3">
    <div class="container">
        <div class="row justify-content-center g-4">
            <div class="col-md-5">
                <div class="card custom-card text-center shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">Indian</h5>
                        <p class="card-text">Form for Indian students to register for the Olympiad Examination.</p>
                        <a href="view_registrations.php" class="btn btn-primary">Go to Indian Form</a>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="card custom-card text-center shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">Foreign</h5>
                        <p class="card-text">Form for Foreign students to register for the Olympiad Examination.</p>
                        <a href="foreign_stud_view.php" class="btn btn-primary">Go to Foreign Form</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<footer>
    &copy; <span id="year"></span> Olympiad Examination Council. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('year').textContent = new Date().getFullYear();
});
</script>
</body>
</html>