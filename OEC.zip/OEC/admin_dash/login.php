<?php
session_start();

// Set cache control headers to prevent caching of this page
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
header("Pragma: no-cache"); // HTTP 1.0
header("Expires: 0"); // Proxies

// Optional: session timeout (e.g., 30 mins = 1800 sec)
$timeout_duration = 1800;

// If already logged in, redirect to admin_home
if (isset($_SESSION['staff'])) {
    // Check session timeout
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout_duration) {
        session_destroy();
        // Clear session cookie as well (optional, but good practice)
        setcookie(session_name(), '', time() - 3600, '/'); // Set cookie to expire in the past
        header("Location: login.php?timeout=1");
        exit;
    }
    $_SESSION['last_activity'] = time();
    header("Location: admin_home.php");
    exit;
}

// Ensure db.php connects successfully
include '../db.php'; // Make sure this path is correct

// Display messages for logout or timeout if present in URL
$message = '';
if (isset($_GET['loggedout'])) {
    $message = '<div class="alert alert-success">✅ You have been successfully logged out.</div>';
} elseif (isset($_GET['timeout'])) {
    $message = '<div class="alert alert-warning">⚠️ Your session has timed out. Please log in again.</div>';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Staff Login | OEC</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
/* Your existing CSS here */
body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #a8edea, #fed6e3);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

.navbar {
    background-color: #004080;
}

.navbar-brand {
    font-weight: 700;
    color: #fff !important;
    text-align: center;
    flex-wrap: wrap;
}

.navbar-brand img {
    height: 50px;
    width: auto;
}

.navbar-text {
    font-size: clamp(1rem, 3vw, 1.4rem);
    line-height: 1.2;
    display: block;
    color: #fff;
}

.footer {
    background-color: #004080;
    color: #fff;
    text-align: center;
    padding: 0.75rem 0;
    margin-top: auto;
    font-size: 0.9rem;
}

.login-card {
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    padding: 35px;
    max-width: 420px;
    width: 100%;
    animation: fadeIn 1s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

.login-card h3 {
    text-align: center;
    margin-bottom: 25px;
    color: #004080;
    font-weight: 600;
}

.btn-primary {
    background: linear-gradient(45deg, #004080, #0066cc);
    border: none;
    font-weight: 500;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    background: linear-gradient(45deg, #002f5f, #0055aa);
    transform: scale(1.02);
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
}

.form-control {
    border-radius: 10px;
    min-height: 45px;
}

.form-control:focus {
    box-shadow: 0 0 5px rgba(74, 20, 140, 0.5);
    border-color: #4a148c;
}

.alert {
    font-size: 0.95rem;
    text-align: center;
}
</style>
</head>

<body>

<nav class="navbar shadow">
    <div class="container">
        <a class="navbar-brand mx-auto d-flex flex-column align-items-center gap-1" href="#">
            <img src="../images/logo.png" alt="Logo">
            <span class="navbar-text">Olympiad Examination Council</span>
        </a>
    </div>
</nav>

<main class="flex-grow-1 d-flex align-items-center justify-content-center py-5">
<div class="login-card">
    <h3>✨ Staff Login ✨</h3>

    <?php echo $message; // Display messages here ?>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);

        // Use prepared statements to prevent SQL Injection
        $stmt = $conn->prepare("SELECT * FROM staff WHERE email = ?");

        if ($stmt === false) {
            die("Error preparing SQL statement: (" . $conn->errno . ") " . $conn->error);
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();

            // Use password_verify for secure password checking
            if (password_verify($password, $user['password'])) {
                $_SESSION['staff'] = $user['email'];
                $_SESSION['last_activity'] = time(); // Set initial activity time
                header("Location: admin_home.php");
                exit;
            } else {
                echo '<div class="alert alert-danger">❌ Incorrect password.</div>';
            }
        } else {
            echo '<div class="alert alert-danger">❌ Email not registered.</div>';
        }

        $stmt->close();
    }
    ?>

    <form method="post">
        <input class="form-control mb-3 shadow-sm" name="email" placeholder="📧 Email" required type="email">
        <input class="form-control mb-3 shadow-sm" name="password" placeholder="🔒 Password" required type="password">
        <button class="btn btn-primary w-100">Login</button>
    </form>

    </div>
</main>

<footer class="footer">
    &copy; <?= date("Y") ?> Olympiad Examination Council. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>