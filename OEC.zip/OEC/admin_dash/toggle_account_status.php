<?php
require_once '../db.php';
require_once 'auth_admin.php'; 

$regid = $_POST['regid'];
$exam = $_POST['exam'];
$status = $_POST['status'];
$date = date('Y-m-d');

// Fetch RegNo from olympiad_registrations
$regno_query = $conn->prepare("SELECT RegNo FROM olympiad_registrations WHERE RegID = ?");
$regno_query->bind_param("s", $regid);
$regno_query->execute();
$regno_result = $regno_query->get_result();
$regno = $regno_result->fetch_assoc()['RegNo'];
$regno_query->close();

// Map exams to amounts
$examAmounts = [
    "International Mathematics Olympiad" => 175,
    "International English Olympiad" => 175,
    "International Science Olympiad" => 175,
    "International Space Olympiad" => 400,
    "International Physics Olympiad" => 250,
    "International Chemistry Olympiad" => 250,
    "International Biology Olympiad" => 250,
    "International Commerce Olympiad" => 250,
    "International Geography Olympiad" => 250,
    "International Economics Olympiad" => 250

];

$amount = $examAmounts[$exam] ?? 0;

// Check if payment record already exists
$check = $conn->prepare("SELECT * FROM payment_transactions WHERE RegID = ? AND Exam = ?");
$check->bind_param("ss", $regid, $exam);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    // Update existing record
    $stmt = $conn->prepare("UPDATE payment_transactions SET AccountStatus = ? WHERE RegID = ? AND Exam = ?");
    $stmt->bind_param("sss", $status, $regid, $exam);
} else {
    // Insert new record with required fields
$stmt = $conn->prepare("INSERT INTO payment_transactions
        (RegID, RegNo, Exam, Amount, PaymentStatus, PaymentMode, PaymentDate, AccountStatus)
        VALUES (?, ?, ?, ?, 'Success', 'Offline', ?, ?)");
$stmt->bind_param("sssiss", $regid, $regno, $exam, $amount, $date, $status);
}

if ($stmt->execute()) {
    header("Location: activeInactiveExam.php");
    exit;
} else {
    echo "Error: " . $conn->error;
}
?>
