<?php
session_start();
include '../db.php';

// Check DB connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ----------------------------------------------------------------------------------
// Pagination Logic
// ----------------------------------------------------------------------------------
$records_per_page = isset($_GET['per_page']) ? intval($_GET['per_page']) : 25;
$allowed_per_page = [10, 25, 50, 100, 200, 500];
if (!in_array($records_per_page, $allowed_per_page)) {
    $records_per_page = 25;
}

$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
if ($current_page <= 0) {
    $current_page = 1;
}

// Fetch total count of unique Student_ID
$total_records_query = "SELECT COUNT(DISTINCT Student_ID) AS total FROM olympiad_registration";
$total_records_result = $conn->query($total_records_query);
$total_records = $total_records_result->fetch_assoc()['total'];

$total_pages = ceil($total_records / $records_per_page);
$offset = ($current_page - 1) * $records_per_page;

// Fetch unique Student_IDs for current page
$sql_ids = "SELECT DISTINCT Student_ID FROM olympiad_registration ORDER BY Student_ID ASC LIMIT ? OFFSET ?";
$stmt_ids = $conn->prepare($sql_ids);
$stmt_ids->bind_param("ii", $records_per_page, $offset);
$stmt_ids->execute();
$result_ids = $stmt_ids->get_result();

$current_page_ids = [];
while ($row = $result_ids->fetch_assoc()) {
    $current_page_ids[] = $row['Student_ID'];
}
$stmt_ids->close();

$student_list = [];
if (!empty($current_page_ids)) {
    $id_list = implode("','", $current_page_ids);

    $sql_data = "SELECT 
        o.Student_ID, o.Stud_name, o.Parent_name, o.Stud_dob, o.Gender, o.Country, 
        o.MobileNo, o.Email_ID, o.Grade, o.C_Branch, o.Exam_Lg,
        p.Exam, p.TransactionID, p.Amount, p.PaymentID, 
        p.PaymentStatus, p.PaymentDate, p.PaymentMode, p.AccountStatus
    FROM olympiad_registration o
    LEFT JOIN foreign_payment_transactions p ON o.Student_ID = p.Student_ID
    WHERE o.Student_ID IN ('$id_list')
    ORDER BY o.Student_ID, p.Exam";

    $result_data = $conn->query($sql_data);

    if ($result_data && $result_data->num_rows > 0) {
        while ($row = $result_data->fetch_assoc()) {
            $sid = $row['Student_ID'];

            if (!isset($student_list[$sid])) {
                $student_list[$sid] = $row;
                $student_list[$sid]['SelectedExams'] = [];
                $student_list[$sid]['Payments'] = [];
            }

            if (!empty($row['Exam']) && !in_array($row['Exam'], $student_list[$sid]['SelectedExams'])) {
                $student_list[$sid]['SelectedExams'][] = $row['Exam'];
            }

            $student_list[$sid]['Payments'][] = $row;
        }
    }
}

// Active count
$activeStudentsByMobile = [];
foreach ($student_list as $student) {
    $mobile = $student['MobileNo'];
    if (isset($activeStudentsByMobile[$mobile])) {
        continue;
    }
    foreach ($student['Payments'] as $payment) {
        if ($payment['AccountStatus'] === 'Active') {
            $activeStudentsByMobile[$mobile] = true;
            break;
        }
    }
}
$active_students = count($activeStudentsByMobile);

// Subjects mapping
$subjectsByClass = [];
for ($i = 1; $i <= 4; $i++) {
    $subjectsByClass[$i] = [
        "International Mathematics Olympiad",
        "International English Olympiad"
    ];
}
for ($i = 5; $i <= 10; $i++) {
    $subjectsByClass[$i] = [
        "International Mathematics Olympiad",
        "International English Olympiad",
        "International Science Olympiad",
        "International Space Olympiad"
    ];
}
$grade11_12_subjects = [
    "science" => [
        "International Physics Olympiad",
        "International Chemistry Olympiad",
        "International Mathematics Olympiad",
        "International Biology Olympiad"
    ],
    "commerce" => [
        "International English Olympiad",
        "International Commerce Olympiad"
    ],
    "arts" => [
        "International English Olympiad",
        "International Geography Olympiad",
        "International Economics Olympiad"
    ]
];
$all11_12_subjects = [];
foreach ($grade11_12_subjects as $branchSubjects) {
    $all11_12_subjects = array_merge($all11_12_subjects, $branchSubjects);
}
$all11_12_subjects = array_values(array_unique($all11_12_subjects));
$subjectsByClass[11] = $all11_12_subjects;
$subjectsByClass[12] = $all11_12_subjects;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>OEC Foreign Student Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
body {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    background-color: rgb(187, 203, 219);
    font-family: 'Inter', sans-serif;
}
.navbar {
    background-color: #004080;
}
.navbar-brand {
    color: white !important;
    font-weight: 600;
    font-size: 1.5rem;
}
main h1 {
    color: #004080;
    font-weight: 600;
}
footer {
    background-color: #004080;
    color: white;
    text-align: center;
    padding: 1rem 0;
    margin-top: auto;
    font-size: 0.95rem;
}
.pagination-controls {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
@media (max-width: 768px) {
    .pagination-controls {
        flex-direction: column;
        align-items: flex-start;
    }
    .pagination-controls > div:first-child {
        margin-bottom: 1rem;
    }
}
</style>
</head>

<body>

<nav class="navbar navbar-expand-lg">
    <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
        <a class="navbar-brand d-flex align-items-center gap-2 text-white" href="#">
            <img src="../images/logo.png" alt="Logo" style="height: 40px; width: auto;">
            <span>OEC Portal</span>
        </a>
        <a href="masterdashboard.php" class="btn btn-light btn-sm">
            <i class="bi bi-arrow-left-circle me-1"></i> Back to Dashboard
        </a>
    </div>
</nav>

<main class="container my-5">
    <h1>Foreign Student</h1>
    <p>Below is the list of all registered foreign students along with payment and related details.</p>

    <p><strong>Active Students:</strong> <?= $active_students ?></p>

    <div class="mb-3 d-flex gap-3 flex-wrap">
        <input type="text" id="searchInput" class="form-control" placeholder="Search by Student Name..." style="flex: 1; min-width: 200px;">
        <input type="text" id="studentIdInput" class="form-control" placeholder="Search by Student ID..." style="flex: 1; min-width: 200px;">
        <input type="text" id="examInput" class="form-control" placeholder="Search by Exam..." style="flex: 1; min-width: 200px;">
    </div>

    <div class="pagination-controls mb-3">
        <form method="get" class="d-flex align-items-center">
            <label for="per_page" class="form-label me-2 mb-0">Records per page:</label>
            <select name="per_page" id="per_page" class="form-select form-select-sm" onchange="this.form.submit()">
                <?php foreach ($allowed_per_page as $val): ?>
                    <option value="<?= $val ?>" <?= $records_per_page == $val ? 'selected' : '' ?>><?= $val ?></option>
                <?php endforeach; ?>
            </select>
            <input type="hidden" name="page" value="<?= $current_page ?>">
        </form>
        <nav aria-label="Page navigation">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= $current_page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page - 1 ?>&per_page=<?= $records_per_page ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= $i == $current_page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&per_page=<?= $records_per_page ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $current_page >= $total_pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page + 1 ?>&per_page=<?= $records_per_page ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>

    <div class="table-responsive mt-4">
    <table class="table table-bordered table-striped" id="foreignTable">
    <thead class="table-dark">
    <tr>
        <th>Student ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Mobile</th>
        <th>Grade</th>
        <th>Branch</th>
        <th>Exam</th>
        <th>Payment Status</th>
        <th>Payment Mode</th>
        <th>Payment Date</th>
        <th>Account Status</th>
    </tr>
    </thead>
    <tbody>

    <?php 
    foreach ($student_list as $student): 
        $grade = (int)$student['Grade'];
        $sid = $student['Student_ID'];

        if ($grade == 11 || $grade == 12) {
            $branch = strtolower(trim($student['C_Branch']));
            if (!empty($branch) && isset($grade11_12_subjects[$branch])) {
                $availableExams = $grade11_12_subjects[$branch];
            } else {
                $branch = '-';
                $availableExams = [];
            }
        } else {
            $branch = '-';
            $availableExams = $subjectsByClass[$grade] ?? [];
        }

        $examCount = count($availableExams) ?: 1;
        $firstRow = true;

        if (empty($availableExams)) {
            $availableExams = ['-'];
        }

        foreach ($availableExams as $examForGrade):
            $matchedPayment = null;
            foreach ($student['Payments'] as $payment) {
                if ($payment['Exam'] === $examForGrade) {
                    $matchedPayment = $payment;
                    break;
                }
            }

            $accountStatus = $matchedPayment['AccountStatus'] ?? '';
            $transactionId = $matchedPayment['TransactionID'] ?? 0;
    ?>
    <tr data-grade="<?= $grade ?>">
    <?php if ($firstRow): ?>
        <td rowspan="<?= $examCount ?>"><?= $student['Student_ID'] ?></td>
        <td rowspan="<?= $examCount ?>" class="student-name"><?= $student['Stud_name'] ?></td>
        <td rowspan="<?= $examCount ?>"><?= $student['Email_ID'] ?></td>
        <td rowspan="<?= $examCount ?>"><?= $student['MobileNo'] ?></td>
        <td rowspan="<?= $examCount ?>"><?= $student['Grade'] ?></td>
        <td rowspan="<?= $examCount ?>"><?= htmlspecialchars($branch) ?></td>
    <?php endif; ?>

        <td><?= htmlspecialchars($examForGrade) ?></td>
        <td><?= htmlspecialchars($matchedPayment['PaymentStatus'] ?? '-') ?></td>
        <td><?= htmlspecialchars($matchedPayment['PaymentMode'] ?? '-') ?></td>
        <td><?= htmlspecialchars($matchedPayment['PaymentDate'] ?? '-') ?></td>
        <td>
<?php
    if ($matchedPayment) {
        if ($matchedPayment['PaymentStatus'] === 'Success') {
            echo "<button class='btn btn-success btn-sm' disabled>Active</button>";
        } else {
            if ($accountStatus === 'Active') {
                echo "<form method='POST' action='toggle_account_status_foreign.php' class='d-inline account-form'>
                    <input type='hidden' name='transaction_id' value='{$transactionId}'>
                    <input type='hidden' name='student_id' value='{$student['Student_ID']}'>
                    <input type='hidden' name='exam' value='{$examForGrade}'>
                    <input type='hidden' name='status' value='Inactive'>
                    <button type='submit' class='btn btn-success btn-sm'>Active</button>
                </form>";
            } else {
                echo "<form method='POST' action='toggle_account_status_foreign.php' class='d-inline account-form'>
                    <input type='hidden' name='transaction_id' value='{$transactionId}'>
                    <input type='hidden' name='student_id' value='{$student['Student_ID']}'>
                    <input type='hidden' name='exam' value='{$examForGrade}'>
                    <input type='hidden' name='status' value='Active'>
                    <button type='submit' class='btn btn-danger btn-sm'>Inactive</button>
                </form>";
            }
        }
    } else {
        echo "<form method='POST' action='toggle_account_status_foreign.php' class='d-inline account-form'>
                <input type='hidden' name='transaction_id' value='0'>
                <input type='hidden' name='student_id' value='{$student['Student_ID']}'>
                <input type='hidden' name='exam' value='{$examForGrade}'>
                <input type='hidden' name='status' value='Active'>
                <button type='submit' class='btn btn-danger btn-sm opacity-75'>Inactive</button>
            </form>";
    }
?>
</td>

    </tr>
    <?php 
        $firstRow = false;
        endforeach;
    endforeach; 
    ?>

    </tbody>
    </table>
    </div>

    <div class="pagination-controls mt-3">
        <div>Showing <?= $offset + 1 ?> to <?= min($offset + $records_per_page, $total_records) ?> of <?= $total_records ?> entries</div>
        <nav aria-label="Page navigation">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= $current_page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page - 1 ?>&per_page=<?= $records_per_page ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= $i == $current_page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&per_page=<?= $records_per_page ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $current_page >= $total_pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page + 1 ?>&per_page=<?= $records_per_page ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>

</main>

<script>
function filterTable() {
    const nameFilter = document.getElementById("searchInput").value.toLowerCase();
    const studentIdFilter = document.getElementById("studentIdInput").value.toLowerCase();
    const examFilter = document.getElementById("examInput").value.toLowerCase();

    const rows = Array.from(document.querySelectorAll("#foreignTable tbody tr"));
    const groups = [];
    let currentGroup = [];
    rows.forEach(row => {
        const cells = row.querySelectorAll("td");
        if (cells[0] && cells[0].hasAttribute("rowspan")) {
            if (currentGroup.length > 0) groups.push(currentGroup);
            currentGroup = [row];
        } else {
            currentGroup.push(row);
        }
    });
    if (currentGroup.length > 0) groups.push(currentGroup);

    groups.forEach(group => {
        let showGroup = false;
        group.forEach(row => {
            const cells = row.querySelectorAll("td");
            const isFirstRow = cells[0] && cells[0].hasAttribute("rowspan");

            if (isFirstRow) {
                const nameCell = row.querySelector(".student-name");
                if (nameFilter && nameCell && nameCell.textContent.toLowerCase().includes(nameFilter)) {
                    showGroup = true;
                }
                const idCell = cells[0];
                if (studentIdFilter && idCell && idCell.textContent.toLowerCase().includes(studentIdFilter)) {
                    showGroup = true;
                }
            }

            const examCell = isFirstRow ? cells[6] : cells[0];
            if (examFilter && examCell && examCell.textContent.toLowerCase().includes(examFilter)) {
                showGroup = true;
            }
        });

        group.forEach(row => {
            row.style.display = showGroup ? "" : "none";
        });
    });
}


document.getElementById("searchInput").addEventListener("keyup", filterTable);
document.getElementById("studentIdInput").addEventListener("keyup", filterTable);
document.getElementById("examInput").addEventListener("keyup", filterTable);
</script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".account-form").forEach(form => {
        form.addEventListener("submit", function (e) {
            const status = this.querySelector("input[name='status']").value;
            if (status === "Active") {
                if (!confirm("Do you want to activate this exam?")) {
                    e.preventDefault();
                }
            } else if (status === "Inactive") {
                if (!confirm("Do you want to deactivate this exam?")) {
                    e.preventDefault();
                }
            }
        });
    });
});
</script>


<footer class="text-center mt-auto">
&copy; <?= date("Y") ?> Olympiad Examination Council. All rights reserved.
</footer>


