<!-- <?php include 'auth_admin.php'; ?> -->

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Olympiad Question Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<style>
body {
    background-color: #f4f6f9;
    font-family: 'Segoe UI', Roboto, sans-serif;
}

.navbar-custom {
    background-color: #004080;
}

.navbar-brand {
    font-weight: bold;
    font-size: 1.5rem;
}

.navbar-brand span {
    font-size: 1.4rem;
}

.card-hover {
    transition: transform 0.4s ease, box-shadow 0.4s ease;
    border: none;
    border-radius: 12px;
}

.card-hover:hover {
    transform: translateY(-8px) scale(1.02);
    box-shadow: 0 12px 25px rgba(0, 0, 0, 0.1);
}

.card-title {
    font-weight: 600;
    color: #004080;
}

footer {
    background-color: #004080;
    color: #ccc;
    padding: 20px 0;
    margin-top: 80px;
}

footer a {
    color: #ccc;
    text-decoration: none;
}

footer a:hover {
    text-decoration: underline;
}

.btn-success, .btn-primary {
    transition: all 0.3s ease-in-out;
}

.btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 12px rgba(0, 128, 0, 0.3);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 12px rgba(0, 64, 128, 0.3);
}

.display-4 {
    transition: transform 0.5s ease-in-out;
}

.card-hover:hover .display-4 {
    transform: rotate(5deg) scale(1.1);
}

h2 {
    animation: fadeInDown 1s ease-out;
}

@keyframes fadeInDown {
    0% {opacity: 0; transform: translateY(-30px);}
    100% {opacity: 1; transform: translateY(0);}
}
</style>
</head>
<body>

<!-- Header -->
<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
    <a class="navbar-brand d-flex align-items-center gap-2 text-white" href="#">
      <img src="../../images/logo.png" alt="Logo" style="height: 40px; width: auto;">
      <span>OEC Portal</span>
    </a>
    <a href="../admin_home.php" class="btn btn-light btn-sm">
      <i class="bi bi-arrow-left-circle me-1"></i> Back to Dashboard
    </a>
  </div>
</nav>

<!-- Main -->
<div class="container py-5">
    <h2 class="text-center mb-5 fw-bold text-primary">Olympiad Question Management</h2>

    <div class="row justify-content-center g-4">
        <div class="col-md-6 col-lg-5">
            <div class="card card-hover text-center p-4 bg-white shadow-sm">
                <div class="card-body">
                    <i class="bi bi-plus-circle display-4 text-success mb-3"></i>
                    <h5 class="card-title">Add New Question</h5>
                    <p class="card-text">Quickly create and insert new Olympiad questions to engage students.</p>
                    <a href="add_question.php" class="btn btn-success w-100 mt-3">
                        <i class="bi bi-plus-circle me-1"></i> Add Question
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-lg-5">
            <div class="card card-hover text-center p-4 bg-white shadow-sm">
                <div class="card-body">
                    <i class="bi bi-table display-4 text-primary mb-3"></i>
                    <h5 class="card-title">View / Edit / Delete</h5>
                    <p class="card-text">Manage your existing Olympiad questions easily and efficiently.</p>
                    <a href="view_questions.php" class="btn btn-primary w-100 mt-3">
                        <i class="bi bi-table me-1"></i> Manage Questions
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="text-center">
    <div class="container">
        <p class="mb-0">&copy; <span id="year"></span> Olympiad System | All rights reserved.</p>
        <p class="small">Designed with ❤️ using Bootstrap</p>
    </div>
</footer>

<script>
document.getElementById("year").textContent = new Date().getFullYear();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
