<!-- <?php include 'auth_admin.php'; ?> -->

<?php
$conn = new mysqli("localhost", "root", "", "user_system");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$id = $_GET['id'] ?? 0;
if (!$id) {
    echo "<div style='padding: 20px; font-family: sans-serif;'>❌ Invalid ID. <a href='view_questions.php'>Back to questions</a></div>";
    exit;
}

// Delete the question
$stmt = $conn->prepare("DELETE FROM questions WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

// Redirect after success
if ($stmt->affected_rows > 0) {
    echo "<div style='padding: 20px; font-family: sans-serif;'>✅ Question deleted successfully. <a href='view_questions.php'>Back to questions</a></div>";
} else {
    echo "<div style='padding: 20px; font-family: sans-serif;'>⚠️ Question not found or already deleted. <a href='view_questions.php'>Back to questions</a></div>";
}
?>
