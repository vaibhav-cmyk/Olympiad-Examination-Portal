<?php include 'auth_admin.php'; ?>

<?php
session_start();
$conn = new mysqli("localhost", "root", "", "user_system");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Step 1: Handle Exam Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['submit_answers'])) {
    $_SESSION['student_name'] = $_POST['student_name'];
    $_SESSION['class'] = $_POST['class'];
    $_SESSION['subject'] = $_POST['subject'];
    $_SESSION['language'] = $_POST['language'];

    $class = $conn->real_escape_string($_POST['class']);
    $subject = $conn->real_escape_string($_POST['subject']);
    $language = $conn->real_escape_string($_POST['language']);

    $questions = [];
    $sections = [1 => 10, 2 => 5, 3 => 2];
    foreach ($sections as $section => $limit) {
        $sql = "SELECT * FROM olympiad_questions WHERE class='$class' AND subject='$subject' AND language='$language' AND section='$section' ORDER BY RAND() LIMIT $limit";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $questions[] = $row;
        }
    }

    $_SESSION['questions'] = $questions;
    $_SESSION['started'] = true;
    header("Location: start_exam.php");
    exit;
}

// Step 2: Handle Answer Submission
if (isset($_POST['submit_answers'])) {
    $questions = $_SESSION['questions'] ?? [];
    $score = 0;
    $section_scores = [1 => 0, 2 => 0, 3 => 0];

    foreach ($questions as $q) {
        $qid = $q['id'];
        $correct = $q['correct_option'];
        $selected = $_POST["answer_$qid"] ?? '';
        $section = $q['section'];
        $marks = ($section == 1) ? 3 : (($section == 2) ? 2 : 5);
        if ($selected === $correct) {
            $score += $marks;
            $section_scores[$section] += $marks;
        }
    }

    $student_name = $_SESSION['student_name'] ?? 'Student';
    echo "<div class='container mt-5'>";
    echo "<h3 class='text-success text-center'>🎉 Thank you, <strong>$student_name</strong>!</h3>";
    echo "<p class='text-center'>You scored <strong>$score</strong> out of <strong>50</strong>.</p>";
    echo "<ul class='list-group mx-auto' style='max-width: 400px;'>";
    echo "<li class='list-group-item'>Section 1 Score: <strong>{$section_scores[1]}</strong> / 30</li>";
    echo "<li class='list-group-item'>Section 2 Score: <strong>{$section_scores[2]}</strong> / 10</li>";
    echo "<li class='list-group-item'>Section 3 Score: <strong>{$section_scores[3]}</strong> / 10</li>";
    echo "</ul>";
    echo "<div class='text-center mt-3'><a href='start_exam.php' class='btn btn-primary'>🔁 Try Again</a></div>";
    echo "</div>";
    session_destroy();
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>🎓 Student Olympiad Exam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        #webcam {
            width: 180px;
            height: 130px;
            border: 2px solid #ccc;
            background: url('https://dummyimage.com/180x130/ccc/000&text=Webcam+Feed') center center no-repeat;
            background-size: cover;
            margin-bottom: 10px;
        }
        .timer {
            font-size: 1.2rem;
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <?php if (!isset($_SESSION['questions'])): ?>
        <h2 class="text-center mb-4">🧑‍🎓 Start Olympiad Exam</h2>
        <form action="start_exam.php" method="POST">
            <div class="mb-3">
                <label class="form-label">🆔 Student Name / Roll Number</label>
                <input type="text" name="student_name" class="form-control" required>
            </div>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label">📚 Class</label>
                    <select name="class" id="class" class="form-select" required>
                        <?php for ($i = 1; $i <= 12; $i++): ?>
                            <option value="<?= $i ?>"><?= $i ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">📖 Subject</label>
                    <select name="subject" id="subject" class="form-select" required></select>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">🗣️ Medium</label>
                    <select name="language" class="form-select" required>
                        <option value="English">English</option>
                        <option value="Hindi">Hindi</option>
                        <option value="Marathi">Marathi</option>
                        <option value="Kannada">Kannada</option>
                    </select>
                </div>
            </div>
            <div class="text-center">
                <button class="btn btn-success px-4">🚀 Start Exam</button>
            </div>
        </form>
    <?php else: ?>
        <h3 class="text-center mb-4">📝 Olympiad Exam for <?= htmlspecialchars($_SESSION['student_name']) ?></h3>
        <div class="text-center mb-4">
            <div id="webcam" class="mx-auto"></div>
            <div class="timer" id="timer">⏳ 60:00</div>
        </div>
        <form method="POST" onsubmit="return validateForm();">
            <div class="alert alert-info">
                <strong>Instructions:</strong><br>
                🕒 Total Duration: 60 minutes<br>
                ✅ Section 1: 10 questions × 3 marks = 30 marks<br>
                ✅ Section 2: 5 questions × 2 marks = 10 marks<br>
                ✅ Section 3: 2 questions × 5 marks = 10 marks<br>
                📸 Webcam will remain active during the exam (dummy simulated).
            </div>
            <?php foreach ($_SESSION['questions'] as $index => $q): ?>
                <div class="card mb-3">
                    <div class="card-header bg-light">
                        <strong>Q<?= $index + 1 ?> (Section <?= $q['section'] ?>):</strong> <?= $q['question'] ?>
                    </div>
                    <div class="card-body" id="q<?= $q['id'] ?>">
                        <?php foreach (['A', 'B', 'C', 'D'] as $opt): ?>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="answer_<?= $q['id'] ?>" value="<?= $opt ?>" required>
                                <label class="form-check-label"><?= $q["option_$opt"] ?></label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
            <div class="text-center">
                <button name="submit_answers" class="btn btn-primary px-5">✅ Submit Answers</button>
            </div>
        </form>
        <script>
            let time = 60 * 60;
            const timerElement = document.getElementById('timer');
            const countdown = setInterval(() => {
                const minutes = Math.floor(time / 60);
                const seconds = time % 60;
                timerElement.textContent = `⏳ ${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                if (--time < 0) {
                    clearInterval(countdown);
                    alert("⏰ Time is up! Submitting your answers.");
                    document.querySelector("form").submit();
                }
            }, 1000);

            function validateForm() {
                const unanswered = [...document.querySelectorAll('.card-body')].filter(q => !q.querySelector('input:checked'));
                if (unanswered.length > 0) {
                    unanswered[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
                    alert("❗ Please answer all questions before submitting.");
                    return false;
                }
                return true;
            }

            document.getElementById('class')?.addEventListener('change', () => {
                const classId = document.getElementById('class').value;
                const subjectSelect = document.getElementById('subject');
                subjectSelect.innerHTML = '';
                const subjects = {
                    1: ['Math', 'Science'],
                    2: ['Math', 'Science', 'English'],
                    10: ['Physics', 'Chemistry', 'Biology'],
                    11: ['PCM', 'PCB'],
                    12: ['Maths', 'Commerce']
                };
                const options = subjects[classId] || ['General Knowledge'];
                for (const sub of options) {
                    const opt = document.createElement('option');
                    opt.value = sub;
                    opt.textContent = sub;
                    subjectSelect.appendChild(opt);
                }
            });
            document.getElementById('class')?.dispatchEvent(new Event('change'));
        </script>
    <?php endif; ?>
</div>
</body>
</html>
