<?php
require_once '../../db.php';

$perPage = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $perPage;

$filter = [];
$params = [];
$types = '';

if (!empty($_GET['class'])) {
    $filter[] = "class = ?";
    $params[] = $_GET['class'];
    $types .= 'i';
}
if (!empty($_GET['subject'])) {
    $filter[] = "subject = ?";
    $params[] = $_GET['subject'];
    $types .= 's';
}
if (!empty($_GET['language'])) {
    $filter[] = "language = ?";
    $params[] = $_GET['language'];
    $types .= 's';
}
if (!empty($_GET['section'])) {
    $filter[] = "section = ?";
    $params[] = $_GET['section'];
    $types .= 's';
}

$where = $filter ? "WHERE " . implode(" AND ", $filter) : "";

$stmt = $conn->prepare("SELECT COUNT(*) FROM questions $where");
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$stmt->bind_result($total);
$stmt->fetch();
$stmt->close();

$totalPages = ceil($total / $perPage);

$query = "SELECT * FROM questions $where ORDER BY id DESC LIMIT $offset, $perPage";
$stmt = $conn->prepare($query);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Olympiad Questions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 40px;
        }
        .filter-box {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 8px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }
        table th, table td {
            vertical-align: top;
            font-size: 14px;
        }
        .question-content {
            white-space: pre-wrap;
        }
        .question-content table {
            border-collapse: collapse;
            width: 100%;
        }
        .question-content table, .question-content th, .question-content td {
            border: 1px solid #ccc;
            padding: 5px;
        }
        .action-buttons .btn {
            margin-right: 4px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0">📘 View Olympiad Questions</h2>
        <div>
            <a href="index.php" class="btn btn-outline-primary btn-sm">🏠 Home</a>
            <a href="add_question.php" class="btn btn-outline-success btn-sm">➕ Add Question</a>
        </div>
    </div>

    <div class="filter-box">
        <form method="GET">
            <div class="row g-3">
                <div class="col-md-2">
                    <label for="class" class="form-label">Class</label>
                    <select name="class" id="class" class="form-select">
                        <option value="">All</option>
                        <?php for ($i = 1; $i <= 12; $i++): ?>
                            <option value="<?= $i ?>" <?= ($_GET['class'] ?? '') == $i ? 'selected' : '' ?>><?= $i ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="subject" class="form-label">Subject</label>
                    <select name="subject" id="subject" class="form-select">
                        <option value="">All</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Language</label>
                    <select name="language" class="form-select">
                        <option value="">All</option>
                        <?php foreach (["English", "Hindi", "Marathi", "Kannada"] as $lang): ?>
                            <option value="<?= $lang ?>" <?= ($_GET['language'] ?? '') === $lang ? 'selected' : '' ?>><?= $lang ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="section" class="form-label">Section</label>
                    <select name="section" id="section" class="form-select">
                        <option value="">All</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary me-2">🔍 Filter</button>
                    <a href="view_questions.php" class="btn btn-secondary">❌ Clear</a>
                </div>
            </div>
        </form>
    </div>

    <div class="table-responsive bg-white rounded shadow-sm p-3">
        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Class</th>
                    <th>Subject</th>
                    <th>Language</th>
                    <th>Section</th>
                    <th>Question</th>
                    <th>Options</th>
                    <th>Correct</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result->num_rows > 0): while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['class'] ?></td>
                    <td><?= $row['subject'] ?></td>
                    <td><?= $row['language'] ?></td>
                    <td><?= $row['section'] ?></td>
                    <td class="question-content"><?= htmlspecialchars_decode($row['question']) ?></td>
                    <td class="question-content">
                        A: <?= htmlspecialchars_decode($row['option_a']) ?><br><br>
                        B: <?= htmlspecialchars_decode($row['option_b']) ?><br><br>
                        C: <?= htmlspecialchars_decode($row['option_c']) ?><br><br>
                        D: <?= htmlspecialchars_decode($row['option_d']) ?>
                    </td>
                    <td><?= $row['correct_answer'] ?></td>
                    <td class="action-buttons">
                        <a href="edit_question.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="delete_question.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this question?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; else: ?>
                <tr><td colspan="9" class="text-center">No records found</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <nav>
        <ul class="pagination justify-content-center mt-4">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?= ($i === $page) ? 'active' : '' ?>">
                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ["page" => $i])) ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>

<script>
const subjectsByClass = {
    1: ["International Mathematics Olympiad", "International English Olympiad"],
    2: ["International Mathematics Olympiad", "International English Olympiad"],
    3: ["International Mathematics Olympiad", "International English Olympiad"],
    4: ["International Mathematics Olympiad", "International English Olympiad"],
    5: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
    6: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
    7: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
    8: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
    9: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
    10: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
    11: ["International Mathematics Olympiad", "International English Olympiad", "International Physics Olympiad", "International Chemistry Olympiad", "International Biology Olympiad", "International Commerce Olympiad", "International Geography Olympiad"],
    12: ["International Mathematics Olympiad", "International English Olympiad", "International Physics Olympiad", "International Chemistry Olympiad", "International Biology Olympiad", "International Commerce Olympiad", "International Geography Olympiad"]
};

const sectionStructure = {
    "International Mathematics Olympiad": ["Part-1: Mathematical Reasoning", "Part-2: Real Life Mathematics", "Part-3: Previous Grade Section"],
    "International Science Olympiad": ["Part-1: Science Reasoning", "Part-2: Real Life Science", "Part-3: Previous Grade Section"],
    "International English Olympiad": ["Part-1: Word, Vocabulary & Grammar", "Part-2: Reading & Writing", "Part-3: Previous Grade Section"],
    "International Space Olympiad": ["Part-1: Space Science", "Part-2: Space Geography"],
    "International Biology Olympiad": ["Part-1: Biology Reasoning", "Part-2: Real Life Biological Science", "Part-3: Previous Grade Section"],
    "International Physics Olympiad": ["Part-1: Physics Reasoning", "Part-2: Real Life Physical Science", "Part-3: Previous Grade Section"],
    "International Chemistry Olympiad": ["Part-1: Chemistry Reasoning", "Part-2: Real Life Chemical Science", "Part-3: Previous Grade Section"],
    "International Geography Olympiad": ["Part-1: Geography Reasoning", "Part-2: Real Life Geography", "Part-3: Previous Grade Section"],
    "International Commerce Olympiad": ["Part-1: Section – 1", "Part-2: Section – 2", "Part-3: Section – 3"]
};

const classSelect = document.getElementById("class");
const subjectSelect = document.getElementById("subject");
const sectionSelect = document.getElementById("section");

function updateSubjects() {
    const selectedClass = classSelect.value;
    subjectSelect.innerHTML = '<option value="">All</option>';
    sectionSelect.innerHTML = '<option value="">All</option>';

    if (subjectsByClass[selectedClass]) {
        subjectsByClass[selectedClass].forEach(sub => {
            const opt = document.createElement("option");
            opt.value = sub;
            opt.textContent = sub;
            if ("<?= $_GET['subject'] ?? '' ?>" === sub) opt.selected = true;
            subjectSelect.appendChild(opt);
        });
    }

    updateSections();
}

function updateSections() {
    const selectedSubject = subjectSelect.value;
    sectionSelect.innerHTML = '<option value="">All</option>';

    if (sectionStructure[selectedSubject]) {
        sectionStructure[selectedSubject].forEach(sec => {
            const opt = document.createElement("option");
            opt.value = sec;
            opt.textContent = sec;
            if ("<?= $_GET['section'] ?? '' ?>" === sec) opt.selected = true;
            sectionSelect.appendChild(opt);
        });
    }
}

classSelect.addEventListener("change", updateSubjects);
subjectSelect.addEventListener("change", updateSections);

updateSubjects();
</script>
</body>
</html>
