<!-- <?php include 'auth_admin.php'; ?> -->
<?php
$conn = new mysqli("localhost", "root", "", "user_system");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$id = $_GET['id'] ?? 0;
if (!$id) die("Invalid ID.");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['delete'])) {
        $stmt = $conn->prepare("DELETE FROM questions WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        echo "<div style='padding: 20px; font-family: sans-serif;'>✅ Question deleted successfully. <a href='view_questions.php'>Back to questions</a></div>";
        exit;
    }

    $class = $_POST['class'];
    $subject = $_POST['subject'];
    $language = $_POST['language'];
    $section = $_POST['section'];
    $question = $_POST['question'];
    $option_a = $_POST['option_a'];
    $option_b = $_POST['option_b'];
    $option_c = $_POST['option_c'];
    $option_d = $_POST['option_d'];
    $correct = $_POST['correct_answer'];

    $stmt = $conn->prepare("UPDATE questions SET class=?, subject=?, language=?, section=?, question=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_answer=? WHERE id=?");
    $stmt->bind_param("isssssssssi", $class, $subject, $language, $section, $question, $option_a, $option_b, $option_c, $option_d, $correct, $id);
    $stmt->execute();
    header("Location: view_questions.php");
    exit;
}

$stmt = $conn->prepare("SELECT * FROM questions WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Olympiad Question</title>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
    <style>
        .ck-editor__editable { min-height: 120px; }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="card shadow rounded">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Edit Olympiad Question</h4>
        </div>
        <div class="card-body">
            <form method="POST">
                <div class="row mb-3">
                    <div class="col-md-2">
                        <label class="form-label">Class</label>
                        <select name="class" id="class" class="form-select" required>
                            <?php for ($i = 1; $i <= 12; $i++): ?>
                                <option value="<?= $i ?>" <?= ($data['class'] == $i) ? 'selected' : '' ?>><?= $i ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Subject</label>
                        <select name="subject" id="subject" class="form-select" required></select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Language</label>
                        <select name="language" class="form-select" required>
                            <?php foreach (["English", "Hindi", "Marathi", "Kannada"] as $lang): ?>
                                <option value="<?= $lang ?>" <?= ($data['language'] === $lang) ? 'selected' : '' ?>><?= $lang ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Section</label>
                        <select name="section" class="form-select" required></select>
                    </div>
                </div>

                <label class="form-label">Question</label>
                <textarea name="question" id="question"><?= $data['question'] ?></textarea>

                <div class="row mt-3">
                    <div class="col-md-6">
                        <label class="form-label">Option A</label>
                        <textarea name="option_a" id="option_a"><?= $data['option_a'] ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Option B</label>
                        <textarea name="option_b" id="option_b"><?= $data['option_b'] ?></textarea>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-6">
                        <label class="form-label">Option C</label>
                        <textarea name="option_c" id="option_c"><?= $data['option_c'] ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Option D</label>
                        <textarea name="option_d" id="option_d"><?= $data['option_d'] ?></textarea>
                    </div>
                </div>

                <div class="mt-3">
                    <label class="form-label">Correct Answer</label>
                    <select name="correct_answer" class="form-select" required>
                        <?php foreach (["A", "B", "C", "D"] as $opt): ?>
                            <option value="<?= $opt ?>" <?= ($data['correct_answer'] === $opt) ? 'selected' : '' ?>><?= $opt ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mt-4 d-flex justify-content-between">
                    <button type="submit" class="btn btn-success">Update</button>
                    <div>
                        <button type="submit" name="delete" value="1" onclick="return confirm('Are you sure you want to delete this question?');" class="btn btn-danger">Delete</button>
                        <a href="view_questions.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    const subjectsByClass = {
        1: ["International Mathematics Olympiad", "International English Olympiad"],
        2: ["International Mathematics Olympiad", "International English Olympiad"],
        3: ["International Mathematics Olympiad", "International English Olympiad"],
        4: ["International Mathematics Olympiad", "International English Olympiad"],
        5: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
        6: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
        7: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
        8: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
        9: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
        10: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
        11: ["International Mathematics Olympiad", "International English Olympiad", "International Physics Olympiad", "International Chemistry Olympiad", "International Biology Olympiad", "International Commerce Olympiad", "International Geography Olympiad"],
        12: ["International Mathematics Olympiad", "International English Olympiad", "International Physics Olympiad", "International Chemistry Olympiad", "International Biology Olympiad", "International Commerce Olympiad", "International Geography Olympiad"]
    };

    const sectionsBySubject = {
        "International Mathematics Olympiad": ["Part-1: Mathematical Reasoning", "Part-2: Real Life Mathematics", "Part-3: Previous Grade Section"],
        "International Science Olympiad": ["Part-1: Science Reasoning", "Part-2: Real Life Science", "Part-3: Previous Grade Section"],
        "International English Olympiad": ["Part-1: Word, Vocabulary & Grammar", "Part-2: Reading & Writing", "Part-3: Previous Grade Section"],
        "International Space Olympiad": ["Part-1: Space Science", "Part-2: Space Geography"],
        "International Biology Olympiad": ["Part-1: Biology Reasoning", "Part-2: Real Life Biological Science", "Part-3: Previous Grade Section"],
        "International Physics Olympiad": ["Part-1: Physics Reasoning", "Part-2: Real Life Physical Science", "Part-3: Previous Grade Section"],
        "International Chemistry Olympiad": ["Part-1: Chemistry Reasoning", "Part-2: Real Life Chemical Science", "Part-3: Previous Grade Section"],
        "International Geography Olympiad": ["Part-1: Geography Reasoning", "Part-2: Real Life Geography", "Part-3: Previous Grade Section"],
        "International Commerce Olympiad": ["Part-1: Section – 1", "Part-2: Section – 2", "Part-3: Section – 3"]
    };

    const classSelect = document.getElementById("class");
    const subjectSelect = document.getElementById("subject");
    const sectionSelect = document.querySelector("select[name='section']");

    function populateSubjects() {
        const selectedClass = parseInt(classSelect.value);
        const selectedSubject = "<?= $data['subject'] ?>";
        subjectSelect.innerHTML = '';

        if (subjectsByClass[selectedClass]) {
            subjectsByClass[selectedClass].forEach(sub => {
                const opt = document.createElement("option");
                opt.value = sub;
                opt.textContent = sub;
                if (sub === selectedSubject) opt.selected = true;
                subjectSelect.appendChild(opt);
            });
        }
        populateSections();
    }

    function populateSections() {
        const selectedSubject = subjectSelect.value;
        const selectedSection = "<?= $data['section'] ?>";
        sectionSelect.innerHTML = '';

        if (sectionsBySubject[selectedSubject]) {
            sectionsBySubject[selectedSubject].forEach(sec => {
                const opt = document.createElement("option");
                opt.value = sec;
                opt.textContent = sec;
                if (sec === selectedSection) opt.selected = true;
                sectionSelect.appendChild(opt);
            });
        }
    }

    classSelect.addEventListener("change", populateSubjects);
    subjectSelect.addEventListener("change", populateSections);
    window.onload = () => { populateSubjects(); };

    ClassicEditor.create(document.querySelector('#question')).catch(error => console.error(error));
    ClassicEditor.create(document.querySelector('#option_a')).catch(error => console.error(error));
    ClassicEditor.create(document.querySelector('#option_b')).catch(error => console.error(error));
    ClassicEditor.create(document.querySelector('#option_c')).catch(error => console.error(error));
    ClassicEditor.create(document.querySelector('#option_d')).catch(error => console.error(error));
</script>
</body>
</html>
