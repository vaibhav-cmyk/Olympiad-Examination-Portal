<!-- <?php include 'auth_admin.php'; ?> -->

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Olympiad Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.ckeditor.com/ckeditor5/41.1.0/classic/ckeditor.js"></script>
    <style>
        .container { max-width: 950px; margin-top: 40px; }
        .form-section { margin-bottom: 20px; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-primary shadow-sm">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="index.php">🎓 Olympiad Admin Panel</a>
        <div class="d-flex align-items-center">
            <a href="view_questions.php" class="btn btn-outline-light btn-sm me-2">📋 Manage Questions</a>
            <a href="index.php" class="btn btn-outline-light btn-sm">🏠 Home</a>
        </div>
    </div>
</nav>

<?php
session_start();
$success = null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $class = $_POST["class"];
    $subject = $_POST["subject"];
    $language = $_POST["language"];
    $section = $_POST["section"];
    $question = $_POST["question"];
    $optionA = $_POST["option_a"];
    $optionB = $_POST["option_b"];
    $optionC = $_POST["option_c"];
    $optionD = $_POST["option_d"];
    $correct = $_POST["correct_answer"];

    $conn = new mysqli("localhost", "root", "", "user_system");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO questions (class, subject, language, section, question, option_a, option_b, option_c, option_d, correct_answer)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssssss", $class, $subject, $language, $section, $question, $optionA, $optionB, $optionC, $optionD, $correct);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        $_SESSION['success'] = true;
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $success = false;
    }

    $stmt->close();
    $conn->close();
}
if (isset($_SESSION['success'])) {
    $success = true;
    unset($_SESSION['success']);
}
?>

<div class="container">
    <div class="card mb-4 shadow">
        <div class="card-body d-flex justify-content-between align-items-center">
            <h4 class="mb-0">📝 Add Olympiad Question</h4>
        </div>
    </div>

    <?php if (!is_null($success)): ?>
        <div class="alert alert-<?= $success ? 'success' : 'danger' ?> shadow-sm">
            <strong><?= $success ? "✅ Success!" : "❌ Error!" ?></strong>
            <?= $success ? " Question added successfully." : " Failed to add question." ?>
        </div>
    <?php endif; ?>

    <div id="errorBox" class="alert alert-danger d-none"></div>

    <form method="post" onsubmit="return validateForm();">
        <div class="form-section row">
            <div class="col-md-4">
                <label class="form-label">🏫 Class</label>
                <select name="class" id="class" class="form-select" required>
                    <option value="">Select Class</option>
                    <?php for ($i = 1; $i <= 12; $i++): ?>
                        <option value="<?= $i ?>"><?= $i ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">📚 Subject</label>
                <select name="subject" id="subject" class="form-select" required>
                    <option value="">Select Subject</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">🗣️ Language</label>
                <select name="language" id="language" class="form-select" required>
                    <option value="">Select Language</option>
                    <option value="English">English</option>
                    <option value="Hindi">Hindi</option>
                    <option value="Marathi">Marathi</option>
                    <option value="Kannada">Kannada</option>
                </select>
            </div>
        </div>

        <div class="form-section">
            <label class="form-label">📌 Section</label>
            <select name="section" id="section" class="form-select" required>
                <option value="">Select Section</option>
            </select>
        </div>

        <div class="form-section">
            <label class="form-label">❓ Question</label>
            <textarea name="question" id="question"></textarea>
        </div>

        <div class="form-section row">
            <div class="col-md-6">
                <label class="form-label">🔵 Option A</label>
                <textarea name="option_a" id="option_a"></textarea>
            </div>
            <div class="col-md-6">
                <label class="form-label">🟢 Option B</label>
                <textarea name="option_b" id="option_b"></textarea>
            </div>
        </div>

        <div class="form-section row">
            <div class="col-md-6">
                <label class="form-label">🟡 Option C</label>
                <textarea name="option_c" id="option_c"></textarea>
            </div>
            <div class="col-md-6">
                <label class="form-label">🔴 Option D</label>
                <textarea name="option_d" id="option_d"></textarea>
            </div>
        </div>

        <div class="form-section">
            <label class="form-label">✅ Correct Answer</label>
            <select name="correct_answer" id="correct_answer" class="form-select" required>
                <option value="">Select Correct Option</option>
                <option value="A">Option A</option>
                <option value="B">Option B</option>
                <option value="C">Option C</option>
                <option value="D">Option D</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success btn-lg mt-3">➕ Add Question</button>
    </form>
</div>

<script>
    const subjectsByClass = {
        1: ["International Mathematics Olympiad", "International English Olympiad"],
        2: ["International Mathematics Olympiad", "International English Olympiad"],
        3: ["International Mathematics Olympiad", "International English Olympiad"],
        4: ["International Mathematics Olympiad", "International English Olympiad"],
        5: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
        6: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
        7: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
        8: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
        9: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
        10: ["International Mathematics Olympiad", "International English Olympiad", "International Science Olympiad", "International Space Olympiad"],
        11: ["International Mathematics Olympiad", "International English Olympiad", "International Physics Olympiad", "International Chemistry Olympiad", "International Biology Olympiad", "International Commerce Olympiad", "International Geography Olympiad"],
        12: ["International Mathematics Olympiad", "International English Olympiad", "International Physics Olympiad", "International Chemistry Olympiad", "International Biology Olympiad", "International Commerce Olympiad", "International Geography Olympiad"]
    };

    const sectionsBySubject = {
        "International Mathematics Olympiad": ["Part-1: Mathematical Reasoning", "Part-2: Real Life Mathematics", "Part-3: Previous Grade Section"],
        "International Science Olympiad": ["Part-1: Science Reasoning", "Part-2: Real Life Science", "Part-3: Previous Grade Section"],
        "International English Olympiad": ["Part-1: Word, Vocabulary & Grammar", "Part-2: Reading & Writing", "Part-3: Previous Grade Section"],
        "International Space Olympiad": ["Part-1: Space Science", "Part-2: Space Geography"],
        "International Biology Olympiad": ["Part-1: Biology Reasoning", "Part-2: Real Life Biological Science", "Part-3: Previous Grade Section"],
        "International Physics Olympiad": ["Part-1: Physics Reasoning", "Part-2: Real Life Physical Science", "Part-3: Previous Grade Section"],
        "International Chemistry Olympiad": ["Part-1: Chemistry Reasoning", "Part-2: Real Life Chemical Science", "Part-3: Previous Grade Section"],
        "International Geography Olympiad": ["Part-1: Geography Reasoning", "Part-2: Real Life Geography", "Part-3: Previous Grade Section"],
        "International Commerce Olympiad": ["Part-1: Section – 1", "Part-2: Section – 2", "Part-3: Section – 3"]
    };

    document.getElementById("class").addEventListener("change", function () {
        const selectedClass = parseInt(this.value);
        const subjectSelect = document.getElementById("subject");
        const sectionSelect = document.getElementById("section");

        subjectSelect.innerHTML = '<option value="">Select Subject</option>';
        sectionSelect.innerHTML = '<option value="">Select Section</option>';

        if (subjectsByClass[selectedClass]) {
            subjectsByClass[selectedClass].forEach(subject => {
                const option = document.createElement("option");
                option.value = subject;
                option.textContent = subject;
                subjectSelect.appendChild(option);
            });
        }
    });

    document.getElementById("subject").addEventListener("change", function () {
        const selectedSubject = this.value;
        const sectionSelect = document.getElementById("section");

        sectionSelect.innerHTML = '<option value="">Select Section</option>';

        if (sectionsBySubject[selectedSubject]) {
            sectionsBySubject[selectedSubject].forEach(section => {
                const option = document.createElement("option");
                option.value = section;
                option.textContent = section;
                sectionSelect.appendChild(option);
            });
        }
    });

    function validateForm() {
        let error = '';
        const getVal = id => document.getElementById(id)?.value.trim();
        const getCKVal = id => editors[id]?.getData().trim();

        if (!getVal('class')) error += 'Class is required.<br>';
        if (!getVal('subject')) error += 'Subject is required.<br>';
        if (!getVal('language')) error += 'Language is required.<br>';
        if (!getVal('section')) error += 'Section is required.<br>';
        if (!getCKVal('question')) error += 'Question is required.<br>';
        if (!getCKVal('option_a')) error += 'Option A is required.<br>';
        if (!getCKVal('option_b')) error += 'Option B is required.<br>';
        if (!getCKVal('option_c')) error += 'Option C is required.<br>';
        if (!getCKVal('option_d')) error += 'Option D is required.<br>';
        if (!getVal('correct_answer')) error += 'Correct answer must be selected.<br>';

        const errorBox = document.getElementById("errorBox");
        if (error) {
            errorBox.innerHTML = error;
            errorBox.classList.remove("d-none");
            return false;
        } else {
            errorBox.classList.add("d-none");
            return true;
        }
    }

    const editors = {};
    ['question', 'option_a', 'option_b', 'option_c', 'option_d'].forEach(id => {
        ClassicEditor
            .create(document.querySelector('#' + id))
            .then(editor => {
                editors[id] = editor;
            })
            .catch(error => {
                console.error(error);
            });
    });
</script>

</body>
</html>
