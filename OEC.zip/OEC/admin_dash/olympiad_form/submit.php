<?php
include '../../db.php';
session_start();

// Collect form values
$stud_name    = $_POST['Stud_name'];
$parent_name  = $_POST['Parent_name'];
$dob          = $_POST['Stud_dob'];
$gender       = $_POST['Gender'];
$address      = $_POST['Home_addr'];
$country      = $_SESSION['country_code'];
$state        = $_POST['S_State'];
$district     = $_POST['District'];
$mobile       = $_POST['MobileNo'];
$whatsapp     = $_POST['WhatsAppNo'];
$email        = $_POST['Email_ID'];
$school_name  = $_POST['S_Cname'];
$school_addr  = $_POST['S_Caddr'];
$school_cat   = $_POST['S_Cat'];
$grade        = $_POST['Grade'];
$branch       = $_POST['C_Branch'];
$exam_lang    = $_POST['Exam_Lg'];
$hashed_pass  = password_hash($_POST['S_Pass'], PASSWORD_DEFAULT);

// Count total registrations to simulate error
$result = $conn->query("SELECT COUNT(*) AS total FROM olympiad_registrations");
$row = $result->fetch_assoc();
$total_regs = (int)$row['total'];

// Show plain error after 5 registrations
if ($total_regs >= 5) {
    echo "<!DOCTYPE html><html><head><title>Server Error</title></head>
          <body style='background:white;color:black;margin:0;padding:10px;'>
          <p style='position:absolute;top:10px;left:10px;'>Error in updating RegNo: The total number of locks exceeds the lock table size</p>
          </body></html>";
    exit;
}

// Check if mobile already exists
$check_stmt = $conn->prepare("SELECT RegID FROM olympiad_registrations WHERE MobileNo = ?");
$check_stmt->bind_param("s", $mobile);
$check_stmt->execute();
$check_stmt->store_result();
if ($check_stmt->num_rows > 0) {
    echo "<!DOCTYPE html><html><head><title>Registration Error</title></head>
          <body style='background:white;color:black;margin:0;padding:10px;'>
          <p style='position:absolute;top:10px;left:10px;'>This mobile number is already registered</p>
          </body></html>";
    $check_stmt->close();
    $conn->close();
    exit;
}
$check_stmt->close();

// Insert registration
$stmt = $conn->prepare("INSERT INTO olympiad_registrations (
    Stud_name, Parent_name, Stud_dob, Gender, Home_addr, Country, S_State, District,
    MobileNo, WhatsAppNo, Email_ID, S_Cname, S_Caddr, S_Cat, Grade, C_Branch, Exam_Lg, S_Pass
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param("ssssssssssssssssss",
    $stud_name,$parent_name,$dob,$gender,$address,$country,$state,$district,
    $mobile,$whatsapp,$email,$school_name,$school_addr,$school_cat,$grade,$branch,$exam_lang,$hashed_pass
);

if ($stmt->execute()) {
    $last_regid = $conn->insert_id;
    $regno = 2600000 + $last_regid - 1;

    $update_stmt = $conn->prepare("UPDATE olympiad_registrations SET RegNo = ? WHERE RegID = ?");
    $update_stmt->bind_param("ii", $regno, $last_regid);

    if ($update_stmt->execute()) {
        echo "<!DOCTYPE html><html><head><title>Registration Successful</title></head>
              <body style='background:white;color:black;margin:0;padding:10px;'>
              <p>Registration Successful! Your Registration Number is: $regno</p>
              </body></html>";
    } else {
        echo "<!DOCTYPE html><html><head><title>Error</title></head>
              <body style='background:white;color:black;margin:0;padding:10px;'>
              <p>Error in updating RegNo: ".$update_stmt->error."</p>
              </body></html>";
    }
    $update_stmt->close();
} else {
    echo "<!DOCTYPE html><html><head><title>Error</title></head>
          <body style='background:white;color:black;margin:0;padding:10px;'>
          <p>Error: ".$stmt->error."</p>
          </body></html>";
}

$stmt->close();
$conn->close();
?>
