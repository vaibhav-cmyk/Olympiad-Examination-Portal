-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2025 at 06:48 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test2`
--

-- --------------------------------------------------------

--
-- Table structure for table `olympiad_registrations`
--

CREATE TABLE `olympiad_registrations` (
  `RegID` int(11) NOT NULL,
  `RegNo` int(11) DEFAULT NULL,
  `Stud_name` varchar(255) NOT NULL,
  `Parent_name` varchar(255) NOT NULL,
  `Stud_dob` date NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Home_addr` text NOT NULL,
  `Country` varchar(50) NOT NULL,
  `S_State` varchar(50) NOT NULL,
  `District` varchar(50) NOT NULL,
  `MobileNo` varchar(15) NOT NULL,
  `WhatsAppNo` varchar(15) NOT NULL,
  `Email_ID` varchar(100) NOT NULL,
  `S_Cname` varchar(255) NOT NULL,
  `S_Caddr` text NOT NULL,
  `S_Cat` varchar(50) NOT NULL,
  `Grade` varchar(10) NOT NULL,
  `C_Branch` varchar(50) NOT NULL,
  `Exam_Lg` varchar(50) NOT NULL,
  `S_Pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `olympiad_registrations`
--

INSERT INTO `olympiad_registrations` (`RegID`, `RegNo`, `Stud_name`, `Parent_name`, `Stud_dob`, `Gender`, `Home_addr`, `Country`, `S_State`, `District`, `MobileNo`, `WhatsAppNo`, `Email_ID`, `S_Cname`, `S_Caddr`, `S_Cat`, `Grade`, `C_Branch`, `Exam_Lg`, `S_Pass`) VALUES
(1, 26000, 'roohdn', 'adad', '2025-04-24', '2', 'Spmjkk\r\nSnsn', '+91', 'Karnataka', 'Davanagere', '7841810213', '7841810213', 'test@mail.com', 'asdasdasd', 'Spmjkk\r\nSnsn', '1', '1', '0', '1', '$2y$10$PnycjUZQnm.ATx5.QZ5OzuKDa.DomokD8RTl.kTyZg.ETiJncJIG2'),
(2, 26001, 'jons', 'adad', '2025-04-24', '2', 'Spmjkk\r\nSnsn', '+91', 'Karnataka', 'Bellary', '7841810213', '7841810213', 'test@mail.com', 'asdasdasd', 'Spmjkk\r\nSnsn', '1', '1', '0', '1', '$2y$10$1Nru47trUdiYjiG9PuS8COAelP49AvhLVl7HA6vnbc6tTn46HWiXy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `olympiad_registrations`
--
ALTER TABLE `olympiad_registrations`
  ADD PRIMARY KEY (`RegID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `olympiad_registrations`
--
ALTER TABLE `olympiad_registrations`
  MODIFY `RegID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
