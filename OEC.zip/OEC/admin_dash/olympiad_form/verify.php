
<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['country_code'] = $_POST['country_code'];
    $_SESSION['mobile'] = $_POST['mobile'] ?? null;
    $_SESSION['email'] = $_POST['email'] ?? null;

    // Simulate OTP verification here later.
    header("Location: register.php");
    exit();
}
?>
