<?php
include '../db.php';
$title = $_POST['title'];
$message = $_POST['message'];
$link = !empty($_POST['link']) ? $_POST['link'] : NULL;

$stmt = $conn->prepare("INSERT INTO notifications (title, message, link) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $title, $message, $link);

if ($stmt->execute()) {
    header("Location: notification_view.php?status=success");
    exit;
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
