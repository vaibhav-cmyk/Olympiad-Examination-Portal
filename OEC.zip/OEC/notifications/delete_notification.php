<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$conn = new mysqli("localhost", "olympiad_user_system ", "riteshweb", "olympiad_user_system ");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $id = intval($_POST['id']);
    $stmt = $conn->prepare("DELETE FROM notifications WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: notification_view.php?deleted=success");
    } else {
        echo "Error deleting notification: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
