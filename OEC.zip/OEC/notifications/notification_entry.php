<?php
include '../db.php';


// If form submitted, insert notification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $title = $conn->real_escape_string($_POST['title']);
    $message = $conn->real_escape_string($_POST['message']);
    $link = !empty($_POST['link']) ? $conn->real_escape_string($_POST['link']) : NULL;

    $sql = "INSERT INTO notifications (title, message, link) VALUES ('$title', '$message', " . ($link ? "'$link'" : "NULL") . ")";
    $conn->query($sql);
    header("Location: ".$_SERVER['PHP_SELF']."?added=success");
    exit;
}

// If delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $id = (int)$_POST['id'];
    $conn->query("DELETE FROM notifications WHERE id=$id");
    header("Location: ".$_SERVER['PHP_SELF']."?deleted=success");
    exit;
}

// fetch all notifications
$query = "SELECT * FROM notifications ORDER BY posted_at DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Notifications - OEC</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
body {
  font-family: 'Inter', sans-serif;
  background: linear-gradient(135deg, #f0f4ff, #eaf2ff);
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}
.navbar {
  background-color: #004080;
}
.navbar-brand {
  color: white !important;
  font-weight: 600;
  font-size: 1.6rem;
}
h3 {
  color: #004080;
  font-weight: 700;
  margin-top: 30px;
  margin-bottom: 30px;
}
.card {
  border: 1px solid #cce0ff;
  border-radius: 16px;
  padding: 1.5rem;
  margin-bottom: 25px;
  background-color: #ffffff;
  box-shadow: 0 8px 20px rgba(0, 64, 128, 0.08);
  transition: 0.3s;
}
.card:hover {
  transform: scale(1.01);
  box-shadow: 0 10px 26px rgba(0, 64, 128, 0.15);
}
.card-title {
  color: #004080;
  font-weight: 600;
  font-size: 1.25rem;
}
.card-text {
  color: #333;
  margin-top: 10px;
  font-size: 1rem;
}
.posted-date {
  font-size: 0.9rem;
  color: #555;
}
.link-button {
  margin-top: 10px;
}
.notification-number {
  background-color: #004080;
  color: #fff;
  font-weight: 600;
  border-radius: 50%;
  width: 36px;
  height: 36px;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right: 15px;
  font-size: 1rem;
}
footer {
  background-color: #004080;
  color: white;
  text-align: center;
  padding: 1rem 0;
  margin-top: auto;
  font-size: 0.95rem;
}
.delete-btn { transition: 0.2s ease-in-out; }
.delete-btn:hover { transform: scale(1.05); }
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg" style="background-color: #004080;">
  <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
    <a class="navbar-brand d-flex align-items-center gap-2 text-white" href="#">
      <img src="../images/logo.png" alt="Logo" style="height: 40px; width: auto;">
      <span>OEC Portal</span>
    </a>
    <a href="../master_dash/masterdashboard.php" class="btn btn-light btn-sm">
      <i class="bi bi-arrow-left-circle me-1"></i> Back to Dashboard
    </a>
  </div>
</nav>


<div class="container my-5">

  <h3 class="text-center">📢 Post New Notification</h3>

  <?php if (isset($_GET['added']) && $_GET['added'] === 'success'): ?>
    <div class="alert alert-success text-center">Notification added successfully.</div>
  <?php elseif (isset($_GET['deleted']) && $_GET['deleted'] === 'success'): ?>
    <div class="alert alert-success text-center">Notification deleted successfully.</div>
  <?php endif; ?>

  <!-- Form -->
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card mb-4">
        <form method="post">
          <input type="hidden" name="action" value="add">
          <div class="mb-3">
            <label class="form-label">Title</label>
            <input type="text" name="title" class="form-control" required placeholder="Enter notification title">
          </div>
          <div class="mb-3">
            <label class="form-label">Message</label>
            <textarea name="message" class="form-control" rows="4" required placeholder="Write your message here..."></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Optional Link</label>
            <input type="url" name="link" class="form-control" placeholder="https://example.com">
          </div>
          <div class="d-grid">
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-send me-1"></i> Post Notification
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <h3 class="text-center">🔔 Latest Notifications</h3>

  <!-- Notifications -->
  <?php if ($result->num_rows > 0): ?>
    <?php $count = 1; ?>
    <?php while ($row = $result->fetch_assoc()): ?>
      <div class="card">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <div class="d-flex align-items-center">
            <div class="notification-number"><?= $count ?></div>
            <h5 class="card-title mb-0"><?= htmlspecialchars($row['title']) ?></h5>
          </div>
          <form method="post" onsubmit="return confirm('Are you sure you want to delete this notification?');">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= $row['id'] ?>">
            <button class="btn btn-sm btn-danger delete-btn" title="Delete Notification">
              <i class="bi bi-trash"></i>
            </button>
          </form>
        </div>
        <p class="card-text"><?= nl2br(htmlspecialchars($row['message'])) ?></p>
        <?php if (!empty($row['link'])): ?>
          <a href="<?= htmlspecialchars($row['link']) ?>" target="_blank" class="btn btn-outline-primary btn-sm link-button">
            <i class="bi bi-link-45deg me-1"></i> Open Link
          </a>
        <?php endif; ?>
        <p class="posted-date mt-3">
          <i class="bi bi-clock me-1"></i> <?= date("d M Y, h:i A", strtotime($row['posted_at'])) ?>
        </p>
      </div>
      <?php $count++; ?>
    <?php endwhile; ?>
  <?php else: ?>
    <div class="alert alert-info text-center">No notifications found.</div>
  <?php endif; ?>

</div>

<footer>
  &copy; <?= date("Y"); ?> Olympiad Examination Council | All Rights Reserved
</footer>

</body>
</html>

<?php $conn->close(); ?>
