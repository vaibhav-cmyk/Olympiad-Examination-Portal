<?php
include '../db.php';

$query = "SELECT * FROM notifications ORDER BY posted_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Notifications - OEC</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Bootstrap & Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<style>
/* General Layout */
body {
  font-family: 'Inter', sans-serif;
  margin: 0;
  padding: 0;
  background: #f5f6fa; /* clean light background */
  color: #333;
}

h3 {
  color: #222;
  font-weight: 700;
  margin: 40px 0 30px;
  text-align: center;
  font-size: 2rem;
}

/* Cards */
@keyframes fadeInUp {
  0% { opacity: 0; transform: translateY(20px); }
  100% { opacity: 1; transform: translateY(0); }
}

.card {
  border: 1px solid #e0e0e0;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 25px;
  background: #fff;
  color: #333;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  opacity: 0;
  animation: fadeInUp 0.5s forwards;
}

.card:hover {
  transform: translateY(-3px);
  box-shadow: 0 6px 16px rgba(0,0,0,0.1);
}

.card-title {
  color: #111;
  font-weight: 600;
  font-size: 1.2rem;
}

.card-text {
  color: #444;
  margin-top: 10px;
  font-size: 1rem;
  line-height: 1.6;
}

/* Notification Number */
.notification-number {
  font-size: 0.9rem;
  font-weight: 600;
  color: #fff;
  background: #007bff; /* blue */
  border-radius: 50%;
  width: 34px;
  height: 34px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 12px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

/* Link Button */
.link-button {
  margin-top: 15px;
  background: #007bff;
  border: none;
  padding: 10px 20px;
  font-weight: 600;
  border-radius: 8px;
  transition: all 0.2s ease;
  color: white;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}

.link-button:hover {
  background: #0056b3;
  box-shadow: 0 4px 10px rgba(0,0,0,0.15);
}

/* Date */
.posted-date {
  font-size: 0.85rem;
  color: #666;
}

/* Alert */
.alert-info {
  background-color: #eaf4ff;
  color: #004085;
  border: 1px solid #b8daff;
}

/* Container */
.container {
  max-width: 850px;
}

/* Responsive */
@media (max-width: 576px) {
  h3 {
    font-size: 1.5rem;
  }
  .card {
    padding: 1.2rem;
  }
  .link-button {
    width: 100%;
    justify-content: center;
  }
}
</style>
</head>
<body>

<?php include 'header.html'; ?>

<!-- Notifications -->
<div class="container my-5">
  <h3>🔔 Latest Notifications</h3>

  <?php if ($result->num_rows > 0): ?>
    <?php $count = 1; ?>
    <?php while ($row = $result->fetch_assoc()): ?>
      <div class="card">
        <div class="d-flex align-items-center mb-2">
          <div class="notification-number"><?= $count ?></div>
          <h5 class="card-title mb-0"><?= htmlspecialchars($row['title']) ?></h5>
        </div>
        <p class="card-text"><?= nl2br(htmlspecialchars($row['message'])) ?></p>
        <?php if (!empty($row['link'])): ?>
          <a href="<?= htmlspecialchars($row['link']) ?>" target="_blank" class="link-button">
            <i class="bi bi-link-45deg"></i> Open Link
          </a>
        <?php endif; ?>
        <p class="posted-date mt-3"><i class="bi bi-clock me-1"></i> <?= date("d M Y, h:i A", strtotime($row['posted_at'])) ?></p>
      </div>
      <?php $count++; ?>
    <?php endwhile; ?>
  <?php else: ?>
    <div class="alert alert-info text-center">No notifications found.</div>
  <?php endif; ?>
</div>

<?php include 'footer.html'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Disable Right-Click + Basic Inspect Prevention -->
<script>
  document.addEventListener('contextmenu', event => event.preventDefault());
  document.onkeydown = function(e) {
    if (e.keyCode == 123 || // F12
        (e.ctrlKey && e.shiftKey && (e.keyCode == 73 || e.keyCode == 74)) || // Ctrl+Shift+I/J
        (e.ctrlKey && e.keyCode == 85)) { // Ctrl+U
        return false;
    }
  };
</script>

</body>
</html>

<?php $conn->close(); ?>
