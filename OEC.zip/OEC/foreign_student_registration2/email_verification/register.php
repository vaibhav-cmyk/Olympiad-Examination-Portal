<?php
session_start();

// Redirect if the user hasn't come from the initial verification step.
// This page is for non-Indian students, so we check that the code is NOT '+91'.
if (!isset($_SESSION['country_code']) || $_SESSION['country_code'] === '+91') {
    header("Location: index.php");
    exit();
}

// Retrieve email and the full country name from the session.
$email = $_SESSION['email'] ?? '';
$country = $_SESSION['country_name'] ?? '';

$success = false;
$new_student_id = '';
$db_error = null;

// Database connection details
$host = 'localhost';
$db = 'olympiad_user_system';
$user = 'olympiad_user_system';
$pass = 'riteshweb';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

$pdo = null;
try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    // We'll display this error in the HTML body for visibility
    $db_error = "Connection failed: " . $e->getMessage();
}

if ($pdo && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Generate a new unique Student_ID for international students
        $stmt = $pdo->query("SELECT Student_ID FROM olympiad_registration 
                                WHERE Student_ID LIKE 'INT26%' 
                                ORDER BY CAST(SUBSTRING(Student_ID, 6) AS UNSIGNED) DESC LIMIT 1");
        $last_id = $stmt->fetchColumn();

        $new_number = $last_id ? ((int)substr($last_id, 5) + 1) : 1;
        $new_student_id = 'INT26' . str_pad($new_number, 5, '0', STR_PAD_LEFT);

        // Prepare the SQL statement for insertion
        $sql = "INSERT INTO olympiad_registration (
                    Student_ID, Stud_name, Parent_name, Stud_dob, Gender, Home_addr, 
                    MobileNo, WhatsAppNo, Country, Email_ID, S_Cname, S_Caddr, 
                    Grade, C_Branch, Exam_Lg, S_Pass
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);

        // Hash the password for security
        $hashed_password = password_hash($_POST['S_Pass'], PASSWORD_DEFAULT);

        // Execute the insertion
        $stmt->execute([
            $new_student_id,
            $_POST['Stud_name'],
            $_POST['Parent_name'],
            $_POST['Stud_dob'],
            $_POST['Gender'],
            $_POST['Home_addr'],
            $_POST['MobileNo'],
            $_POST['WhatsAppNo'],
            $country, // Use country from session
            $email,   // Use email from session
            $_POST['S_Cname'],
            $_POST['S_Caddr'],
            $_POST['Grade'],
            $_POST['C_Branch'],
            $_POST['Exam_Lg'],
            $hashed_password
        ]);

        $success = true;

    } catch (PDOException $e) {
        $db_error = "Registration failed: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>International Student Registration - Olympiad Examination Council</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons for visual cues -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        /* Custom styles for a polished, modern look */
        body {
            background-color: #eef2f7;
            font-family: 'Inter', sans-serif;
        }
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap');

        .form-container {
            background: white;
            padding: 2rem 3rem;
            border-radius: 1rem;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
            margin-top: 2rem;
            margin-bottom: 2rem;
        }

        .progress-bar-container {
            display: flex;
            justify-content: space-between;
            counter-reset: step;
            margin-bottom: 3rem;
        }
        .progress-bar-container .step {
            width: 100%;
            text-align: center;
            position: relative;
        }
        .progress-bar-container .step::before {
            content: counter(step);
            counter-increment: step;
            width: 30px;
            height: 30px;
            line-height: 30px;
            border: 2px solid #e0e0e0;
            display: block;
            text-align: center;
            margin: 0 auto 10px auto;
            border-radius: 50%;
            background-color: white;
            transition: all 0.3s ease;
        }
        .progress-bar-container .step::after {
            content: '';
            width: 100%;
            height: 2px;
            background-color: #e0e0e0;
            position: absolute;
            left: -50%;
            top: 14px;
            z-index: -1;
            transition: all 0.3s ease;
        }
        .progress-bar-container .step:first-child::after { content: none; }
        .progress-bar-container .step.active::before {
            border-color: #0d6efd;
            background-color: #0d6efd;
            color: white;
        }
        .progress-bar-container .step.active + .step::after { background-color: #0d6efd; }
        .step-label { font-size: 0.85rem; color: #6c757d; }
        .step.active .step-label { color: #0d6efd; font-weight: 500; }

        .form-step { display: none; animation: fadeIn 0.5s; }
        .form-step.active { display: block; }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .form-control:disabled, .form-select:disabled { background-color: #e9ecef; opacity: 1; }
        .form-control[readonly] { background-color: #e9ecef; }

        /* Responsive adjustments for mobile */
        @media (max-width: 576px) {
            .step-label {
                font-size: 0.75rem; /* Smaller font for labels on mobile */
            }
            .form-container {
                padding: 2rem 1.5rem; /* Reduce horizontal padding on mobile */
            }
            .progress-bar-container .step::before {
                width: 25px; /* Smaller progress circles */
                height: 25px;
                line-height: 25px;
            }
            .progress-bar-container .step::after {
                top: 12px; /* Adjust line position to match smaller circles */
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-xl-9">
                <div class="form-container">
                    <div class="text-center mb-5">
                        <img src="https://olympiadexamination.org/img/oecfavicon.png" alt="OEC Logo" style="width: 64px; height: 64px;" class="mx-auto mb-3">
                        <h1 class="h3 fw-bold">International Student Registration</h1>
                        <p class="text-muted">Follow the steps to complete your registration.</p>
                    </div>

                    <?php if (isset($db_error) && $db_error): ?>
                        <div class="alert alert-danger"><?php echo $db_error; ?></div>
                    <?php elseif ($success): ?>
                        <div class="text-center">
                            <i class="bi bi-check-circle-fill text-success" style="font-size: 4rem;"></i>
                            <h3 class="mt-3">Registration Successful!</h3>
                            <p class="lead">Thank you for submitting your school affiliation request.<br> 
                            We have received your application and will review it.<br>
                            We'll contact you within a week regarding a potential partnership.<br>
                            Your Student ID is:</p>
                            <p class="h4 bg-light py-2 px-3 d-inline-block rounded"><?php echo htmlspecialchars($new_student_id); ?></p>
                            <p class="mt-3">Please save this ID for future reference.</p>
                            <div class="mt-4">
                                <a href="../../student/registration/index.php" class="btn btn-secondary me-2"><i class="bi bi-house-door"></i> Go to Home</a>
                                <a href="../../student/login.php" class="btn btn-primary"><i class="bi bi-box-arrow-in-right"></i> Login Now</a>
                            </div>
                        </div>
                    <?php else: ?>
                    <!-- Progress Bar -->
                    <div class="progress-bar-container">
                        <div class="step active"><div class="step-label">Personal</div></div>
                        <div class="step"><div class="step-label">Contact</div></div>
                        <div class="step"><div class="step-label">Academic</div></div>
                        <div class="step"><div class="step-label">Password</div></div>
                    </div>

                    <form id="registrationForm" action="" method="post" novalidate>
                        <!-- Step 1: Personal Information -->
                        <div class="form-step active">
                            <h5 class="mb-4 text-center">Personal Information</h5>
                            <div class="row g-3">
                                <div class="col-md-6"><label for="Stud_name" class="form-label">Student Name</label><input type="text" class="form-control" name="Stud_name" required><div class="invalid-feedback">Please enter the student's name.</div></div>
                                <div class="col-md-6"><label for="Parent_name" class="form-label">Parent Name</label><input type="text" class="form-control" name="Parent_name" required><div class="invalid-feedback">Please enter the parent's name.</div></div>
                                <div class="col-md-6"><label for="Stud_dob" class="form-label">Date of Birth</label><input type="date" class="form-control" name="Stud_dob" required><div class="invalid-feedback">Please select a valid date of birth.</div></div>
                                <div class="col-md-6"><label for="Gender" class="form-label">Gender</label><select class="form-select" name="Gender" required><option value="" disabled selected>Select Gender</option><option value="Male">Male</option><option value="Female">Female</option><option value="Other">Other</option></select><div class="invalid-feedback">Please select a gender.</div></div>
                            </div>
                        </div>

                        <!-- Step 2: Contact Information -->
                        <div class="form-step">
                            <h5 class="mb-4 text-center">Contact Information</h5>
                            <div class="row g-3">
                                <div class="col-12"><label for="Home_addr" class="form-label">Home Address</label><textarea class="form-control" name="Home_addr" rows="2" required></textarea><div class="invalid-feedback">Please enter your address.</div></div>
                                <div class="col-md-6"><label for="MobileNo" class="form-label">Mobile Number</label><input type="tel" class="form-control" id="MobileNo" name="MobileNo" required><div class="invalid-feedback">Please enter a valid mobile number.</div></div>
                                <div class="col-md-6"><label for="WhatsAppNo" class="form-label">WhatsApp Number</label><input type="tel" class="form-control" id="WhatsAppNo" name="WhatsAppNo" required><div class="form-text mt-1"><input class="form-check-input me-1" type="checkbox" id="sameAsMobile"><label class="form-check-label" for="sameAsMobile">Same as Mobile</label></div><div class="invalid-feedback">Please enter a valid WhatsApp number.</div></div>
                                <div class="col-md-6"><label for="Country" class="form-label">Country</label><input type="text" class="form-control" name="Country" value="<?php echo htmlspecialchars($country); ?>" readonly></div>
                                <div class="col-md-6"><label for="Email_ID" class="form-label">Email</label><input type="email" class="form-control" name="Email_ID" value="<?php echo htmlspecialchars($email); ?>" readonly></div>
                            </div>
                        </div>

                        <!-- Step 3: Academic Information -->
                        <div class="form-step">
                             <h5 class="mb-4 text-center">Academic Information</h5>
                             <div class="row g-3">
                                 <div class="col-12"><label for="S_Cname" class="form-label">School/College Name</label><input type="text" class="form-control" name="S_Cname" required><div class="invalid-feedback">Please enter the school/college name.</div></div>
                                 <div class="col-12"><label for="S_Caddr" class="form-label">School/College Address</label><textarea class="form-control" name="S_Caddr" rows="2" required></textarea><div class="invalid-feedback">Please enter the school/college address.</div></div>
                                 <div class="col-md-6"><label for="Grade" class="form-label">Grade</label><select class="form-select" id="GradeSelect" name="Grade" required><option value="" disabled selected>Select Grade</option><?php for ($i = 1; $i <= 12; $i++): ?><option value="<?php echo $i; ?>">Grade <?php echo $i; ?></option><?php endfor; ?></select><div class="invalid-feedback">Please select a grade.</div></div>
                                 <div class="col-md-6"><label for="C_Branch" class="form-label">Branch/Major (for Grade 11/12)</label><input type="text" class="form-control" id="C_Branch" name="C_Branch"><div class="invalid-feedback">Please enter a branch/major.</div></div>
                                 <div class="col-12"><label for="Exam_Lg" class="form-label">Preferred Exam Language</label><select class="form-select" name="Exam_Lg" required><option value="" disabled selected>Select Language</option><option value="English">English</option><option value="Spanish">Spanish</option><option value="French">French</option></select><div class="invalid-feedback">Please select a language.</div></div>
                             </div>
                        </div>

                        <!-- Step 4: Set Password -->
                        <div class="form-step">
                            <h5 class="mb-4 text-center">Set Your Password</h5>
                            <div class="row g-3 justify-content-center">
                                <div class="col-md-8"><label for="S_Pass" class="form-label">Password</label><input type="password" class="form-control" id="S_Pass" name="S_Pass" required><div class="invalid-feedback">Please enter a password.</div></div>
                                <div class="col-md-8"><label for="S_ConfirmPass" class="form-label">Confirm Password</label><input type="password" class="form-control" id="S_ConfirmPass" required><div class="invalid-feedback">Passwords do not match.</div></div>
                            </div>
                        </div>

                        <!-- Navigation Buttons -->
                        <div class="d-flex justify-content-between mt-5 gap-3">
                            <button type="button" class="btn btn-secondary" id="prevBtn" style="display: none;"><i class="bi bi-arrow-left"></i> Previous</button>
                            <button type="button" class="btn btn-primary" id="nextBtn">Next <i class="bi bi-arrow-right"></i></button>
                            <button type="submit" class="btn btn-success" id="submitBtn" style="display: none;"><i class="bi bi-check-lg"></i> Submit Registration</button>
                        </div>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Do not run script if the form is not on the page (i.e., on success)
            const form = document.getElementById('registrationForm');
            if (!form) return;

            const steps = Array.from(document.querySelectorAll('.form-step'));
            const progressSteps = Array.from(document.querySelectorAll('.progress-bar-container .step'));
            const nextBtn = document.getElementById('nextBtn');
            const prevBtn = document.getElementById('prevBtn');
            const submitBtn = document.getElementById('submitBtn');
            let currentStep = 0;

            nextBtn.addEventListener('click', () => {
                if (validateStep(currentStep)) {
                    if (currentStep < steps.length - 1) {
                        currentStep++;
                        updateFormSteps();
                    }
                }
            });

            prevBtn.addEventListener('click', () => {
                if (currentStep > 0) {
                    currentStep--;
                    updateFormSteps();
                }
            });

            function updateFormSteps() {
                steps.forEach((step, index) => step.classList.toggle('active', index === currentStep));
                progressSteps.forEach((step, index) => step.classList.toggle('active', index <= currentStep));
                prevBtn.style.display = currentStep > 0 ? 'inline-block' : 'none';
                nextBtn.style.display = currentStep < steps.length - 1 ? 'inline-block' : 'none';
                submitBtn.style.display = currentStep === steps.length - 1 ? 'inline-block' : 'none';
            }

            function validateStep(stepIndex) {
                let isValid = true;
                const currentStepElement = steps[stepIndex];
                currentStepElement.querySelectorAll('input, select, textarea').forEach(input => {
                    input.classList.remove('is-invalid'); // Reset validation state
                    if (input.hasAttribute('required') && !input.disabled) {
                        if (!input.checkValidity()) {
                            input.classList.add('is-invalid');
                            isValid = false;
                        }
                    }
                });
                
                if (stepIndex === steps.length - 1) {
                    const passInput = document.getElementById('S_Pass');
                    const confirmPassInput = document.getElementById('S_ConfirmPass');
                    if (passInput.value !== confirmPassInput.value || passInput.value === '') {
                        confirmPassInput.classList.add('is-invalid');
                        isValid = false;
                    }
                }
                return isValid;
            }

            form.addEventListener('submit', function(e) {
                if (!validateStep(currentStep)) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                manageBranchSelectOnSubmit();
            });

            // --- Specific Field Logic ---
            const sameAsMobileCheck = document.getElementById('sameAsMobile');
            if(sameAsMobileCheck) {
                sameAsMobileCheck.addEventListener('change', function () {
                    const mobileInput = document.getElementById('MobileNo');
                    const whatsappInput = document.getElementById('WhatsAppNo');
                    whatsappInput.value = this.checked ? mobileInput.value : '';
                });
            }

            const gradeSelect = document.getElementById('GradeSelect');
            if(gradeSelect) {
                gradeSelect.addEventListener('change', manageBranchSelect);
                manageBranchSelect(); // Initial check
            }

            function manageBranchSelect() {
                const branchInput = document.getElementById('C_Branch');
                const selectedGrade = parseInt(gradeSelect.value);
                const isHighSchool = selectedGrade === 11 || selectedGrade === 12;
                branchInput.disabled = !isHighSchool;
                branchInput.required = isHighSchool;
                if (!isHighSchool) branchInput.value = '';
            }
            
            function manageBranchSelectOnSubmit() {
                const branchInput = document.getElementById('C_Branch');
                if (branchInput.disabled) {
                    branchInput.disabled = false; // Temporarily enable to submit value
                    branchInput.value = 'Not Applicable'; // Set default for lower grades
                }
            }
        });
    </script>

</body>
</html>
