<?php
// Include the database connection file
require_once '../db.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_staff'])) {
    // Sanitize form data to prevent XSS attacks
    $full_name = htmlspecialchars(trim($_POST['full_name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $phone = htmlspecialchars(trim($_POST['phone']));
    $position = htmlspecialchars(trim($_POST['position']));
    $department = htmlspecialchars(trim($_POST['department']));
    $username = htmlspecialchars(trim($_POST['username']));
    
    // Hash the password for secure storage
    $password_hash = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Prepare SQL statement with a prepared statement
    $stmt = $conn->prepare("INSERT INTO staff (full_name, email, phone, position, department, username, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
    
    // Bind parameters to the statement
    $stmt->bind_param("sssssss", $full_name, $email, $phone, $position, $department, $username, $password_hash);

    // Execute the statement
    if ($stmt->execute()) {
        $message = "✅ Staff member added successfully.";
    } else {
        $message = "❌ Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection at the end of the script
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Staff</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f4f8;
            padding: 20px;
        }

        h2 {
            color: #004080;
        }

        form {
            background: #fff;
            padding: 20px;
            width: 400px;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }

        input, button {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
        }

        button {
            background-color: #004080;
            color: white;
            border: none;
            cursor: pointer;
        }

        .message {
            margin-top: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Add New Staff Member</h2>

<?php if ($message): ?>
    <div class="message"><?php echo $message; ?></div>
<?php endif; ?>

<form method="POST" action="">
    <input type="text" name="full_name" placeholder="Full Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="text" name="phone" placeholder="Phone">
    <input type="text" name="position" placeholder="Position">
    <input type="text" name="department" placeholder="Department">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit" name="add_staff">Add Staff</button>
</form>

</body>
</html>