<?php 
require_once 'db.php';
require_once 'auth_master.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Register | OEC</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<style>
body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #74ebd5, #ACB6E5);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

.navbar {
    background-color: #004080;
}

.navbar-brand {
    font-weight: 600;
    color: #fff !important;
    text-align: center;
    font-size: clamp(1rem, 3vw, 1.4rem);
    flex-wrap: wrap;
}

.navbar-brand img {
    height: 50px;
    width: auto;
}

.footer {
    background-color: #004080;
    color: #fff;
    text-align: center;
    padding: 0.75rem 0;
    margin-top: auto;
    font-size: 0.9rem;
}

.card {
    padding: 2rem;
    border-radius: 16px;
    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.2);
    animation: fadeInUp 0.8s ease-in-out;
    background-color: #fff;
}

@keyframes fadeInUp {
    0% { transform: translateY(30px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
}

.form-title {
    font-weight: 600;
    font-size: 1.8rem;
    color: #004080;
    margin-bottom: 20px;
    text-align: center;
}

.form-control:focus {
    border-color: #00bcd4;
    box-shadow: 0 0 0 0.2rem rgba(0, 188, 212, 0.25);
}

.btn-primary {
    background: linear-gradient(45deg, #004080, #0066cc);
    border: none;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    background: linear-gradient(45deg, #002f5f, #0055aa);
}

.alert {
    animation: fadeIn 0.5s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: scale(0.95); }
    to { opacity: 1; transform: scale(1); }
}

#loader {
    display: none;
    text-align: center;
    margin-top: 10px;
}
</style>
</head>

<body>

<!-- Header -->
<nav class="navbar shadow">
  <div class="container">
    <a class="navbar-brand mx-auto d-flex flex-column align-items-center gap-1" href="#">
      <img src="images/logo.png" alt="Logo">
      <span>Olympiad Examination Council</span>
    </a>
  </div>
</nav>

<main class="flex-grow-1 d-flex align-items-center justify-content-center py-4">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-11 col-sm-9 col-md-7 col-lg-5">
            <div class="card">
                <h3 class="form-title">✨ Create Your Account</h3>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $address = trim($_POST['address']);
    $contact = trim($_POST['contact']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    $errors = [];

    if (empty($name) || empty($address) || empty($contact) || empty($email) || empty($password) || empty($confirm_password)) {
        $errors[] = "All fields are required.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (!preg_match('/^[0-9]{10}$/', $contact)) {
        $errors[] = "Contact number must be 10 digits.";
    }

    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }

    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters.";
    }

    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $errors[] = "Email already registered.";
    }
    $stmt->close();

    if (count($errors) > 0) {
        echo '<div class="alert alert-danger"><ul>';
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo '</ul></div>';
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (name, address, contact, email, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $name, $address, $contact, $email, $hashed_password);

        if ($stmt->execute()) {
            echo '<div class="alert alert-success">✅ Registered successfully!</div>';
        } else {
            echo '<div class="alert alert-danger">❌ Something went wrong. Please try again.</div>';
        }

        $stmt->close();
    }

    $conn->close();
}
?>

<form method="post" action="" onsubmit="return validateForm();">
    <div class="mb-3">
        <label for="name" class="form-label">👤 Name</label>
        <input type="text" class="form-control" id="name" name="name" required>
    </div>

    <div class="mb-3">
        <label for="address" class="form-label">🏠 Address</label>
        <textarea class="form-control" id="address" name="address" rows="2" required></textarea>
    </div>

    <div class="mb-3">
        <label for="contact" class="form-label">📞 Contact No.</label>
        <input type="text" class="form-control" id="contact" name="contact" required pattern="[0-9]{10}">
    </div>

    <div class="mb-3">
        <label for="email" class="form-label">📧 Email</label>
        <input type="email" class="form-control" id="email" name="email" required>
    </div>

    <div class="mb-3">
        <label for="password" class="form-label">🔑 Password</label>
        <input type="password" class="form-control" id="password" name="password" required minlength="6">
    </div>

    <div class="mb-3">
        <label for="confirm_password" class="form-label">🔐 Confirm Password</label>
        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required minlength="6">
        <div id="passwordMatchMessage" class="form-text text-danger d-none">Passwords do not match.</div>
    </div>

    <button type="submit" class="btn btn-primary w-100 mt-3">Register</button>
    <div id="loader">
        <div class="spinner-border text-info mt-2" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
</form>

            </div>
        </div>
    </div>
</div>
</main>

<footer class="footer">
  &copy; <?= date("Y") ?> Olympiad Examination Council. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
const password = document.getElementById("password");
const confirmPassword = document.getElementById("confirm_password");
const message = document.getElementById("passwordMatchMessage");

confirmPassword.addEventListener("input", () => {
    if (password.value !== confirmPassword.value) {
        message.classList.remove("d-none");
    } else {
        message.classList.add("d-none");
    }
});

function validateForm() {
    if (password.value !== confirmPassword.value) {
        alert("❌ Passwords do not match.");
        return false;
    }
    document.getElementById("loader").style.display = "block";
    return true;
}
</script>

</body>
</html>
