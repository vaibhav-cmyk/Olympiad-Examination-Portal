<?php
require_once '../db.php';
require_once 'auth_master.php'; 

$studentId = $_POST['student_id'];
$exam      = $_POST['exam'];
$status    = $_POST['status'];
$date      = date('Y-m-d');

// Map exams to amounts (same as Indian mapping)
$examAmounts = [
    "International Mathematics Olympiad" => 15,
    "International English Olympiad"     => 15,
    "International Science Olympiad"     => 15,
    "International Space Olympiad"       => 15,
    "International Physics Olympiad"     => 15,
    "International Chemistry Olympiad"   => 15,
    "International Biology Olympiad"     => 15,
    "International Commerce Olympiad"    => 15,
    "International Geography Olympiad"   => 15,
    "International Economics Olympiad"   => 15
];

$amount = $examAmounts[$exam] ?? 0;

// Check if payment record already exists
$check = $conn->prepare("SELECT * FROM foreign_payment_transactions WHERE Student_ID = ? AND Exam = ?");
$check->bind_param("ss", $studentId, $exam);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    // 🔹 Update existing record
    $stmt = $conn->prepare("UPDATE foreign_payment_transactions 
                            SET AccountStatus = ? 
                            WHERE Student_ID = ? AND Exam = ?");
    $stmt->bind_param("sss", $status, $studentId, $exam);
} else {
    // 🔹 Insert new record with defaults
    $stmt = $conn->prepare("INSERT INTO foreign_payment_transactions
        (Student_ID, Exam, Amount, PaymentStatus, PaymentMode, PaymentDate, AccountStatus)
        VALUES (?, ?, ?, 'Success', 'Offline', ?, ?)");
    $stmt->bind_param("ssiss", $studentId, $exam, $amount, $date, $status);
}

if ($stmt->execute()) {
    header("Location: foreign_students.php");
    exit;
} else {
    echo "Error: " . $conn->error;
}
?>
