<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View School Registration</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<style>
body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #dbe9f4, #f0f4f8);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

.navbar {
    background: linear-gradient(90deg, #004080, #0073e6);
}

.navbar-brand {
    font-weight: 600;
    font-size: 1.5rem;
    color: #fff !important;
}

.logo {
    height: 40px;
    margin-right: 10px;
}

.container {
    flex: 1;
}

h2 {
    color: #004080;
    font-weight: 600;
}

.card-hover {
    transition: transform 0.3s, box-shadow 0.3s;
    border-radius: 15px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.card-hover:hover {
    transform: translateY(-8px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
}

.btn-primary {
    background: linear-gradient(90deg, #004080, #0073e6);
    border: none;
    font-weight: 500;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    background: linear-gradient(90deg, #003060, #005bb5);
    transform: translateY(-2px) scale(1.02);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.btn-success {
    background: linear-gradient(90deg, #006633, #00aa66);
    border: none;
    font-weight: 500;
    transition: all 0.3s ease;
}

.btn-success:hover {
    background: linear-gradient(90deg, #004d26, #008855);
    transform: translateY(-2px) scale(1.02);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

footer {
    background: linear-gradient(90deg, #004080, #0073e6);
    color: #fff;
    text-align: center;
    padding: 1rem 0;
    margin-top: auto;
    font-size: 0.95rem;
    position: relative;
    overflow: hidden;
}

footer::after {
    content: "";
    position: absolute;
    top: 0;
    left: -150%;
    height: 100%;
    width: 50%;
    background: linear-gradient(120deg, transparent, rgba(255,255,255,0.4), transparent);
    animation: shine 3s infinite;
}

@keyframes shine {
    0% { left: -150%; }
    50% { left: 150%; }
    100% { left: 150%; }
}

.back-btn {
    background: #fff;
    color: #004080;
    font-weight: 500;
    border-radius: 20px;
    padding: 0.3rem 1rem;
    transition: all 0.3s ease;
    font-size: 0.9rem;
}

.back-btn:hover {
    background: #e6f0ff;
    color: #00264d;
    transform: scale(1.05);
}

@media (max-width: 576px) {
    .back-btn {
        font-size: 0.8rem;
        padding: 0.2rem 0.7rem;
    }
}

</style>
</head>
<body>

<!-- Header -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="#">
      <img src="../../images/logo.png" alt="Logo" class="logo">
      <span>OEC </span>
    </a>
    <div class="ms-auto me-2">
      <a href="../masterdashboard.php" class="back-btn text-decoration-none">
        <i class="bi bi-arrow-left-circle"></i> Back
      </a>
    </div>
  </div>
</nav>


<!-- Main Content -->
<div class="container my-5">
  <h2 class="text-center mb-4">View School Registrations</h2>
  <div class="row justify-content-center gap-4">
    <div class="col-md-4">
      <div class="card card-hover text-center">
        <div class="card-body">
          <i class="bi bi-building fs-1 text-primary"></i>
          <h5 class="card-title mt-3">View Indian Schools</h5>
          <p class="card-text">See all registered Indian schools here.</p>
          <a href="view_indian_schools.php" class="btn btn-primary">View Indian Schools</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card card-hover text-center">
        <div class="card-body">
          <i class="bi bi-globe fs-1 text-success"></i>
          <h5 class="card-title mt-3">View International Schools</h5>
          <p class="card-text">See all registered International schools here.</p>
          <a href="view_international_schools.php" class="btn btn-success">View International Schools</a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Footer -->
<footer>
  &copy; <?= date('Y') ?> OEC School Registration. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
