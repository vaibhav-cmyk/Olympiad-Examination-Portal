<?php
session_start();

// Set cache control headers to prevent caching of this sensitive page
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
header("Pragma: no-cache"); // HTTP 1.0
header("Expires: 0"); // Proxies (e.g., set to a past date)

// Check if the master user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../masterlogin.php'); // Redirect to master login if not logged in
    exit();
}
?>

<?php
// session_start();
// Include the database connection file.
// Make sure you have a 'db.php' file with your MySQL connection details.
include '../../db.php';

// Check for and display any session messages (success or error)
$message = '';
$message_class = '';
if (isset($_SESSION['success_message'])) {
    $message = htmlspecialchars($_SESSION['success_message']);
    $message_class = 'alert-success';
    unset($_SESSION['success_message']);
} elseif (isset($_SESSION['error_message'])) {
    $message = htmlspecialchars($_SESSION['error_message']);
    $message_class = 'alert-danger';
    unset($_SESSION['error_message']);
}

// --- PHP Logic to Handle Form Submission ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Collect all form data. Use the null coalescing operator for safety.
    $school_name = $_POST['school_name'] ?? '';
    $country = $_POST['country'] ?? '';
    $address = $_POST['address'] ?? '';
    $state = $_POST['state'] ?? '';
    $city = $_POST['city'] ?? '';
    $zip = $_POST['zip'] ?? '';
    $contact_number = $_POST['contact_number'] ?? '';
    $email = $_POST['email'] ?? '';
    $website = $_POST['website'] ?? '-'; // Set default to '-' if not provided
    $school_type = $_POST['school_type'] ?? '';
    $school_level = $_POST['school_level'] ?? '';
    $accreditation = $_POST['accreditation'] ?? '';
    $grade_from = intval($_POST['grade_from'] ?? 0);
    $grade_to = intval($_POST['grade_to'] ?? 0);
    $total_students = intval($_POST['total_students'] ?? 0);
    $total_teachers = intval($_POST['total_teachers'] ?? 0);
    $principal_name = $_POST['principal_name'] ?? '';
    $principal_mobile = $_POST['principal_mobile'] ?? '';
    $principal_email = $_POST['principal_email'] ?? '';
    $teacher_name = $_POST['teacher_name'] ?? '';
    $teacher_mobile = $_POST['teacher_mobile'] ?? '';
    $teacher_email = $_POST['teacher_email'] ?? '';
    $password_input = $_POST['password'] ?? '';
    $confirm_password_input = $_POST['confirm_password'] ?? '';

    // --- Server-side Validation ---
    if ($password_input !== $confirm_password_input) {
        $_SESSION['error_message'] = "Passwords do not match.";
        header("Location: international_registration.php");
        exit;
    }
    
    // Check for empty password
    if (empty($password_input)) {
        $_SESSION['error_message'] = "Password cannot be empty.";
        header("Location: international_registration.php");
        exit;
    }

    // Hash the password for secure storage
    $password_hash = password_hash($password_input, PASSWORD_DEFAULT);

    // --- Generate Unique School ID (e.g., OECIN250001) ---
    $prefix = "OECIN25";
    $sql_last_id = "SELECT school_id FROM international_schools WHERE school_id LIKE '$prefix%' ORDER BY school_id DESC LIMIT 1";
    $result = $conn->query($sql_last_id);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $last_id_num = intval(substr($row['school_id'], strlen($prefix))); 
        $new_id_num = $last_id_num + 1;
    } else {
        $new_id_num = 1;
    }

    $school_id = $prefix . str_pad($new_id_num, 4, "0", STR_PAD_LEFT);

    // --- Insert Data into the Database using a Prepared Statement ---
    $sql = "INSERT INTO international_schools 
    (school_id, school_name, country, address, state, city, zip, contact_number, email, website, school_type, school_level, accreditation, grade_from, grade_to, total_students, total_teachers, principal_name, principal_mobile, principal_email, teacher_name, teacher_mobile, teacher_email, password_hash) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        $_SESSION['error_message'] = "Database error (prepare): " . htmlspecialchars($conn->error);
        header("Location: international_registration.php");
        exit;
    }
        
    $stmt->bind_param("sssssssssssssiiiisssssss",
        $school_id, $school_name, $country, $address, $state, $city, $zip,
        $contact_number, $email, $website, $school_type, $school_level, $accreditation,
        $grade_from, $grade_to, $total_students, $total_teachers, $principal_name,
        $principal_mobile, $principal_email, $teacher_name, $teacher_mobile, $teacher_email,
        $password_hash
    );

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "✅ Registration successful! Your School ID is: " . htmlspecialchars($school_id);
        header("Location: international_registration.php");
        exit();
    } else {
        $_SESSION['error_message'] = "❌ Error registering school. Please try again. " . htmlspecialchars($stmt->error);
        header("Location: international_registration.php");
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>International School Registration</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<style>
body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #dbe9f4, #f0f4f8);
    min-height: 100vh;
    margin: 0;
    overflow-x: hidden;
    display: flex;
    flex-direction: column;
}

.navbar {
    background: linear-gradient(90deg, #004080, #0073e6);
}

.navbar-brand {
    font-weight: 600;
    color: #fff !important;
}

.footer {
    background: linear-gradient(90deg, #004080, #0073e6);
    color: #fff;
    text-align: center;
    padding: 1rem 0;
    margin-top: auto;
    font-size: 0.95rem;
    position: relative;
    overflow: hidden;
}

.footer::after {
    content: "";
    position: absolute;
    top: 0;
    left: -150%;
    height: 100%;
    width: 50%;
    background: linear-gradient(120deg, transparent, rgba(255,255,255,0.4), transparent);
    animation: shine 3s infinite;
}

@keyframes shine {
    0% { left: -150%; }
    50% { left: 150%; }
    100% { left: 150%; }
}

.registration-container {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1rem;
}

.registration-card {
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    padding: 20px;
    width: 100%;
    max-width: 1200px;
    animation: slideIn 1s ease;
}

@keyframes slideIn {
    from { opacity: 0; transform: translateY(-30px); }
    to { opacity: 1; transform: translateY(0); }
}

.registration-card h4 {
    text-align: center;
    margin-bottom: 20px;
    color: #004080;
    font-weight: 600;
}

.register-btn {
    background: linear-gradient(90deg, #004080, #0073e6);
    color: #fff;
    font-weight: 500;
    transition: all 0.4s ease;
}

.register-btn:hover {
    background: linear-gradient(90deg, #003060, #005bb5);
    transform: translateY(-2px) scale(1.02);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

input.form-control,
textarea.form-control,
select.form-select {
    transition: all 0.3s ease;
}

input.form-control:focus,
textarea.form-control:focus,
select.form-select:focus {
    border-color: #0073e6;
    box-shadow: 0 0 0 3px rgba(0,115,230,0.1);
}

@media (max-width: 576px) {
    .navbar-brand span {
        font-size: 1.1rem;
    }
}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand d-flex align-items-center gap-2" href="#">
            <img src="../../images/logo.png" alt="Logo" style="height: 30px; width: auto;">
            <span>OEC School Registration Edit</span>
        </a>
        <div class="ms-auto d-flex gap-2">
            <button
                class="btn register-btn btn-sm"
                onclick="window.location.href='country_selector.html'"
                style="font-size: 0.9rem;">
                ← Back
            </button>
            <button
                class="btn register-btn btn-sm"
                onclick="window.location.href='../master_logout.php'"
                style="font-size: 0.9rem;">
                Logout
            </button>
        </div>
    </div>
</nav></div>
</nav>

<div class="registration-container container-fluid">
  <div class="registration-card">
    <h4>Register Your International School</h4>
    
    <?php if ($message): ?>
    <div class="alert <?php echo $message_class; ?> mt-3" role="alert">
        <?php echo $message; ?>
    </div>
    <?php endif; ?>

    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
      <div class="row g-3">
            
        <div class="col-md-6">
            <label class="form-label">School Name</label>
            <input type="text" class="form-control" name="school_name" required>
        </div>

        <div class="col-md-6">
            <label class="form-label">Country</label>
            <select class="form-select" name="country" id="country" required>
                <option selected disabled>Select Country</option>
            </select>
        </div>

        <div class="col-12">
            <label class="form-label">Address</label>
            <textarea class="form-control" name="address" rows="2" required></textarea>
        </div>

        <div class="col-md-4">
            <label class="form-label">State / Province</label>
            <input type="text" class="form-control" name="state" required>
        </div>

        <div class="col-md-4">
            <label class="form-label">City</label>
            <input type="text" class="form-control" name="city" required>
        </div>

        <div class="col-md-4">
            <label class="form-label">Zip / Postal Code</label>
            <input type="text" class="form-control" name="zip" required>
        </div>

        <div class="col-md-6">
            <label class="form-label">Contact Number</label>
            <input type="tel" class="form-control" name="contact_number" required pattern="[0-9]{10}" title="Must be a 10-digit number">
        </div>

        <div class="col-md-6">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" name="email" required>
        </div>

        <div class="col-md-6">
            <label class="form-label">Website (Optional)</label>
            <input type="url" class="form-control" name="website">
        </div>

        <div class="col-md-6">
            <label class="form-label">School Type</label>
            <select class="form-select" name="school_type" required>
                <option selected disabled>Select Type</option>
                <option>Public</option>
                <option>Private</option>
                <option>Charter</option>
            </select>
        </div>

        <div class="col-md-6">
            <label class="form-label">School Level</label>
            <select class="form-select" name="school_level" required>
                <option selected disabled>Select Level</option>
                <option>Primary School</option>
                <option>Elementary School</option>
                <option>Middle School</option>
                <option>Junior High School</option>
                <option>Secondary School</option>
                <option>Senior Secondary School</option>
                <option>High School</option>
            </select>
        </div>

        <div class="col-md-6">
            <label class="form-label">Accreditation</label>
            <input type="text" class="form-control" name="accreditation">
        </div>

        <div class="col-md-4">
            <label class="form-label">Grade/Class From</label>
            <select class="form-select" name="grade_from" required>
                <option selected disabled>Select Grade</option>
                <?php for ($i = 1; $i <= 12; $i++): ?>
                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label">Grade/Class To</label>
            <select class="form-select" name="grade_to" required>
                <option selected disabled>Select Grade</option>
                <?php for ($i = 1; $i <= 12; $i++): ?>
                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label">Total Students</label>
            <input type="number" class="form-control" name="total_students" required>
        </div>

        <div class="col-md-4">
            <label class="form-label">Total Teachers</label>
            <input type="number" class="form-control" name="total_teachers" required>
        </div>

        <div class="col-md-4">
            <label class="form-label">Principal Name</label>
            <input type="text" class="form-control" name="principal_name" required>
        </div>

        <div class="col-md-4">
          <label class="form-label">Principal Mobile</label>
          <input type="tel" class="form-control" name="principal_mobile" required pattern="[0-9]{10}" title="Must be a 10-digit number">
        </div>

        <div class="col-md-6">
            <label class="form-label">Principal Email</label>
            <input type="email" class="form-control" name="principal_email" required>
        </div>

        <div class="col-md-6">
            <label class="form-label">Teacher Name (Optional)</label>
            <input type="text" class="form-control" name="teacher_name">
        </div>

        <div class="col-md-6">
            <label class="form-label">Teacher Mobile (Optional)</label>
            <input type="tel" class="form-control" name="teacher_mobile" pattern="[0-9]{10}" title="Must be a 10-digit number">
        </div>

        <div class="col-md-6">
            <label class="form-label">Teacher Email (Optional)</label>
            <input type="email" class="form-control" name="teacher_email">
        </div>

        <div class="col-md-6">
            <label class="form-label">Password</label>
            <input type="password" class="form-control" name="password" id="password" required>
        </div>

        <div class="col-md-6">
            <label class="form-label">Confirm Password</label>
            <input type="password" class="form-control" name="confirm_password" id="confirm_password" required>
        </div>

      </div>

      <div class="text-center mt-4">
          <button type="submit" class="btn register-btn px-5">Register</button>
      </div>
    </form>
  </div>
</div>

<footer class="footer">
    &copy; <?php echo date("Y"); ?> Olympiad Examination Council. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    const data = [
    "Afghanistan","Albania","Algeria","Andorra","Angola","Antigua and Barbuda","Argentina","Armenia","Australia","Austria",
    "Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bhutan",
    "Bolivia","Bosnia and Herzegovina","Botswana","Brazil","Brunei",
    "Bulgaria","Burkina Faso","Burundi","Cabo Verde","Cambodia","Cameroon","Canada","Central African Republic","Chad","Chile",
    "China","Colombia","Comoros","Congo","Democratic Republic of the Congo","Costa Rica","Ivory Coast","Croatia","Cuba","Cyprus",
    "Czech Republic","Denmark","Djibouti","Dominica","Dominican Republic",
    "Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Eswatini","Ethiopia","Fiji","Finland",
    "France","Gabon","Gambia","Georgia","Germany","Ghana","Greece","Grenada","Guatemala","Guinea",
    "Guinea-Bissau","Guyana","Haiti","Honduras","Hungary",
    "Iceland","Indonesia","Iran","Iraq","Ireland","Israel","Italy","Jamaica","Japan",
    "Jordan","Kazakhstan","Kenya","Kiribati","Kuwait","Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho",
    "Liberia","Libya","Liechtenstein","Lithuania","Luxembourg",
    "Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Mauritania","Mauritius","Mexico",
    "Micronesia","Moldova","Monaco","Mongolia","Montenegro","Morocco","Mozambique","Myanmar","Namibia","Nauru",
    "Nepal","Netherlands","New Zealand","Nicaragua","Niger",
    "Nigeria","North Macedonia","Norway","Oman","Pakistan","Palau","Panama","Papua New Guinea","Paraguay","Peru",
    "Philippines","Poland","Portugal","Qatar","South Korea","Romania","Russia","Rwanda","Saint Kitts and Nevis","Saint Lucia",
    "Saint Vincent and the Grenadines","Samoa","San Marino","Sao Tome and Principe","Saudi Arabia",
    "Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa",
    "South Sudan","Spain","Sri Lanka","Sudan","Suriname","Sweden","Switzerland","Syria","Tajikistan","Thailand",
    "Timor-Leste","Togo","Tonga","Trinidad and Tobago","Tunisia",
    "Turkey","Turkmenistan","Tuvalu","Uganda","Ukraine","United Arab Emirates","United Kingdom","Tanzania","United States","Uruguay",
    "Uzbekistan","Vanuatu","Venezuela","Vietnam","Yemen","Zambia","Zimbabwe"
    ];

    window.onload = () => {
        const country = document.getElementById("country");
        data.forEach(c => {
            country.innerHTML += `<option>${c}</option>`;
        });
    };
</script>
</body>
</html>