<?php include 'auth_master.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Staff Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f2f5f8;
        }
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
        }
        .card-hover {
            transition: all 0.3s ease-in-out;
            border: none;
            border-radius: 12px;
        }
        .card-hover:hover {
            transform: translateY(-6px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }
        .card-title {
            font-weight: 600;
        }
        footer {
            margin-top: 80px;
            padding: 20px 0;
            background-color: #004080;
            color: #fff;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Olympiad Examination Council</a>
        </div>
    </nav>

    <div class="container py-5">
        <h2 class="text-center mb-5 fw-bold text-primary">Staff Management</h2>

        <div class="row justify-content-center g-4">
            <div class="col-md-5">
                <div class="card card-hover text-center p-4 bg-white shadow-sm">
                    <div class="card-body">
    <i class="bi bi-person-lines-fill display-4 text-info mb-3"></i>
    <h5 class="card-title">Add Staff</h5>
    <p class="card-text">Add Staff in the Olympiad system.</p>
    <a href="register.php" class="btn btn-outline-info w-100 mt-2">
        👥 Add Staff
    </a>
</div>

                </div>
            </div>

            <div class="col-md-5">
                <div class="card card-hover text-center p-4 bg-white shadow-sm">
                    <div class="card-body">
                        <i class="bi bi-pencil-square display-4 text-warning mb-3"></i>
                        <h5 class="card-title">Update Staff Info</h5>
                        <p class="card-text">Modify Staff details and update </p>
                        <a href="adminviewregrstion.php" class="btn btn-outline-warning w-100 mt-2">✏️ Update Staff</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="text-center">
        &copy; <?= date('Y') ?> Olympiad Examination Council. All rights reserved.
    </footer>
</body>
</html>
