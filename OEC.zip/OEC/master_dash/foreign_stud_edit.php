<?php
// include 'auth_admin.php';
include '../db.php';

// ✅ Exam Language Mapping
$langMap = [
    1 => "English",
    2 => "Hindi",
    3 => "French",
    4 => "Spanish"
];

// ✅ Gender Mapping
$genderMap = [
    1 => "Male",
    2 => "Female",
    3 => "Other"
];

// ✅ FETCH STUDENT DATA
if (isset($_GET['id'])) {
    $Student_ID = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM olympiad_registration WHERE Student_ID = ?");
    $stmt->bind_param("s", $Student_ID);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
    $stmt->close();

    if (!$student) {
        die("❌ Student not found.");
    }
} else {
    die("❌ No Student ID provided.");
}

// ✅ UPDATE STUDENT DATA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $Stud_name = $_POST['Stud_name'];
    $Parent_name = $_POST['Parent_name'];
    $Stud_dob = $_POST['Stud_dob'];
    $Gender = $_POST['Gender'];
    $Home_addr = $_POST['Home_addr'];
    $MobileNo = $_POST['MobileNo'];
    $WhatsAppNo = $_POST['WhatsAppNo'];
    $Country = $_POST['Country'];
    $Email_ID = $_POST['Email_ID'];
    $S_Cname = $_POST['S_Cname'];
    $S_Caddr = $_POST['S_Caddr'];
    $Grade = $_POST['Grade'];
    $C_Branch = $_POST['C_Branch']; // now storing text directly
    $Exam_Lg = $_POST['Exam_Lg'];

    $updateSQL = "UPDATE olympiad_registration 
                  SET Stud_name=?, Parent_name=?, Stud_dob=?, Gender=?, Home_addr=?, MobileNo=?, WhatsAppNo=?, 
                      Country=?, Email_ID=?, S_Cname=?, S_Caddr=?, Grade=?, C_Branch=?, Exam_Lg=? 
                  WHERE Student_ID=?";
    $stmt = $conn->prepare($updateSQL);
    $stmt->bind_param("sssisisssssssss", $Stud_name, $Parent_name, $Stud_dob, $Gender, $Home_addr, $MobileNo,
                      $WhatsAppNo, $Country, $Email_ID, $S_Cname, $S_Caddr, $Grade, $C_Branch, $Exam_Lg, $Student_ID);

    if ($stmt->execute()) {
        echo "<script>alert('✅ Student details updated successfully'); window.location='foreign_stud_view.php';</script>";
        exit();
    } else {
        echo "<script>alert('❌ Error updating student.');</script>";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Student</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
body { background-color: #f2f5f8; font-family: 'Poppins', sans-serif; }
.card { background: white; padding: 20px; border-radius: 16px; box-shadow: 0 8px 20px rgba(0,0,0,0.1); }
.navbar { background-color: #004080; }
.navbar-brand { font-weight: 600; color: white; }
footer { background-color: #004080; color: #ccc; text-align: center; padding: 1rem; margin-top: 20px; }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <div class="container-fluid px-4">
        <a class="navbar-brand" href="#">
            <img src="../images/logo.png" style="height: 40px;"> OEC Portal
        </a>
        <a href="foreign_stud_view.php" class="btn btn-light btn-sm">
            <i class="bi bi-arrow-left-circle"></i> Back to List
        </a>
    </div>
</nav>

<div class="container mt-4">
    <div class="card">
        <h3 class="text-center mb-3 text-primary">✏ Edit Student Details</h3>

        <form method="POST">
            <input type="hidden" name="Student_ID" value="<?= htmlspecialchars($student['Student_ID']) ?>">

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Student Name</label>
                    <input type="text" name="Stud_name" class="form-control" value="<?= htmlspecialchars($student['Stud_name']) ?>" required>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Parent Name</label>
                    <input type="text" name="Parent_name" class="form-control" value="<?= htmlspecialchars($student['Parent_name']) ?>" required>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Date of Birth</label>
                    <input type="date" name="Stud_dob" class="form-control" value="<?= htmlspecialchars($student['Stud_dob']) ?>" required>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Gender</label>
                    <select name="Gender" class="form-select">
                        <?php foreach($genderMap as $key=>$value): ?>
                            <option value="<?= $key ?>" <?= ($student['Gender'] == $key) ? 'selected' : '' ?>><?= $value ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Grade</label>
                    <input type="number" name="Grade" class="form-control" value="<?= htmlspecialchars($student['Grade']) ?>" required>
                </div>

                <div class="col-12">
                    <label class="form-label">Home Address</label>
                    <textarea name="Home_addr" class="form-control" rows="2"><?= htmlspecialchars($student['Home_addr']) ?></textarea>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Mobile No</label>
                    <input type="text" name="MobileNo" class="form-control" value="<?= htmlspecialchars($student['MobileNo']) ?>" required readonly>
                </div>

                <div class="col-md-6">
                    <label class="form-label">WhatsApp No</label>
                    <input type="text" name="WhatsAppNo" class="form-control" value="<?= htmlspecialchars($student['WhatsAppNo']) ?>">
                </div>

                <div class="col-md-6">
                    <label class="form-label">Country</label>
                    <input type="text" name="Country" class="form-control" value="<?= htmlspecialchars($student['Country']) ?>" required>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Email</label>
                    <input type="email" name="Email_ID" class="form-control" value="<?= htmlspecialchars($student['Email_ID']) ?>" required readonly>
                </div>

                <div class="col-md-6">
                    <label class="form-label">School Name</label>
                    <input type="text" name="S_Cname" class="form-control" value="<?= htmlspecialchars($student['S_Cname']) ?>" required>
                </div>

                <div class="col-md-6">
                    <label class="form-label">School Address</label>
                    <textarea name="S_Caddr" class="form-control" rows="2"><?= htmlspecialchars($student['S_Caddr']) ?></textarea>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Branch</label>
                    <select name="C_Branch" class="form-select">
                        <?php
                        $branches = ["Commerce", "Science", "Arts"];
                        foreach($branches as $branch): ?>
                            <option value="<?= $branch ?>" <?= ($student['C_Branch'] == $branch) ? 'selected' : '' ?>><?= $branch ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Exam Language</label>
                    <select name="Exam_Lg" class="form-select">
                        <?php foreach($langMap as $key=>$value): ?>
                            <option value="<?= $key ?>" <?= ($student['Exam_Lg'] == $key) ? 'selected' : '' ?>><?= $value ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="text-center mt-4 d-flex justify-content-center gap-3">
                <button type="submit" name="update" class="btn btn-success px-4">✅ Update</button>
                <a href="foreign_stud_view.php" class="btn btn-secondary px-4">❌ Cancel</a>
            </div>
        </form>
    </div>
</div>

<footer>
    <p class="mb-0">&copy; <?= date('Y') ?> Olympiad Examination Council | All Rights Reserved.</p>
</footer>
</body>
</html>
