<?php
session_start();

// Set cache control headers to prevent caching of this sensitive page
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
header("Pragma: no-cache"); // HTTP 1.0
header("Expires: 0"); // Proxies (e.g., set to a past date)

// Check if the master user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: masterlogin.php'); // Redirect to master login if not logged in
    exit();
}
?>

<?php
// include the database connection file
require_once '../db.php';

// fetch total students
$sql_students = "SELECT COUNT(RegNo) AS total_students FROM olympiad_registrations";
$result_students = $conn->query($sql_students);
$total_students = 0;
if ($result_students && $row = $result_students->fetch_assoc()) {
    $total_students = $row['total_students'];
}

// fetch total staff
$sql_staff = "SELECT COUNT(staff_id) AS total_staff FROM staff";
$result_staff = $conn->query($sql_staff);
$total_staff = 0;
if ($result_staff && $row = $result_staff->fetch_assoc()) {
    $total_staff = $row['total_staff'];
}

// --- Fetch the total count of Active Exams (AccountStatus = 'Active') ---
$sql_active = "SELECT COUNT(*) AS active_count FROM payment_transactions WHERE AccountStatus = 'Active'";
$result_active = $conn->query($sql_active);
$active_students = 0; // Default value
if ($result_active && $result_active->num_rows > 0) {
    $row = $result_active->fetch_assoc();
    $active_students = $row['active_count'];
}

// Count online and offline students based on payment mode
// SQL query to count online and offline payments
$sql = "SELECT 
            SUM(CASE WHEN PaymentMode = 'Online' THEN 1 ELSE 0 END) AS online_count,
            SUM(CASE WHEN PaymentMode = 'Offline' THEN 1 ELSE 0 END) AS offline_count
        FROM payment_transactions 
        WHERE AccountStatus = 'Active'"; // Added a WHERE clause to count only active accounts

$result = $conn->query($sql);

$online_students = 0;
$offline_students = 0;

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $online_students = $row['online_count'];
    $offline_students = $row['offline_count'];
}
// Close the database connection
$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>OEC Portal</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
html, body {
  height: 100%;
  width: 100%;
  overflow-x: hidden;
  overflow-y: auto;
  font-family: 'Inter', sans-serif;
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

*, *::before, *::after {
  box-sizing: inherit;
}

body {
  display: block;
  background: linear-gradient(135deg, #f5f7fa, #e4ecf7);
}

main {
  flex: 1;
}

.navbar {
  background: linear-gradient(90deg, #004080, #0056b3);
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.navbar .container-fluid {
  flex-wrap: wrap;
  gap: 0.5rem;
}

footer {
  background: linear-gradient(90deg, #004080, #0056b3);
  color: white;
  text-align: center;
  padding: 1rem 0;
  margin-top: auto;
  font-size: 0.9rem;
  position: relative;
  overflow: hidden;
  word-wrap: break-word;
}

footer::after {
  content: "";
  position: absolute;
  top: 0;
  left: -150%;
  height: 100%;
  width: 50%;
  background: linear-gradient(120deg, transparent, rgba(255,255,255,0.4), transparent);
  animation: shine 3s infinite;
}

@keyframes shine {
  0% { left: -150%; }
  50% { left: 150%; }
  100% { left: 150%; }
}

.card {
  opacity: 0;
  transform: translateY(30px);
  transition: all 0.6s ease;
  margin-bottom: 1rem;
}

.card.show {
  opacity: 1;
  transform: translateY(0);
}

canvas {
  max-width: 100%;
  height: auto;
  display: block;
  filter: drop-shadow(0px 4px 6px rgba(0,0,0,0.3));
  border-radius: 8px;
  background: rgba(255,255,255,0.05);
  padding: 10px;
  overflow-x: auto;
}

img {
  max-width: 100%;
  height: auto;
}

.offcanvas {
  background-color: #fdfdfd;
  color: #333;
  width: 260px;
  box-shadow: 2px 0 8px rgba(0,0,0,0.1);
}

.offcanvas-header {
  background-color: #004080;
  color: #fff;
  padding: 0.75rem 1rem;
}

.offcanvas-title {
  font-size: 1.1rem;
  font-weight: 600;
}

.accordion-item {
  border: none;
  margin-bottom: 4px;
  border-radius: 4px;
  overflow: hidden;
}

.accordion-button {
  background: linear-gradient(90deg, #f1f5f9, #e9eff5);
  font-weight: 500;
  color: #004080;
  font-size: 0.95rem;
  padding: 0.5rem 1rem;
  border-radius: 0 !important;
  box-shadow: none !important;
  transition: all 0.3s ease;
}

.accordion-button:hover {
  background: linear-gradient(90deg, #e6f0ff, #dceefb);
  transform: scale(1.02);
}

.accordion-button:focus {
  box-shadow: none;
}

.accordion-button:not(.collapsed) {
  color: #fff;
  background: linear-gradient(45deg, #004080, #0056b3);
}

.accordion-body {
  padding: 0.5rem 0.75rem;
  background-color: #f9fbfd;
}

.accordion-body .nav-link {
  color: #495057;
  font-size: 0.9rem;
  margin-bottom: 0.3rem;
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 0.35rem 0.5rem;
  border-radius: 4px;
  text-decoration: none;
  transition: all 0.2s ease-in-out;
}

.accordion-body .nav-link:hover {
  color: #004080;
  background-color: #e9f1fb;
}

.accordion-body .nav-link i {
  font-size: 1rem;
}

.card-hover {
  position: relative;
  overflow: hidden;
  color: #fff;
  transition: transform 0.4s ease, box-shadow 0.4s ease, background 0.6s ease;
  background: linear-gradient(135deg, #2c3e50, #4b6cb7);
  animation: colorCycle 8s ease-in-out infinite alternate;
}

.card-hover:hover {
  transform: translateY(-10px) scale(1.05);
  box-shadow: 0 1rem 2rem rgba(0, 0, 0, 0.4), 0 0 20px rgba(75, 108, 183, 0.4);
  background: linear-gradient(135deg, #1c2833, #34495e);
  cursor: pointer;
}

.card-hover::after {
  content: "";
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0;
  height: 0;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 50%;
  transform: translate(-50%, -50%);
  opacity: 0;
  transition: all 0.6s ease;
  z-index: 0;
}

.card-hover:hover::after {
  width: 250%;
  height: 250%;
  opacity: 1;
}

@keyframes colorCycle {
  0% { background: linear-gradient(135deg, #2c3e50, #4b6cb7); }
  50% { background: linear-gradient(135deg, #34495e, #22304a); }
  100% { background: linear-gradient(135deg, #2c3e50, #4b6cb7); }
}

.card-hover .icon {
  transition: color 0.4s ease, transform 0.3s ease;
}

.card-hover:hover .icon {
  transform: rotate(10deg) scale(1.2);
  color: #ffd700 !important;
}

.logout-btn {
  background-color: #f8f9fa;
  color: #004080;
  border: none;
  transition: all 0.3s ease;
  border-radius: 4px;
  font-size: 0.9rem;
  padding: 0.4rem 0.9rem;
  display: inline-flex;
  align-items: center;
  gap: 0.25rem;
  white-space: nowrap;
}

.logout-btn:hover {
  background-color: #e2e6ea;
  color: #002f5f;
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
  animation: bounce 0.6s;
}

@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-4px); }
}

button:focus, .btn:focus {
  outline: none;
  box-shadow: 0 0 0 3px rgba(0,64,128,0.3);
}

.navbar-brand b {
  animation: pulseColor 3s infinite;
}

@keyframes pulseColor {
  0% { color: #fff; }
  50% { color: #cce7ff; }
  100% { color: #fff; }
}

.row.mt-4.text-center > div {
  margin-bottom: 1rem;
}

@media (max-width: 992px) {
  .navbar-brand {
    font-size: 1.2rem;
  }
  .card .card-title {
    font-size: 0.95rem;
  }
  .card .card-text {
    font-size: 1rem;
  }
}

@media (max-width: 768px) {
  main {
    padding: 0 0.5rem;
  }
  .navbar-brand {
    font-size: 1rem;
  }
  .logout-btn {
    font-size: 0.8rem;
    padding: 0.3rem 0.6rem;
  }
  .accordion-button {
    font-size: 0.85rem;
  }
  .card .card-title {
    font-size: 0.9rem;
  }
  .card .card-text {
    font-size: 1rem;
  }
  footer {
    font-size: 0.8rem;
    padding: 0.5rem;
  }
  .offcanvas {
    width: 80%;
  }
  .row.mt-4.text-center {
    flex-direction: column;
  }
  #studentsChart {
    max-width: 100%;
  }
}

@media (max-width: 576px) {
  .navbar-brand {
    font-size: 0.85rem;
  }
  .text-white.fs-4,
  .text-white.fs-3 {
    font-size: 0.9rem !important;
  }
  .logout-btn {
    font-size: 0.75rem;
    padding: 0.25rem 0.5rem;
    margin-left: auto;
  }
  .accordion-button {
    font-size: 0.8rem;
  }
  .accordion-body .nav-link {
    font-size: 0.75rem;
  }
  .card-hover {
    transform: none !important;
    box-shadow: none !important;
  }
  .card .card-title {
    font-size: 0.85rem;
  }
  .card .card-text {
    font-size: 0.95rem;
  }
  footer {
    font-size: 0.7rem;
    padding: 0.3rem;
  }
  .offcanvas {
    width: 100%;
  }
  .navbar .container-fluid {
    flex-wrap: wrap;
    gap: 0.3rem;
  }
}

</style>

</head>

<body>

<!-- Navbar -->
<nav class="navbar navbar-dark" style="background-color: #004080;">
  <div class="container-fluid justify-content-between align-items-center flex-wrap">
    <div class="d-flex align-items-center">
      <button class="navbar-toggler me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Logo -->
      <img src="../images/logo.png" alt="Logo" style="height: 40px; width: auto;" class="me-2">

      <!-- Brand Text -->
      <a class="navbar-brand mb-0 h1" href="#">
        <b>Olympiad Examination Council</b>
      </a>
    </div>

    <div class="d-flex align-items-center gap-3 mt-2 mt-md-0">
      <a href="master_logout.php" class="btn btn-light btn-sm px-3 py-2 fw-semibold shadow-sm logout-btn">
        <i class="bi bi-box-arrow-right"></i> Logout
      </a>
    </div>
  </div>
</nav>

<!-- Offcanvas Menu -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasMenu">
  <div class="offcanvas-header border-bottom">
    <h5 class="offcanvas-title fw-bold">Navigation Menu</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
  </div>
  <div class="offcanvas-body p-2">
    <div class="accordion" id="menuAccordion">

   <div class="accordion-item mb-2">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
            <i class="bi bi-house-door-fill me-2"></i> School Registration
          </button>
        </h2>
        <div id="collapseOne" class="accordion-collapse collapse">
          <div class="accordion-body">
            <a href="school_affiliation/country_selector.html" class="nav-link ps-4">
              <i class="bi bi-plus-circle me-1"></i> Register School
            </a>
             <a href="school_affiliation/view_school_registration.php" class="nav-link ps-4">
              <i class="bi bi-plus-circle me-1"></i> View Registered School
            </a>
          </div>
        </div>
      </div>

      <div class="accordion-item mb-2">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
            <i class="bi bi-bell-fill me-2"></i> Notifications
          </button>
        </h2>
        <div id="collapseTwo" class="accordion-collapse collapse">
          <div class="accordion-body">
            <a href="../notifications/notification_entry.php" class="nav-link ps-4">
              <i class="bi bi-pencil-square me-1"></i> Post Notification
            </a>
            <a href="../notifications/notification_view.php" class="nav-link ps-4">
              <i class="bi bi-eye-fill me-1"></i> View Notifications
            </a>
          </div>
        </div>
      </div>

      <div class="accordion-item mb-2">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseStaff">
            <i class="bi bi-people-fill me-2"></i> Staff
          </button>
        </h2>
        <div id="collapseStaff" class="accordion-collapse collapse">
          <div class="accordion-body">
            <a href="addstaff.php" class="nav-link ps-4">
              <i class="bi bi-person-plus-fill me-1"></i> Add Staff
            </a>
             <a href="staff_view.php" class="nav-link ps-4">
              <i class="bi bi-person-plus-fill me-1"></i> view Staff
            </a>
          </div>
        </div>
      </div>


      <div class="accordion-item mb-2">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree">
            <i class="bi bi-people-fill me-2"></i> Exam
          </button>
        </h2>
        <div id="collapseThree" class="accordion-collapse collapse">
          <div class="accordion-body">
            <a href="activeInactiveExam.php" class="nav-link ps-4">
              <i class="bi bi-eye-fill me-1"></i> View  Indian Students
            </a>
            <a href="foreign_students.php" class="nav-link ps-4">
              <i class="bi bi-eye-fill me-1"></i> View  International Students
            </a>
          </div>
        </div>
      </div>

      <!-- <div class="accordion-item mb-2">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour">
            <i class="bi bi-star-fill me-2"></i> Donation
          </button>
        </h2>
        <div id="collapseFour" class="accordion-collapse collapse">
          <div class="accordion-body">
            <a href="../donation/view_donation.php" class="nav-link ps-4">
              <i class="bi bi-table me-1"></i> View Donation
            </a>
          </div>
        </div>
      </div> -->
        <div class="accordion-item mb-2">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAddQuestions">
              <i class="bi bi-question-circle-fill me-2"></i> Add Questions
            </button>
          </h2>
          <div id="collapseAddQuestions" class="accordion-collapse collapse">
            <div class="accordion-body">
              <a href="s4/index.php" class="nav-link ps-4">
                <i class="bi bi-plus-circle me-1"></i> Add / Manage Questions
              </a>
            </div>
          </div>
        </div>


      <div class="accordion-item mb-2">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive">
            <i class="bi bi-people-fill me-2"></i> Students
          </button>
        </h2>
        <div id="collapseFive" class="accordion-collapse collapse">
          <div class="accordion-body">
            <a href="indian_index.php" class="nav-link ps-4">
              <i class="bi bi-person me-1"></i> Indian Form
            </a>
            <a href="foreign_index.php" class="nav-link ps-4">
              <i class="bi bi-globe me-1"></i> Foreign Form
            </a>
          </div>
        </div>
      </div>

      <div class="accordion-item">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix">
            <i class="bi bi-upload me-2"></i> Files
          </button>
        </h2>
        <div id="collapseSix" class="accordion-collapse collapse">
          <div class="accordion-body">
            <a href="../download/admin_upload.php" class="nav-link ps-4">
              <i class="bi bi-plus-circle me-1"></i> Add Files
            </a>
            <a href="../download/download_view.php" class="nav-link ps-4">
              <i class="bi bi-eye-fill me-1"></i> View Files
            </a>
          </div>
        </div>
      </div>
     <div class="accordion-item">
      <h2 class="accordion-header">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseLogout">
          <i class="bi bi-box-arrow-right me-2"></i> Logout
        </button>
      </h2>
      <div id="collapseLogout" class="accordion-collapse collapse">
        <div class="accordion-body">
          <a href="master_logout.php" class="nav-link ps-4">
            <i class="bi bi-box-arrow-right me-1"></i> Logout
          </a>
        </div>
      </div>
    </div>

    </div>
  </div>
</div>


<main class="container my-5">
  <h1 class="text-center mb-4">Welcome to Olympiad Examination Council</h1>

  <div class="row mt-4 text-center">

    <div class="col-md-4 mb-3">
      <div class="card text-center shadow-sm h-100 card-hover">
        <div class="card-body">
          <i class="bi bi-people-fill display-4 text-primary"></i>
          <h5 class="card-title mt-2">Registered Students</h5>
          <p class="card-text display-6 text-primary">
            <?= htmlspecialchars($total_students) ?>
          </p>
        </div>
      </div>
    </div>

    <div class="col-md-4 mb-3">
      <div class="card text-center shadow-sm h-100 card-hover">
        <div class="card-body">
          <i class="bi bi-people-fill display-4 text-primary"></i>
          <h5 class="card-title mt-2">Active Students</h5>
          <p class="card-text display-6 text-primary">
            <?= htmlspecialchars($total_students) ?>
          </p>
        </div>
      </div>
    </div>

    <div class="col-md-4 mb-3">
        <div class="card text-center shadow-sm h-100 card-hover">
            <div class="card-body">
                <i class="bi bi-laptop-fill display-4 text-danger"></i>
                <h5 class="card-title mt-2">Online / Offline Students</h5>
                <p class="card-text display-6">
                    <span class="text-success">Online: <?= $online_students ?></span><br>
                    <span class="text-muted">Offline: <?= $offline_students ?></span>
                </p>
            </div>
        </div>
    </div>

    <div class="col-md-4 mb-3">
      <div class="card text-center shadow-sm h-100 card-hover">
        <div class="card-body">
          <i class="bi bi-person-badge-fill display-4 text-warning"></i>
          <h5 class="card-title mt-2">Total Staff</h5>
          <p class="card-text display-6 text-warning">
            <?= $total_staff ?>
          </p>
        </div>
      </div>
    </div>

    
  </div>

  <div class="row mt-5">
    <div class="col-12">
      <div class="card shadow-sm w-100">
        <div class="card-body">
          <h5 class="card-title text-center">Students Overview</h5>
          <canvas id="studentsChart" height="100"></canvas>
        </div>
      </div>
    </div>
  </div>
</main>



<footer>
  &copy; <span id="year"></span> Olympiad Examination Council. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
// Animate cards
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.card').forEach((card, i) => {
    setTimeout(() => card.classList.add('show'), i * 150);
  });
  document.getElementById('year').textContent = new Date().getFullYear();
});

// Animated chart
const ctx = document.getElementById('studentsChart').getContext('2d');
const studentsChart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels: ['Registered Students', 'Active Students'],
    datasets: [{
      label: 'Count',
      data: [1250, 980],
      backgroundColor: [
        'rgba(13, 110, 253, 0.7)',
        'rgba(25, 135, 84, 0.7)'
      ],
      borderColor: [
        'rgba(13, 110, 253, 1)',
        'rgba(25, 135, 84, 1)'
      ],
      borderWidth: 1
    }]
  },
  options: {
    animation: {
      duration: 1500,
      easing: 'easeOutBounce'
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: { stepSize: 200 }
      }
    }
  }
});
</script>
<script>
if (!window.performance || performance.navigation.type === 2) {
    location.reload(true);
}
</script>

</body>
</html>
