<?php
// Make sure to include your database connection file
include '../db.php';

// SQL query to fetch all data from both tables using a LEFT JOIN
// This query links student registration records with their payment transactions.
// It uses `LEFT JOIN` to ensure that all registered students are shown,
// even if they don't have a matching payment transaction yet.
$sql = "SELECT 
    r.Student_ID, 
    r.Stud_name, 
    r.Gender, 
    r.Grade, 
    r.C_Branch,
    p.Exam, 
    p.PaymentStatus, 
    p.PaymentMode, 
    p.PaymentDate, 
    p.AccountStatus
FROM olympiad_registration r
LEFT JOIN payment_transactions p ON r.Student_ID = p.RegID
ORDER BY r.Student_ID";

$result = $conn->query($sql);
$registrations = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $registrations[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student & Payment Data</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
body {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    background-color: rgb(187, 203, 219);
    font-family: 'Inter', sans-serif;
}
.navbar {
    background-color: #004080;
}
.navbar-brand {
    color: white !important;
    font-weight: 600;
    font-size: 1.5rem;
}
main h1 {
    color: #004080;
    font-weight: 600;
}
footer {
    background-color: #004080;
    color: white;
    text-align: center;
    padding: 1rem 0;
    margin-top: auto;
    font-size: 0.95rem;
}
</style>
</head>

<body>

<nav class="navbar navbar-expand-lg">
    <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
        <a class="navbar-brand d-flex align-items-center gap-2 text-white" href="#">
            <img src="../images/logo.png" alt="Logo" style="height: 40px; width: auto;">
            <span>OEC Portal</span>
        </a>
        <a href="masterdashboard.php" class="btn btn-light btn-sm">
            <i class="bi bi-arrow-left-circle me-1"></i> Back to Dashboard
        </a>
    </div>
</nav>

<main class="container my-5">
    <h1>International Student</h1>
    <p>Below is a combined view of student registrations and their corresponding payment transactions.</p>

    <div class="table-responsive mt-4">
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Grade</th>
                    <th>Branch</th>
                    <th>Exam</th>
                    <th>Payment Status</th>
                    <th>Payment Mode</th>
                    <th>Payment Date</th>
                    <th>Account Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($registrations)): ?>
                    <?php foreach ($registrations as $reg): ?>
                        <tr>
                            <td><?= htmlspecialchars($reg['Student_ID'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($reg['Stud_name'] ?? '-') ?></td>
                            <td>
                                <?php
                                    // Assuming Gender is 1 for Male, 2 for Female based on typical tinyint usage.
                                    if (isset($reg['Gender'])) {
                                        echo ($reg['Gender'] == 1) ? 'Male' : 'Female';
                                    } else {
                                        echo '-';
                                    }
                                ?>
                            </td>
                            <td><?= htmlspecialchars($reg['Grade'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($reg['C_Branch'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($reg['Exam'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($reg['PaymentStatus'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($reg['PaymentMode'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($reg['PaymentDate'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($reg['AccountStatus'] ?? '-') ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="10" class="text-center">No registration or payment data found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>

<footer class="text-center mt-auto">
    &copy; <?= date("Y") ?> Olympiad Examination Council. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
