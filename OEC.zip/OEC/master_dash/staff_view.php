<?php
require_once '../db.php';
require_once 'auth_master.php'; 

// Fetch staff records
$result = $conn->query("SELECT * FROM staff ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff List</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<style>
html, body {
    height: 100%;
    margin: 0;
}
body {
    display: flex;
    flex-direction: column;
    background-color: #f8f9fa;
}
main {
    flex: 1;
}
.header-logo {
    height: 50px;
}
.footer {
    background-color: #004080;
    color: white;
    text-align: center;
    padding: 10px 0;
}
table tbody tr:hover {
    background-color: #eef6ff;
}
</style>
</head>
<body>

<!-- Header -->
<nav class="navbar navbar-expand-lg" style="background-color: #004080;">
  <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
    <a class="navbar-brand d-flex align-items-center gap-2 text-white" href="#">
      <img src="../images/logo.png" alt="Logo" style="height: 40px; width: auto;">
      <span>OEC Portal</span>
    </a>
    <div class="d-flex align-items-center gap-3">
      <a href="masterdashboard.php" class="btn btn-light btn-sm">
        <i class="bi bi-arrow-left-circle me-1"></i> Back to Dashboard
      </a>
    </div>
  </div>
</nav>

<main class="container my-4">
  <h2 class="mb-4 text-center">Staff List</h2>
  <div class="table-responsive">
    <table id="staffTable" class="table table-striped table-bordered align-middle">
      <thead class="table-dark">
        <tr>
          <th>ID</th>
          <th>Full Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Position</th>
          <th>Department</th>
          <th>Username</th>
          <th>Created At</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($row['staff_id']) ?></td>
              <td><?= htmlspecialchars($row['full_name']) ?></td>
              <td><?= htmlspecialchars($row['email']) ?></td>
              <td><?= htmlspecialchars($row['phone']) ?></td>
              <td><?= htmlspecialchars($row['position']) ?></td>
              <td><?= htmlspecialchars($row['department']) ?></td>
              <td><?= htmlspecialchars($row['username']) ?></td>
              <td><?= htmlspecialchars($row['created_at']) ?></td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="8" class="text-center">No staff records found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</main>

<!-- Footer -->
<footer class="footer mt-auto">
  &copy; <?= date("Y") ?> Your Company Name. All Rights Reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function () {
  $('#staffTable').DataTable();
});
</script>

</body>
</html>

<?php
$conn->close();
?>
