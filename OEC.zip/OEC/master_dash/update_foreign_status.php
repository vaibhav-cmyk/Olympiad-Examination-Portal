<?php
// update_foreign_status.php
include 'db_connection.php'; // adjust this to your DB connection file

if (isset($_POST['id']) && isset($_POST['status'])) {
    $id = $_POST['id'];       // Student_ID from foreign_registration
    $status = $_POST['status']; // Active / Inactive

    // Prepare update statement
    $sql = "UPDATE foreign_payment_transactions 
            SET AccountStatus = ? 
            WHERE Student_ID = ?";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ss", $status, $id); // both are strings (varchar)
        if ($stmt->execute()) {
            echo "Success";
        } else {
            echo "Error executing query: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
} else {
    echo "Invalid request";
}

$conn->close();
?>
