<?php 
require_once '../db.php';
// require_once 'auth_master.php'; 
?>
<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Staff Registration | OEC</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #a8edea, #fed6e3);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

.navbar {
    background-color: #004080;
}

.navbar-brand {
    font-weight: 700;
    color: #fff !important;
    text-align: center;
    flex-wrap: wrap;
}

.navbar-brand img {
    height: 50px;
    width: auto;
}

.navbar-text {
    font-size: clamp(1rem, 3vw, 1.4rem);
    line-height: 1.2;
    display: block;
    color: #fff;
}

.footer {
    background-color: #004080;
    color: #fff;
    text-align: center;
    padding: 0.75rem 0;
    margin-top: auto;
    font-size: 0.9rem;
}

.card {
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    padding: 30px;
    max-width: 500px;
    width: 100%;
    animation: fadeIn 1s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}
.back-btn {
  background: #fff;
  color: #004080;
  font-weight: 500;
  border-radius: 15px;
  padding: 0.2rem 0.6rem;
  font-size: 0.8rem;
  text-decoration: none;
  transition: all 0.3s ease;
}
.back-btn:hover {
  background: #e6f0ff;
  color: #00264d;
  transform: scale(1.05);
}

.card h3 {
    text-align: center;
    margin-bottom: 25px;
    color: #004080;
    font-weight: 600;
}

.btn-primary {
    background: linear-gradient(45deg, #004080, #0066cc);
    border: none;
    font-weight: 500;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    background: linear-gradient(45deg, #002f5f, #0055aa);
    transform: scale(1.02);
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
}

.form-control {
    border-radius: 10px;
    min-height: 45px;
}

.form-control:focus {
    box-shadow: 0 0 5px rgba(74, 20, 140, 0.5);
    border-color: #4a148c;
}

.alert {
    font-size: 0.95rem;
    text-align: center;
}
</style>
</head>

<body>

<!-- Navbar -->
<nav class="navbar shadow" style="background-color: #004080;">
  <div class="container d-flex justify-content-center position-relative">
    <!-- Logo & Title in center -->
    <a class="navbar-brand d-flex flex-column align-items-center gap-1 m-0" href="#">
      <img src="../images/logo.png" alt="Logo" style="height: 45px;">
      <span class="navbar-text text-white text-center" style="font-size: 1rem;">Olympiad Examination Council</span>
    </a>

    <!-- Back button on right -->
    <a href="masterdashboard.php" class="back-btn position-absolute end-0 top-50 translate-middle-y me-2">
      <i class="bi bi-arrow-left-circle"></i> Back
    </a>
  </div>
</nav>

<!-- Registration Section -->
<main class="flex-grow-1 d-flex align-items-center justify-content-center py-4">
<div class="card">
<h3>✨ Register New Staff ✨</h3>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $position = trim($_POST['position']);
    $department = trim($_POST['department']);
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = $conn->prepare("SELECT staff_id FROM staff WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo '<div class="alert alert-danger">❌ Email already registered.</div>';
    } else {
        $stmt = $conn->prepare("INSERT INTO staff (full_name, email, phone, position, department, username, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $full_name, $email, $phone, $position, $department, $username, $password);
        if ($stmt->execute()) {
            echo '<div class="alert alert-success">✅ Registered successfully.</div>';
        } else {
            echo '<div class="alert alert-danger">❌ Error occurred. Try again.</div>';
        }
        $stmt->close();
    }
    $check->close();
}
?>

<form method="post" class="mt-3">
    <input class="form-control mb-2 shadow-sm" name="full_name" placeholder="👤 Full Name" required>
    <input class="form-control mb-2 shadow-sm" name="email" placeholder="📧 Email" required type="email">
    <input class="form-control mb-2 shadow-sm" name="phone" placeholder="📞 Phone">
    <input class="form-control mb-2 shadow-sm" name="position" placeholder="💼 Position">
    <input class="form-control mb-2 shadow-sm" name="department" placeholder="🏢 Department">
    <input class="form-control mb-2 shadow-sm" name="username" placeholder="👥 Username" required>
    <input class="form-control mb-2 shadow-sm" name="password" placeholder="🔒 Password" required type="password">
    <button class="btn btn-primary w-100 mt-2">Register</button>
</form>
<!-- 
<div class="text-center mt-3">
Already have an account? <a href="login.php" class="text-decoration-none fw-semibold text-primary">Login</a>
</div> -->

</div>
</main>

<!-- Footer -->
<footer class="footer">
  &copy; <?= date("Y") ?> Olympiad Examination Council. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

