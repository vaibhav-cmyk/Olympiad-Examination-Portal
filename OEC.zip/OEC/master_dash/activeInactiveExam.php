<?php
session_start();
// Ensure db.php exists and contains your database connection logic ($conn)
include '../db.php';

// Check if connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ----------------------------------------------------------------------------------
// Pagination Logic
// ----------------------------------------------------------------------------------

// Number of records to display per page.
$records_per_page = isset($_GET['per_page']) ? intval($_GET['per_page']) : 25;
$allowed_per_page = [10, 25, 50, 100, 200, 500];
if (!in_array($records_per_page, $allowed_per_page)) {
    $records_per_page = 25; // Default to 25 if an invalid value is provided.
}

// Get the current page number from the URL, or default to 1.
$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
if ($current_page <= 0) {
    $current_page = 1;
}

// Fetch total count of unique registration IDs
$total_records_query = "SELECT COUNT(DISTINCT RegID) AS total FROM olympiad_registrations";
$total_records_result = $conn->query($total_records_query);
$total_records = $total_records_result->fetch_assoc()['total'];

// Calculate total pages
$total_pages = ceil($total_records / $records_per_page);

// Calculate the offset for the main SQL query
$offset = ($current_page - 1) * $records_per_page;

// Fetch unique registration IDs for the current page
$sql_regids = "SELECT DISTINCT RegID FROM olympiad_registrations ORDER BY RegID ASC LIMIT ? OFFSET ?";
$stmt_regids = $conn->prepare($sql_regids);
$stmt_regids->bind_param("ii", $records_per_page, $offset);
$stmt_regids->execute();
$result_regids = $stmt_regids->get_result();

$current_page_regids = [];
while ($row = $result_regids->fetch_assoc()) {
    $current_page_regids[] = $row['RegID'];
}
$stmt_regids->close();

// Join the list of current page RegIDs into a string for the main query
$regid_list = implode("','", $current_page_regids);
$sql_data = "SELECT 
    o.RegID, o.RegNo, o.Stud_name, o.Parent_name, o.Stud_dob, o.Gender, o.Country, o.S_State, o.District, 
    o.MobileNo, o.Email_ID, o.Grade, o.C_Branch, 
    p.Exam, p.TransactionID, p.Amount, p.PaymentID, 
    p.PaymentStatus, p.PaymentDate, p.PaymentMode, p.AccountStatus
FROM olympiad_registrations o
LEFT JOIN payment_transactions p ON o.RegID = p.RegID
WHERE o.RegID IN ('$regid_list')
ORDER BY o.RegID, p.Exam";

$result_data = $conn->query($sql_data);

// Process the fetched data to group by RegID
$students = [];
if ($result_data && $result_data->num_rows > 0) {
    while ($row = $result_data->fetch_assoc()) {
        $regid = $row['RegID'];

        if (!isset($students[$regid])) {
            $students[$regid] = $row;
            $students[$regid]['SelectedExams'] = [];
            $students[$regid]['Payments'] = [];
        }

        if (!empty($row['Exam']) && !in_array($row['Exam'], $students[$regid]['SelectedExams'])) {
            $students[$regid]['SelectedExams'][] = $row['Exam'];
        }

        $students[$regid]['Payments'][] = $row;
    }
}

// active count my regid
$activeStudentsByMobile = [];
foreach ($students as $student) {
    $mobile = $student['MobileNo'];
    if (isset($activeStudentsByMobile[$mobile])) {
        continue;
    }
    foreach ($student['Payments'] as $payment) {
        if ($payment['AccountStatus'] === 'Active') {
            $activeStudentsByMobile[$mobile] = true;
            break;
        }
    }
}
$active_students = count($activeStudentsByMobile);

// subjects by class
$subjectsByClass = [];
for ($i = 1; $i <= 4; $i++) {
    $subjectsByClass[$i] = [
        "International Mathematics Olympiad",
        "International English Olympiad"
    ];
}
for ($i = 5; $i <= 10; $i++) {
    $subjectsByClass[$i] = [
        "International Mathematics Olympiad",
        "International English Olympiad",
        "International Science Olympiad",
        "International Space Olympiad"
    ];
}
$grade11_12_subjects = [
    "science" => [
        "International Physics Olympiad",
        "International Chemistry Olympiad",
        "International Mathematics Olympiad",
        "International Biology Olympiad"
    ],
    "commerce" => [
        "International English Olympiad",
        "International Commerce Olympiad"
    ],
    "arts" => [
        "International English Olympiad",
        "International Geography Olympiad",
        "International Economics Olympiad"
    ]
];
$all11_12_subjects = [];
foreach ($grade11_12_subjects as $branchSubjects) {
    $all11_12_subjects = array_merge($all11_12_subjects, $branchSubjects);
}
$all11_12_subjects = array_values(array_unique($all11_12_subjects));
$subjectsByClass[11] = $all11_12_subjects;
$subjectsByClass[12] = $all11_12_subjects;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>OEC Master Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
body {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    background-color: rgb(187, 203, 219);
    font-family: 'Inter', sans-serif;
}
.navbar {
    background-color: #004080;
}
.navbar-brand {
    color: white !important;
    font-weight: 600;
    font-size: 1.5rem;
}
main h1 {
    color: #004080;
    font-weight: 600;
}
footer {
    background-color: #004080;
    color: white;
    text-align: center;
    padding: 1rem 0;
    margin-top: auto;
    font-size: 0.95rem;
}
.pagination-controls {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
@media (max-width: 768px) {
    .pagination-controls {
        flex-direction: column;
        align-items: flex-start;
    }
    .pagination-controls > div:first-child {
        margin-bottom: 1rem;
    }
}
</style>
</head>

<body>

<nav class="navbar navbar-expand-lg">
    <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
        <a class="navbar-brand d-flex align-items-center gap-2 text-white" href="#">
            <img src="../images/logo.png" alt="Logo" style="height: 40px; width: auto;">
            <span>OEC Portal</span>
        </a>
        <a href="masterdashboard.php" class="btn btn-light btn-sm">
            <i class="bi bi-arrow-left-circle me-1"></i> Back to Dashboard
        </a>
    </div>
</nav>

<main class="container my-5">
    <h1>Indian Student</h1>
    <p>Below is the list of all registered students along with payment and related questions.</p>

    <p><strong>Active Students:</strong> <?= $active_students ?></p>

    <div class="mb-3 d-flex gap-3 flex-wrap">
        <input type="text" id="searchInput" class="form-control" placeholder="Search by Student Name..." style="flex: 1; min-width: 200px;">
        <input type="text" id="regNoInput" class="form-control" placeholder="Search by RegNo..." style="flex: 1; min-width: 200px;">
        <input type="text" id="examInput" class="form-control" placeholder="Search by Exam..." style="flex: 1; min-width: 200px;">
        <!--<input type="date" id="dateInput" class="form-control" placeholder="Search by Payment Date..." style="flex: 1; min-width: 200px;">-->
    </div>

    <div class="pagination-controls mb-3">
        <form method="get" class="d-flex align-items-center">
            <label for="per_page" class="form-label me-2 mb-0">Records per page:</label>
            <select name="per_page" id="per_page" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="10" <?= $records_per_page == 10 ? 'selected' : '' ?>>10</option>
                <option value="25" <?= $records_per_page == 25 ? 'selected' : '' ?>>25</option>
                <option value="50" <?= $records_per_page == 50 ? 'selected' : '' ?>>50</option>
                <option value="100" <?= $records_per_page == 100 ? 'selected' : '' ?>>100</option>
                <option value="200" <?= $records_per_page == 200 ? 'selected' : '' ?>>200</option>
                <option value="500" <?= $records_per_page == 500 ? 'selected' : '' ?>>500</option>
            </select>
            <input type="hidden" name="page" value="<?= $current_page ?>">
        </form>
        <nav aria-label="Page navigation">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= $current_page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page - 1 ?>&per_page=<?= $records_per_page ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= $i == $current_page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&per_page=<?= $records_per_page ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $current_page >= $total_pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page + 1 ?>&per_page=<?= $records_per_page ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>

    <div class="table-responsive mt-4">
    <table class="table table-bordered table-striped" id="masterTable">
    <thead class="table-dark">
    <tr>
        <th>RegID</th>
        <th>RegNo</th>
        <th>Name</th>
        <th>Email</th>
        <th>Mobile</th>
        <th>Grade</th>
        <th>Branch</th>
        <th>Exam</th>
        <th>Payment Status</th>
        <th>Payment Mode</th>
        <th>Payment Date</th>
        <th>Account Status</th>
    </tr>
    </thead>
    <tbody>

    <?php 
    foreach ($students as $student): 
    $grade = (int)$student['Grade'];
    $regid = $student['RegID'];

    if ($grade == 11 || $grade == 12) {
        $branch = strtolower(trim($student['C_Branch']));
        if (!empty($branch) && isset($grade11_12_subjects[$branch])) {
            $availableExams = $grade11_12_subjects[$branch];
        } else {
            $branch = '-';
            $availableExams = [];
        }
    } else {
        $branch = '-';
        $availableExams = $subjectsByClass[$grade] ?? [];
    }

    $examCount = count($availableExams) ?: 1;
    $firstRow = true;

    if (empty($availableExams)) {
        $availableExams = ['-'];
    }

    foreach ($availableExams as $examForGrade):
    $matchedPayment = null;
    foreach ($student['Payments'] as $payment) {
        if ($payment['Exam'] === $examForGrade) {
            $matchedPayment = $payment;
            break;
        }
    }

    $accountStatus = $matchedPayment['AccountStatus'] ?? '';
    ?>
    <tr data-grade="<?= $grade ?>">
    <?php if ($firstRow): ?>
    <td rowspan="<?= $examCount ?>"><?= $student['RegID'] ?></td>
    <td rowspan="<?= $examCount ?>"><?= $student['RegNo'] ?></td>
    <td rowspan="<?= $examCount ?>" class="student-name"><?= $student['Stud_name'] ?></td>
    <td rowspan="<?= $examCount ?>"><?= $student['Email_ID'] ?></td>
    <td rowspan="<?= $examCount ?>"><?= $student['MobileNo'] ?></td>
    <td rowspan="<?= $examCount ?>"><?= $student['Grade'] ?></td>
    <td rowspan="<?= $examCount ?>"><?= htmlspecialchars($branch) ?></td>
    <?php endif; ?>

    <td><?= htmlspecialchars($examForGrade) ?></td>

    <td style="display:none;"><?= isset($matchedPayment['Amount']) ? number_format($matchedPayment['Amount'], 2) : '-' ?></td>
    <td><?= htmlspecialchars($matchedPayment['PaymentStatus'] ?? '-') ?></td>
    <td><?= htmlspecialchars($matchedPayment['PaymentMode'] ?? '-') ?></td>
    <td><?= htmlspecialchars($matchedPayment['PaymentDate'] ?? '-') ?></td>
    <td>
    <?php
        if ($matchedPayment) {
            if ($matchedPayment['PaymentStatus'] === 'Success') {
                echo "<button class='btn btn-success btn-sm' disabled>Active</button>";
            } else {
                if ($accountStatus === 'Active') {
                    echo "<form method='POST' action='toggle_account_status.php' class='d-inline'>
                        <input type='hidden' name='regid' value='{$student['RegID']}'>
                        <input type='hidden' name='exam' value='{$examForGrade}'>
                        <input type='hidden' name='status' value='Inactive'>
                        <button type='submit' class='btn btn-success btn-sm'>Active</button>
                    </form>";
                } else {
                    echo "<form method='POST' action='toggle_account_status.php' class='d-inline'>
                        <input type='hidden' name='regid' value='{$student['RegID']}'>
                        <input type='hidden' name='exam' value='{$examForGrade}'>
                        <input type='hidden' name='status' value='Active'>
                        <button type='submit' class='btn btn-danger btn-sm'>Inactive</button>
                    </form>";
                }
            }
        } else {
            echo "<form method='POST' action='toggle_account_status.php' class='d-inline'>
                    <input type='hidden' name='regid' value='{$student['RegID']}'>
                    <input type='hidden' name='exam' value='{$examForGrade}'>
                    <input type='hidden' name='status' value='Active'>
                    <button type='submit' class='btn btn-danger btn-sm opacity-75'>Inactive</button>
                </form>";
        }
    ?>
    </td>
    </tr>
    <?php 
    $firstRow = false;
    endforeach;
    endforeach; 
    ?>

    </tbody>
    </table>
    </div>

    <div class="pagination-controls mt-3">
        <div>Showing <?= $offset + 1 ?> to <?= min($offset + $records_per_page, $total_records) ?> of <?= $total_records ?> entries</div>
        <nav aria-label="Page navigation">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= $current_page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page - 1 ?>&per_page=<?= $records_per_page ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= $i == $current_page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&per_page=<?= $records_per_page ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $current_page >= $total_pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $current_page + 1 ?>&per_page=<?= $records_per_page ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>

</main>
<script>
function filterTable() {
    const nameFilter = document.getElementById("searchInput").value.toLowerCase();
    const regNoFilter = document.getElementById("regNoInput").value.toLowerCase();
    const examFilter = document.getElementById("examInput").value.toLowerCase();

    const rows = Array.from(document.querySelectorAll("#masterTable tbody tr"));

    // Group rows by RegID (first row has rowspan)
    const groups = [];
    let currentGroup = [];
    rows.forEach(row => {
        const cells = row.querySelectorAll("td");
        if (cells[0] && cells[0].hasAttribute("rowspan")) {
            if (currentGroup.length > 0) groups.push(currentGroup);
            currentGroup = [row];
        } else {
            currentGroup.push(row);
        }
    });
    if (currentGroup.length > 0) groups.push(currentGroup);

    // Check each group
    groups.forEach(group => {
        let showGroup = false;

        group.forEach(row => {
            const cells = row.querySelectorAll("td");
            const isFirstRow = cells[0] && cells[0].hasAttribute("rowspan");

            // Name & RegNo filters
            if (isFirstRow) {
                const nameCell = row.querySelector(".student-name");
                if (nameFilter && nameCell && nameCell.textContent.toLowerCase().includes(nameFilter)) {
                    showGroup = true;
                }
                const regNoCell = cells[1];
                if (regNoFilter && regNoCell && regNoCell.textContent.toLowerCase().includes(regNoFilter)) {
                    showGroup = true;
                }
            }

            // Exam filter (last column before PaymentStatus)
            const examCell = isFirstRow ? cells[7] : cells[0];
            if (examFilter && examCell && examCell.textContent.toLowerCase().includes(examFilter)) {
                showGroup = true;
            }
        });

        // Show/hide all rows in the group
        group.forEach(row => {
            row.style.display = showGroup ? "" : "none";
        });
    });
}

// Attach events
document.getElementById("searchInput").addEventListener("keyup", filterTable);
document.getElementById("regNoInput").addEventListener("keyup", filterTable);
document.getElementById("examInput").addEventListener("keyup", filterTable);
</script>


<footer class="text-center mt-auto">
    &copy; <?= date("Y") ?> Olympiad Examination Council. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
