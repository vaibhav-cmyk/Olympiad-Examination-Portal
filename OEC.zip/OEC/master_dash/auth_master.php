<?php
session_start();

// Check if master admin is logged in
if (empty($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: masterlogin.php"); // adjust path if needed
    exit();
}

// Optional: add no-cache headers to prevent back navigation after logout
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
?>
