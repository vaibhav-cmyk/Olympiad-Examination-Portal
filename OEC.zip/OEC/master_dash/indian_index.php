<?php include 'auth_master.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<style>
body {
  background-color: #eef3f7;
  font-family: 'Inter', sans-serif;
}

.navbar {
  background-color: #004080;
}

.navbar-brand {
  font-weight: 700;
  font-size: 1.4rem;
}

.header-title {
  font-size: 2rem;
  font-weight: 700;
  color: #004080;
}

.card-hover {
  transition: all 0.4s ease-in-out;
  border: none;
  border-radius: 12px;
  position: relative;
  overflow: hidden;
  background: linear-gradient(135deg, #ffffff, #f7f9fb);
}

.card-hover::before {
  content: '';
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: radial-gradient(circle at center, rgba(0, 64, 128, 0.05), transparent);
  transform: scale(0);
  transition: transform 0.4s ease;
  z-index: 0;
}

.card-hover:hover::before {
  transform: scale(1);
}

.card-hover:hover {
  transform: translateY(-8px) scale(1.02);
  box-shadow: 0 12px 35px rgba(0, 0, 0, 0.15);
  background: linear-gradient(135deg, #f7f9fb, #ffffff);
}

.card-title {
  font-weight: 600;
  color: #004080;
  position: relative;
  z-index: 1;
}

.card-body > * {
  position: relative;
  z-index: 1;
}

footer {
  background-color: #004080;
  color: #fff;
  padding: 15px 0;
  font-size: 0.9rem;
  margin-top: auto;
}

@media (max-width: 576px) {
  .header-title {
    font-size: 1.5rem;
  }
  .card .card-title {
    font-size: 1rem;
  }
  .card-hover {
    margin-bottom: 1rem;
  }
}
</style>
</head>

<body class="d-flex flex-column min-vh-100">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
    <a class="navbar-brand d-flex align-items-center gap-2 text-white" href="#">
      <img src="../images/logo.png" alt="Logo" style="height: 40px; width: auto;">
      <span>OEC Portal</span>
    </a>
    <a href="masterdashboard.php" class="btn btn-light btn-sm">
      <i class="bi bi-arrow-left-circle me-1"></i> Back to Dashboard
    </a>
  </div>
</nav>

<!-- Main Content -->
<main class="container py-5 flex-grow-1">
  <h2 class="text-center header-title mb-5">Student Management</h2>

  <div class="row justify-content-center g-4">
    <!-- Card 1 -->
    <div class="col-sm-10 col-md-6 col-lg-5">
      <div class="card card-hover text-center p-4 shadow-sm h-100">
        <div class="card-body d-flex flex-column justify-content-between">
          <div>
            <i class="bi bi-person-lines-fill display-4 text-info mb-3"></i>
            <h5 class="card-title">Add Students</h5>
            <p class="card-text">Add students into the Olympiad system quickly & easily.</p>
          </div>
          <a href="../olympiad_form/index.php" class="btn btn-info w-100 mt-3 text-white">
            👥 Add Students
          </a>
        </div>
      </div>
    </div>

    <!-- Card 2 -->
    <div class="col-sm-10 col-md-6 col-lg-5">
      <div class="card card-hover text-center p-4 shadow-sm h-100">
        <div class="card-body d-flex flex-column justify-content-between">
          <div>
            <i class="bi bi-pencil-square display-4 text-warning mb-3"></i>
            <h5 class="card-title">Update Student Info</h5>
            <p class="card-text">Modify student details and keep records up to date.</p>
          </div>
          <a href="view_registrations.php" class="btn btn-warning w-100 mt-3 text-white">
            ✏️ Update Student
          </a>
        </div>
      </div>
    </div>
  </div>
</main>

<!-- Footer -->
<footer class="text-center mt-auto">
  &copy; <?= date('Y') ?> Olympiad Examination Council. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
