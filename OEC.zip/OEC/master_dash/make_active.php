<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['regid'])) {
    $regid = intval($_POST['regid']);

    // 1. Update AccountStatus to Active
    $updateStatus = "UPDATE olympiad_registrations SET AccountStatus = 'Active' WHERE RegID = $regid";

    // 2. Fetch info for Exam & Amount for that student
    $getDetails = "SELECT Exam, Amount FROM payment_transactions WHERE RegID = $regid ORDER BY PaymentDate DESC LIMIT 1";
    $detailsResult = $conn->query($getDetails);
    $exam = 'Offline Payment';
    $amount = 0.00;

    if ($detailsResult && $detailsResult->num_rows > 0) {
        $row = $detailsResult->fetch_assoc();
        $exam = $row['Exam'];
        $amount = $row['Amount'];
    }

    // 3. Insert a new payment transaction for offline activation
    $insertTransaction = "INSERT INTO payment_transactions (RegID, Exam, Amount, PaymentStatus, PaymentMode)
                          VALUES ($regid, '$exam', $amount, 'Success', 'Offline')";

    if ($conn->query($updateStatus) === TRUE && $conn->query($insertTransaction) === TRUE) {
        header("Location: master_dashboard.php?msg=activated");
        exit();
    } else {
        echo "Error updating status or inserting transaction: " . $conn->error;
    }
}

$conn->close();
?>
