<?php
session_start();

// Set cache control headers for the login page itself
// This prevents the login page from being cached, ensuring fresh display on back button.
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
header("Pragma: no-cache"); // HTTP 1.0
header("Expires: 0"); // Proxies (e.g., set to a past date)

// Redirect to dashboard if already logged in (check for valid session state)
// IMPORTANT: Remove the session_destroy() at the very top.
// It's better to let the logout page handle session destruction explicitly.
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header('Location: masterlogin.php');
    exit();
}

// Credentials
// IMPORTANT: For production, do NOT hardcode credentials. Use a database.
// This is for demonstration only.
$correct_email = 'aruna@gmail.com';
$correct_password = 'Aruna@123';

$error_message = ''; // Initialize error message

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if ($email === $correct_email && $password === $correct_password) {
        $_SESSION['logged_in'] = true;
        // Regenerate session ID for security (prevents session fixation)
        session_regenerate_id(true);
        header('Location: masterdashboard.php');
        exit();
    } else {
        $error_message = 'Invalid email or password!';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Master Login Page</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<style>
body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #dbe9f4, #f0f4f8);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    overflow-x: hidden;
}

.navbar {
    background: linear-gradient(90deg, #004080, #0073e6);
}

.navbar-brand {
    font-weight: 600;
    font-size: 1.5rem;
    color: #fff !important;
}

.footer {
    background: linear-gradient(90deg, #004080, #0073e6);
    color: #fff;
    text-align: center;
    padding: 1rem 0;
    margin-top: auto;
    font-size: 0.95rem;
    position: relative;
    overflow: hidden;
}

.footer::after {
    content: "";
    position: absolute;
    top: 0;
    left: -150%;
    height: 100%;
    width: 50%;
    background: linear-gradient(120deg, transparent, rgba(255,255,255,0.4), transparent);
    animation: shine 3s infinite;
}

@keyframes shine {
    0% { left: -150%; }
    50% { left: 150%; }
    100% { left: 150%; }
}

.login-container {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem;
}

.login-card {
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    padding: 40px;
    width: 100%;
    max-width: 420px;
    animation: slideIn 1s ease;
}

@keyframes slideIn {
    from { opacity: 0; transform: translateY(-30px); }
    to { opacity: 1; transform: translateY(0); }
}

.login-card h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #004080;
    font-weight: 600;
}

.login-btn {
    background: linear-gradient(90deg, #004080, #0073e6);
    color: #fff;
    font-weight: 500;
    transition: all 0.4s ease;
}

.login-btn:hover {
    background: linear-gradient(90deg, #003060, #005bb5);
    transform: translateY(-2px) scale(1.02);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.login-btn:focus {
    box-shadow: 0 0 0 3px rgba(0,115,230,0.3);
}

.error-message {
    color: red;
    font-size: 14px;
    text-align: center;
    margin-top: 10px;
}

input.form-control {
    transition: all 0.3s ease;
}

input.form-control:focus {
    border-color: #0073e6;
    box-shadow: 0 0 0 3px rgba(0,115,230,0.1);
}

@media (max-width: 576px) {
    .login-card {
        padding: 25px;
    }
    .navbar-brand {
        font-size: 1.2rem;
    }
    .footer {
        font-size: 0.8rem;
    }
}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="#">
            <img src="../images/logo.png" alt="Logo" style="height: 40px; width: auto;">
            <span>OEC Master Panel</span>
        </a>
    </div>
</nav>

<div class="login-container">
    <div class="login-card">
        <h2>Master Login</h2>
        <form method="POST" action="masterlogin.php">
            <div class="mb-3">
                <label for="email" class="form-label">Email ID</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="Enter your email" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Enter your password" required>
            </div>
            <button type="submit" class="btn login-btn w-100">Login</button>

            <?php if (isset($error_message) && !empty($error_message)): ?>
                <div class="error-message"><?= $error_message ?></div>
            <?php endif; ?>
        </form>
    </div>
</div>

<footer class="footer">
    &copy; <?= date("Y") ?> Olympiad Examination Council. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>