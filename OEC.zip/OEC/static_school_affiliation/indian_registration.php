<?php
session_start();
// Include the database connection file
// Make sure the path to 'db.php' is correct.
include '../db.php';

// Check for and display any session messages (success or error)
$message = '';
$message_class = '';
if (isset($_SESSION['success_message'])) {
    $message = htmlspecialchars($_SESSION['success_message']);
    $message_class = 'alert-success';
    unset($_SESSION['success_message']);
} elseif (isset($_SESSION['error_message'])) {
    $message = htmlspecialchars($_SESSION['error_message']);
    $message_class = 'alert-danger';
    unset($_SESSION['error_message']);
}

// --- PHP Logic to Handle Form Submission ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Collect form data. Use null coalescing operator for safety.
    $udise_code = $_POST['udise_code'] ?? '';
    $school_name = $_POST['school_name'] ?? '';
    $address = $_POST['address'] ?? '';
    $state = $_POST['state'] ?? '';
    $district = $_POST['district'] ?? '';
    
    // Check if taluka and website are empty and set to '-' if they are
    $taluka = empty($_POST['taluka']) ? '-' : $_POST['taluka'];
    $city = $_POST['city'] ?? '';
    $contact_number = $_POST['contact_number'] ?? '';
    $email = $_POST['email'] ?? '';
    $website = empty($_POST['website']) ? '-' : $_POST['website'];
    
    $school_type = $_POST['school_type'] ?? '';
    $school_level = $_POST['school_level'] ?? '';
    $affiliation = $_POST['affiliation'] ?? '';
    $area = $_POST['area'] ?? '';
    $grade_from = intval($_POST['grade_from'] ?? 0);
    $grade_to = intval($_POST['grade_to'] ?? 0);
    $total_students = intval($_POST['total_students'] ?? 0);
    $total_teachers = intval($_POST['total_teachers'] ?? 0);
    $principal_name = $_POST['principal_name'] ?? '';
    $principal_mobile = $_POST['principal_mobile'] ?? '';
    $teacher_incharge_name = $_POST['teacher_incharge_name'] ?? '';
    $teacher_incharge_mobile = $_POST['teacher_incharge_mobile'] ?? '';
    $password_input = $_POST['password'] ?? '';
    $confirm_password_input = $_POST['confirm_password'] ?? '';

    // Validate passwords
    if ($password_input !== $confirm_password_input) {
        $_SESSION['error_message'] = "Passwords do not match.";
        header("Location: indian_registration.php");
        exit;
    }
    
    // Check for empty password
    if (empty($password_input)) {
        $_SESSION['error_message'] = "Password cannot be empty.";
        header("Location: indian_registration.php");
        exit;
    }

    // Hash the password for secure storage
    $password_hash = password_hash($password_input, PASSWORD_DEFAULT);

    // --- Generate Unique School ID (e.g., OEC20250001) ---
    $prefix = "OEC2025";
    $sql_last_id = "SELECT school_id FROM indian_schools WHERE school_id LIKE '$prefix%' ORDER BY school_id DESC LIMIT 1";
    $result = $conn->query($sql_last_id);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $last_id_num = intval(substr($row['school_id'], strlen($prefix))); 
        $new_id_num = $last_id_num + 1;
    } else {
        $new_id_num = 1;
    }

    $school_id = $prefix . str_pad($new_id_num, 4, "0", STR_PAD_LEFT);

    // --- Insert Data into the Database using a Prepared Statement ---
    $sql = "INSERT INTO indian_schools 
    (school_id, udise_code, school_name, address, state, district, taluka, city, contact_number, email, website, school_type, school_level, affiliation, area, grade_from, grade_to, total_students, total_teachers, principal_name, principal_mobile, teacher_incharge_name, teacher_incharge_mobile, password_hash) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        $_SESSION['error_message'] = "Database error (prepare): " . htmlspecialchars($conn->error);
        header("Location: indian_registration.php");
        exit;
    }
    
    // The bind string represents the data types of the parameters.
    // 's' = string, 'i' = integer
    // This bind string matches the 24 placeholders in the SQL query.
    $stmt->bind_param(
        "sssssssssssssssiiiisssss",
        $school_id, $udise_code, $school_name, $address, $state, $district, $taluka, $city,
        $contact_number, $email, $website, $school_type, $school_level, $affiliation, $area,
        $grade_from, $grade_to, $total_students, $total_teachers, $principal_name, $principal_mobile,
        $teacher_incharge_name, $teacher_incharge_mobile, $password_hash
    );
    

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "✅ Thank you for submitting your school affiliation request.
         We have received your application and will review it.
         We'll contact you within a week regarding a potential partnership.
         Your School ID is: " . htmlspecialchars($school_id);
        header("Location: indian_registration.php");
        exit();
    } else {
        $_SESSION['error_message'] = "❌ Error registering school. Please try again. " . htmlspecialchars($stmt->error);
        header("Location: indian_registration.php");
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>School Registration</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<style>
body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #dbe9f4, #f0f4f8);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}
.navbar {
    background: linear-gradient(90deg, #004080, #0073e6);
}
.navbar-brand {
    font-weight: 600;
    font-size: 1.2rem;
    color: #fff !important;
}
.footer {
    background: linear-gradient(90deg, #004080, #0073e6);
    color: #fff;
    text-align: center;
    padding: 1rem 0;
    margin-top: auto;
    font-size: 0.95rem;
    position: relative;
    overflow: hidden;
}
.footer::after {
    content: "";
    position: absolute;
    top: 0;
    left: -150%;
    height: 100%;
    width: 50%;
    background: linear-gradient(120deg, transparent, rgba(255,255,255,0.4), transparent);
    animation: shine 3s infinite;
}
@keyframes shine {
    0% { left: -150%; }
    50% { left: 150%; }
    100% { left: 150%; }
}
.registration-container {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1rem;
}
.registration-card {
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    padding: 20px;
    width: 100%;
    max-width: 1200px;
    animation: slideIn 1s ease;
}
@keyframes slideIn {
    from { opacity: 0; transform: translateY(-30px); }
    to { opacity: 1; transform: translateY(0); }
}
.registration-card h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #004080;
    font-weight: 600;
}
.register-btn {
    background: linear-gradient(90deg, #004080, #0073e6);
    color: #fff;
    font-weight: 500;
    transition: all 0.4s ease;
}
.register-btn:hover {
    background: linear-gradient(90deg, #003060, #005bb5);
    transform: translateY(-2px) scale(1.02);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}
input.form-control,
textarea.form-control,
select.form-select {
    transition: all 0.3s ease;
}
input.form-control:focus,
textarea.form-control:focus,
select.form-select:focus {
    border-color: #0073e6;
    box-shadow: 0 0 0 3px rgba(0,115,230,0.1);
}
@media (max-width: 576px) {
    .navbar-brand {
        font-size: 1rem;
    }
}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand d-flex align-items-center gap-2" href="#">
            <img src="../images/logo.png" alt="Logo" style="height: 30px; width: auto;">
            <span>OEC School Registration Edit</span>
        </a>
        <div class="ms-auto d-flex gap-2">
            <button
                class="btn register-btn btn-sm"
                onclick="window.location.href='../../index.html'"
                style="font-size: 0.9rem;">
                ← Back
            </button>
            
        </div>
    </div>
</nav>

<div class="registration-container container-fluid">
  <div class="registration-card">
    <h2>School Registration</h2>
    
    <?php if ($message): ?>
    <div class="alert <?php echo $message_class; ?> mt-3" role="alert">
        <?php echo $message; ?>
    </div>
    <?php endif; ?>

    <form id="registration-form" class="row g-3" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">

      <div class="col-md-6">
        <label class="form-label">UDISE Code</label>
        <input type="text" class="form-control" name="udise_code" required>
      </div>

      <div class="col-md-6">
        <label class="form-label">School Name</label>
        <input type="text" class="form-control" name="school_name" required>
      </div>

      <div class="col-12">
        <label class="form-label">Address</label>
        <textarea class="form-control" rows="2" name="address" required></textarea>
      </div>

      <div class="col-md-4">
        <label class="form-label">State</label>
        <select id="state" name="state" class="form-select" required>
          <option selected disabled>Select State</option>
        </select>
      </div>

      <div class="col-md-4">
        <label class="form-label">District</label>
        <select id="district" name="district" class="form-select" required>
          <option selected disabled>Select District</option>
        </select>
      </div>

      <div class="col-md-4">
        <label class="form-label">Taluka</label>
        <input type="text" class="form-control" name="taluka">
      </div>

      <div class="col-md-6">
        <label class="form-label">City</label>
        <input type="text" class="form-control" name="city" required>
      </div>

      <div class="col-md-6">
        <label class="form-label">Contact Number</label>
        <input type="tel" class="form-control" name="contact_number" placeholder="Enter Contact Number" pattern="[0-9]{10}" title="Enter a 10-digit phone number" required>
      </div>

      <div class="col-md-6">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" name="email" required>
      </div>

      <div class="col-md-6">
        <label class="form-label">Website</label>
        <input type="url" class="form-control" name="website">
      </div>

      <div class="col-md-6">
        <label class="form-label">School Type</label>
        <select class="form-select" name="school_type" required>
          <option selected disabled>Select School Type</option>
          <option>Government</option>
          <option>Semi Government</option>
          <option>Private</option>
        </select>
      </div>

      <div class="col-md-6">
        <label class="form-label">School Level</label>
        <select class="form-select" name="school_level" required>
          <option selected disabled>Select School Level</option>
          <option>Primary</option>
          <option>Secondary</option>
          <option>High School</option>
        </select>
      </div>

        <div class="col-md-6">
            <label class="form-label">Affiliation</label>
            <select class="form-control" name="affiliation" required>
                    <option value="" selected disabled>-- Select Affiliation --</option>
                    <option value="State Board">State Board</option>
                    <option value="ICSE">ICSE</option>
                    <option value="CBSE">CBSE</option>
                    <option value="IB">IB</option>
                    <option value="IGCSE">IGCSE</option>
                    <option value="Others">Others</option>
                </select>
        </div>
        
        <div class="col-md-6">
            <label class="form-label">Area</label>
            <select class="form-control" name="area" required>
                    <option value="" selected disabled>-- Select Area --</option>
                    <option value="Rural">Rural</option>
                    <option value="Urban">Urban</option>
                </select>
        </div>

        <div class="col-md-4">
            <label for="grade_from" class="form-label">Grade/Class From</label>
            <select id="grade_from" name="grade_from" class="form-select" required>
                <option selected disabled>Select Grade</option>
                <?php for ($i = 1; $i <= 12; $i++): ?>
                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="col-md-4">
            <label for="grade_to" class="form-label">Grade/Class To</label>
            <select id="grade_to" name="grade_to" class="form-select" required>
                <option selected disabled>Select Grade</option>
                <?php for ($i = 1; $i <= 12; $i++): ?>
                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                <?php endfor; ?>
            </select>
        </div>


      <div class="col-md-4">
        <label class="form-label">Total Students</label>
        <input type="number" class="form-control" name="total_students" required>
      </div>

      <div class="col-md-4">
        <label class="form-label">Total Teachers</label>
        <input type="number" class="form-control" name="total_teachers" required>
      </div>

      <div class="col-md-6">
        <label class="form-label">Principal Name</label>
        <input type="text" class="form-control" name="principal_name" required>
      </div>

        <div class="col-md-6">
          <label class="form-label">Principal Mobile</label>
          <input type="tel" class="form-control" name="principal_mobile" placeholder="Enter Principal Mobile" pattern="[0-9]{10}" title="Enter a 10-digit phone number" required>
        </div>

      <div class="col-md-6">
        <label class="form-label">Teacher In-charge Name</label>
        <input type="text" class="form-control" name="teacher_incharge_name">
      </div>

      <div class="col-md-6">
        <label class="form-label">Teacher In-charge Mobile</label>
        <input type="tel" name="teacher_incharge_mobile" class="form-control" placeholder="Enter Teacher In-charge Mobile">
      </div>

        <div class="col-md-6">
          <label class="form-label">Password</label>
          <input type="password" class="form-control" name="password" id="password" required>
        </div>
        <div class="col-md-6">
          <label class="form-label">Confirm Password</label>
          <input type="password" class="form-control" name="confirm_password" id="confirm_password" required>
        </div>
        
      <div class="col-12 text-center">
        <button type="submit" class="btn register-btn px-5 mt-3">Register</button>
      </div>
    </form>
  </div>
</div>

<footer class="footer">
  &copy; 2024 Olympiad Examination Council. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
// --- State/District/Grade Population Logic ---
const districtData = {
    AndraPradesh: ["Anantapur", "Chittoor", "East Godavari", "Guntur", "Kadapa", "Krishna", "Kurnool", "Prakasam", "Nellore", "Srikakulam", "Visakhapatnam", "Vizianagaram", "West Godavari"],
    ArunachalPradesh: ["Anjaw", "Changlang", "Dibang Valley", "East Kameng", "East Siang", "Kra Daadi", "Kurung Kumey", "Lohit", "Longding", "Lower Dibang Valley", "Lower Subansiri", "Namsai", "Papum Pare", "Siang", "Tawang", "Tirap", "Upper Siang", "Upper Subansiri", "West Kameng", "West Siang", "Itanagar"],
    Assam: ["Baksa", "Barpeta", "Biswanath", "Bongaigaon", "Cachar", "Charaideo", "Chirang", "Darrang", "Dhemaji", "Dhubri", "Dibrugarh", "Goalpara", "Golaghat", "Hailakandi", "Hojai", "Jorhat", "Kamrup Metropolitan", "Kamrup (Rural)", "Karbi Anglong", "Karimganj", "Kokrajhar", "Lakhimpur", "Majuli", "Morigaon", "Nagaon", "Nalbari", "Dima Hasao", "Sivasagar", "Sonitpur", "South Salmara Mankachar", "Tinsukia", "Udalguri", "West Karbi Anglong"],
    Bihar: ["Araria", "Arwal", "Aurangabad", "Banka", "Begusarai", "Bhagalpur", "Bhojpur", "Buxar", "Darbhanga", "East Champaran", "Gaya", "Gopalganj", "Jamui", "Jehanabad", "Kaimur", "Katihar", "Khagaria", "Kishanganj", "Lakhisarai", "Madhepura", "Madhubani", "Munger", "Muzaffarpur", "Nalanda", "Nawada", "Patna", "Purnia", "Rohtas", "Saharsa", "Samastipur", "Saran", "Sheikhpura", "Sheohar", "Sitamarhi", "Siwan", "Supaul", "Vaishali", "West Champaran"],
    Karnataka: ["Bagalkot", "Bangalore Rural", "Bangalore Urban", "Belgaum", "Bellary", "Bidar", "Vijayapura", "Chamarajanagar", "Chikkaballapur", "Chikkamagaluru", "Chitradurga", "Dakshina Kannada", "Davanagere", "Dharwad", "Gadag", "Gulbarga", "Hassan", "Haveri", "Kodagu", "Kolar", "Koppal", "Mandya", "Mysore", "Raichur", "Ramanagara", "Shimoga", "Tumkur", "Udupi", "Uttara Kannada", "Yadgir"],
    Delhi: ["Central Delhi", "East Delhi", "New Delhi", "North Delhi", "North East Delhi", "North West Delhi", "Shahdara", "South Delhi", "South East Delhi", "South West Delhi", "West Delhi"],
    Puducherry: ["Karaikal", "Mahe", "Puducherry", "Yanam"],
    Chhattisgarh: ["Balod", "Baloda Bazar", "Balrampur", "Bastar", "Bemetara", "Bijapur", "Bilaspur", "Dantewada", "Dhamtari", "Durg", "Gariaband", "Janjgir-Champa", "Jashpur", "Kabirdham", "Kanker", "Kondagaon", "Korba", "Koriya", "Mahasamund", "Mungeli", "Narayanpur", "Raigarh", "Raipur", "Rajnandgaon", "Sukma", "Surajpur", "Surguja"],
    Goa: ["North Goa", "South Goa"],
    Gujarat: ["Ahmedabad", "Amreli", "Anand", "Aravalli", "Banaskantha", "Bharuch", "Bhavnagar", "Botad", "Chhota Udaipur", "Dahod", "Dang", "Devbhoomi Dwarka", "Gandhinagar", "Gir Somnath", "Jamnagar", "Junagadh", "Kheda", "Kutch", "Mahisagar", "Mehsana", "Morbi", "Narmada", "Navsari", "Panchmahal", "Patan", "Porbandar", "Rajkot", "Sabarkantha", "Surat", "Surendranagar", "Tapi", "Vadodara", "Valsad"],
    Haryana: ["Ambala", "Bhiwani", "Charkhi Dadri", "Faridabad", "Fatehabad", "Gurugram", "Hisar", "Jhajjar", "Jind", "Kaithal", "Karnal", "Kurukshetra", "Mahendragarh", "Nuh", "Palwal", "Panchkula", "Panipat", "Rewari", "Rohtak", "Sirsa", "Sonipat", "Yamunanagar"],
    HimachalPradesh: ["Bilaspur", "Chamba", "Hamirpur", "Kangra", "Kinnaur", "Kullu", "Lahaul and Spiti", "Mandi", "Shimla", "Sirmaur", "Solan", "Una"],
    JammuKashmir: ["Anantnag", "Bandipora", "Baramulla", "Budgam", "Doda", "Ganderbal", "Jammu", "Kathua", "Kishtwar", "Kulgam", "Kupwara", "Poonch", "Pulwama", "Rajouri", "Ramban", "Reasi", "Samba", "Shopian", "Srinagar", "Udhampur"],
    Jharkhand: ["Bokaro", "Chatra", "Deoghar", "Dhanbad", "Dumka", "East Singhbhum", "Garhwa", "Giridih", "Godda", "Gumla", "Hazaribagh", "Jamtara", "Khunti", "Koderma", "Latehar", "Lohardaga", "Pakur", "Palamu", "Ramgarh", "Ranchi", "Sahibganj", "Seraikela Kharsawan", "Simdega", "West Singhbhum"],
    Kerala: ["Alappuzha", "Ernakulam", "Idukki", "Kannur", "Kasaragod", "Kollam", "Kottayam", "Kozhikode", "Malappuram", "Palakkad", "Pathanamthitta", "Thiruvananthapuram", "Thrissur", "Wayanad"],
    MadhyaPradesh: ["Agar Malwa", "Alirajpur", "Anuppur", "Ashoknagar", "Balaghat", "Barwani", "Betul", "Bhind", "Bhopal", "Burhanpur", "Chhatarpur", "Chhindwara", "Damoh", "Datia", "Dewas", "Dhar", "Dindori", "Guna", "Gwalior", "Harda", "Hoshangabad", "Indore", "Jabalpur", "Jhabua", "Katni", "Khandwa", "Khargone", "Mandla", "Mandsaur", "Morena", "Narsinghpur", "Neemuch", "Niwari", "Panna", "Raisen", "Rajgarh", "Ratlam", "Rewa", "Sagar", "Satna", "Sehore", "Seoni", "Shahdol", "Shajapur", "Sheopur", "Shivpuri", "Sidhi", "Singrauli", "Tikamgarh", "Ujjain", "Umaria", "Vidisha"],
    Maharashtra: ["Ahmednagar", "Akola", "Amravati", "Aurangabad", "Beed", "Bhandara", "Buldhana", "Chandrapur", "Dhule", "Gadchiroli", "Gondia", "Hingoli", "Jalgaon", "Jalna", "Kolhapur", "Latur", "Mumbai City", "Mumbai Suburban", "Nagpur", "Nanded", "Nandurbar", "Nashik", "Osmanabad", "Palghar", "Parbhani", "Pune", "Raigad", "Ratnagiri", "Sangli", "Satara", "Sindhudurg", "Solapur", "Thane", "Wardha", "Washim", "Yavatmal"],
    Manipur: ["Bishnupur", "Chandel", "Churachandpur", "Imphal East", "Imphal West", "Jiribam", "Kakching", "Kamjong", "Kangpokpi", "Noney", "Pherzawl", "Senapati", "Tamenglong", "Tengnoupal", "Thoubal", "Ukhrul"],
    Meghalaya: ["East Garo Hills", "East Jaintia Hills", "East Khasi Hills", "North Garo Hills", "Ri Bhoi", "South Garo Hills", "South West Garo Hills", "South West Khasi Hills", "West Garo Hills", "West Jaintia Hills", "West Khasi Hills"],
    Mizoram: ["Aizawl", "Champhai", "Kolasib", "Lawngtlai", "Lunglei", "Mamit", "Saiha", "Serchhip", "Hnahthial", "Khawzawl", "Saitual"],
    Nagaland: ["Dimapur", "Kiphire", "Kohima", "Longleng", "Mokokchung", "Mon", "Peren", "Phek", "Tuensang", "Wokha", "Zunheboto"],
    Odisha: ["Angul", "Balangir", "Balasore", "Bargarh", "Bhadrak", "Boudh", "Cuttack", "Deogarh", "Dhenkanal", "Gajapati", "Ganjam", "Jagatsinghpur", "Jajpur", "Jharsuguda", "Kalahandi", "Kandhamal", "Kendrapara", "Kendujhar", "Khordha", "Koraput", "Malkangiri", "Mayurbhanj", "Nabarangpur", "Nayagarh", "Nuapada", "Puri", "Rayagada", "Sambalpur", "Sonepur", "Sundargarh"],
    Punjab: ["Amritsar", "Barnala", "Bathinda", "Faridkot", "Fatehgarh Sahib", "Fazilka", "Ferozepur", "Gurdaspur", "Hoshiarpur", "Jalandhar", "Kapurthala", "Ludhiana", "Malerkotla", "Mansa", "Moga", "Mohali", "Muktsar", "Pathankot", "Patiala", "Rupnagar", "Sangrur", "Shaheed Bhagat Singh Nagar", "Tarn Taran"],
    Rajasthan: ["Ajmer", "Alwar", "Banswara", "Baran", "Barmer", "Bharatpur", "Bhilwara", "Bikaner", "Bundi", "Chittorgarh", "Churu", "Dausa", "Dholpur", "Dungarpur", "Hanumangarh", "Jaipur", "Jaisalmer", "Jalore", "Jhalawar", "Jhunjhunu", "Jodhpur", "Karauli", "Kota", "Nagaur", "Pali", "Pratapgarh", "Rajsamand", "Sawai Madhopur", "Sikar", "Sirohi", "Sri Ganganagar", "Tonk", "Udaipur"],
    Sikkim: ["East Sikkim", "North Sikkim", "South Sikkim", "West Sikkim", "Pakyong", "Soreng"],
    TamilNadu: ["Ariyalur", "Chengalpattu", "Chennai", "Coimbatore", "Cuddalore", "Dharmapuri", "Dindigul", "Erode", "Kallakurichi", "Kanchipuram", "Kanyakumari", "Karur", "Krishnagiri", "Madurai", "Mayiladuthurai", "Nagapattinam", "Namakkal", "Nilgiris", "Perambalur", "Pudukkottai", "Ramanathapuram", "Ranipet", "Salem", "Sivaganga", "Tenkasi", "Thanjavur", "Theni", "Thoothukudi", "Tiruchirappalli", "Tirunelveli", "Tirupathur", "Tiruppur", "Tiruvallur", "Tiruvannamalai", "Tiruvarur", "Vellore", "Viluppuram", "Virudhunagar"],
    Telangana: ["Adilabad", "Bhadradri Kothagudem", "Hyderabad", "Jagtial", "Jangaon", "Jayashankar Bhupalapally", "Jogulamba Gadwal", "Kamareddy", "Karimnagar", "Khammam", "Komaram Bheem", "Mahabubabad", "Mahabubnagar", "Mancherial", "Medak", "Medchal–Malkajgiri", "Mulugu", "Nagarkurnool", "Nalgonda", "Narayanpet", "Nirmal", "Nizamabad", "Peddapalli", "Rajanna Sircilla", "Ranga Reddy", "Sangareddy", "Siddipet", "Suryapet", "Vikarabad", "Wanaparthy", "Warangal Rural", "Warangal Urban", "Yadadri Bhuvanagiri"],
    Tripura: ["Dhalai", "Gomati", "Khowai", "North Tripura", "Sepahijala", "South Tripura", "Unakoti", "West Tripura"],
    UttarPradesh: ["Agra", "Aligarh", "Prayagraj", "Ambedkar Nagar", "Amethi", "Amroha", "Auraiya", "Azamgarh", "Baghpat", "Bahraich", "Ballia", "Balrampur", "Banda", "Barabanki", "Bareilly", "Basti", "Bijnor", "Badaun", "Bulandshahr", "Chandauli", "Chitrakoot", "Deoria", "Etah", "Etawah", "Faizabad", "Farrukhabad", "Fatehpur", "Firozabad", "Gautam Buddh Nagar", "Ghaziabad", "Ghazipur", "Gonda", "Gorakhpur", "Hamirpur", "Hapur", "Hardoi", "Hathras", "Jalaun", "Jaunpur", "Jhansi", "Kannauj", "Kanpur Dehat", "Kanpur Nagar", "Kasganj", "Kaushambi", "Kheri", "Kushinagar", "Lalitpur", "Lucknow", "Maharajganj", "Mahoba", "Mainpuri", "Mathura", "Mau", "Meerut", "Mirzapur", "Moradabad", "Muzaffarnagar", "Pilibhit", "Pratapgarh", "Raebareli", "Rampur", "Saharanpur", "Sambhal", "Sant Kabir Nagar", "Sant Ravidas Nagar", "Shahjahanpur", "Shamli", "Shrawasti", "Siddharthnagar", "Sitapur", "Sonbhadra", "Sultanpur", "Unnao", "Varanasi"],
    Uttarakhand: ["Almora", "Bageshwar", "Chamoli", "Champawat", "Dehradun", "Haridwar", "Nainital", "Pauri Garhwal", "Pithoragarh", "Rudraprayag", "Tehri Garhwal", "Udham Singh Nagar", "Uttarkashi"],
    WestBengal: ["Alipurduar", "Bankura", "Birbhum", "Cooch Behar", "Dakshin Dinajpur", "Darjeeling", "Hooghly", "Howrah", "Jalpaiguri", "Jhargram", "Kalimpong", "Kolkata", "Malda", "Murshidabad", "Nadia", "North 24 Parganas", "Paschim Bardhaman", "Paschim Medinipur", "Purba Bardhaman", "Purba Medinipur", "Purulia", "South 24 Parganas", "Uttar Dinajpur"]
};

// Populate States
const stateSelect = document.getElementById('state');
const districtSelect = document.getElementById('district');

Object.keys(districtData).forEach(state => {
  const option = document.createElement('option');
  option.value = state;
  option.textContent = state.replace(/([A-Z])/g, ' $1').trim();
  stateSelect.appendChild(option);
});

// Update Districts on State Change
stateSelect.addEventListener('change', () => {
  const state = stateSelect.value;
  districtSelect.innerHTML = '<option selected disabled>Select District</option>';
  if (districtData[state]) {
    districtData[state].forEach(dist => {
      const option = document.createElement('option');
      option.value = dist;
      option.textContent = dist;
      districtSelect.appendChild(option);
    });
  }
});
</script>
</body>
</html>