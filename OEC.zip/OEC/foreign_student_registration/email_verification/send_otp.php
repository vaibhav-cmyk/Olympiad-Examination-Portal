<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



// 1. Start the session to access variables from index.php
session_start();

// 2. Add a security check. If email isn't in the session, redirect to the start.
if (!isset($_SESSION['email']) || empty($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

// 3. Get the email directly from the session
$email = $_SESSION['email'];

// --- The rest of the logic now runs automatically, not after a form post ---

// Include necessary files
require 'db.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$errorMessage = '';
$success = false;

// Generate OTP and Expiry
$otp = rand(100000, 999999);
$expiry = date("Y-m-d H:i:s", strtotime('+10 minutes'));

// Store OTP in DB
try {
    $stmt = $conn->prepare("INSERT INTO email_otps (email, otp, expires_at) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $email, $otp, $expiry);
    $stmt->execute();

    // Send email using PHPMailer
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'oec.code@gmail.com'; // 🔴 Replace with your Gmail
    $mail->Password = 'yozrrtxkvtoecqct';       // 🔴 Replace with your App Password
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('your-email@gmail.com', 'Olympiad Council');
    $mail->addAddress($email);
    $mail->Subject = 'Your Olympiad Council OTP Code';
    $mail->Body    = "Your verification code is: $otp. It is valid for 10 minutes.";

    $mail->send();

    // If email sends successfully, redirect to the verification page
    header("Location: verify.php?email=" . urlencode($email));
    exit();

} catch (Exception $e) {
    // If anything fails, set an error message to display
    $errorMessage = "Could not send OTP. Please try again later. Error: {$e->getMessage()}";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Sending Verification Email...</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #e3f2fd, #90caf9);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card {
            animation: fadeInUp 0.8s ease-out;
        }
        @keyframes fadeInUp {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card shadow-lg rounded-4 p-4 text-center">
                    <?php if (!empty($errorMessage)): ?>
                        <h4 class="text-danger">An Error Occurred</h4>
                        <div class="alert alert-danger mt-3"><?php echo $errorMessage; ?></div>
                        <a href="index.php" class="btn btn-primary mt-2">Go Back</a>
                    <?php else: ?>
                        <h4>Processing...</h4>
                        <p>Sending verification code to your email.</p>
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>